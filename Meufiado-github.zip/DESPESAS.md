﻿# Despesas por itens: impostos e funcionários

A seção Despesas registra cada gasto individualmente. Os totais são calculados pela
soma dos lançamentos; não há um campo para informar o total do funcionário.

## Como usar

Em **Funcionários**, informe ou selecione o nome, escolha o mês de referência e a
data de pagamento. Adicione as linhas com **+ Adicionar gasto**. Cada linha tem tipo,
valor e descrição opcional. Sem descrição, o sistema usa o nome do tipo escolhido.
Tipos: salário, transporte, comissão, vale alimentação, benefícios, INSS/encargos,
hora extra, bonificação e outros.

Em **Impostos**, cada linha contém nome/descrição e valor. Use **+ Adicionar imposto**
para registrar DAS, ICMS, ISS, taxas municipais e outros pagamentos no mesmo formulário.

A prévia soma os itens imediatamente quando os valores são alterados ou uma linha é
adicionada/removida. O botão Registrar gastos salva todos os itens de uma vez. A data,
mês e observações informados no formulário são aplicados a esses itens; depois é
possível editar cada gasto individualmente.

O histórico de funcionários agrupa os itens por pessoa e mostra seu total no mês.
O link **+ Adicionar gasto para [nome]** abre um novo formulário com o funcionário e
mês preenchidos. Cada gasto tem ações de edição e exclusão. O filtro mensal mostra
outros períodos, mantendo visíveis os totais de impostos, funcionários e ambos.

## Cálculos

Os valores são validados no servidor e armazenados em centavos inteiros. O JavaScript
calcula apenas a prévia; nenhum total enviado pelo navegador é utilizado. O backend
valida cada linha e os resumos usam `SUM(valor_centavos)` por `usuario_id`, funcionário,
categoria e mês de referência. Edições e exclusões alteram os itens e o resumo é
recalculado na próxima leitura, sem total acumulado armazenado.

Exemplo de outubro/2026:

- João: salário 1.675 + transporte 100 + comissão 200 = R$ 1.975,00.
- Maria: R$ 2.250,00; Carlos: R$ 1.800,00.
- Todos os funcionários: R$ 6.025,00.
- DAS 500 + ICMS 300 + taxa municipal 100 = R$ 900,00.
- Total combinado: R$ 6.925,00.

Continuam sendo rejeitados valores zero, negativos, inválidos, não finitos e acima
do limite do projeto (R$ 999.999.999,99 por item). O arredondamento é o existente,
para centavos, half-up. Datas devem ser válidas e pagamentos não podem estar no futuro.
Os nomes/descrições têm limite de 150 caracteres e observações de 500 caracteres.

## Banco e migração

Mantido o padrão de migrações aditivas/idempotentes em `init_db()`:

- `funcionarios`: ID, `usuario_id`, nome, nome normalizado e data de criação.
  A unicidade é por usuário e nome normalizado; espaços extras e diferenças de
  maiúsculas/minúsculas não criam outro cadastro da mesma pessoa.
- `despesas_operacionais`: continua sendo a tabela normalizada de itens para as duas
  categorias. Foi adicionada a FK `funcionario_id`; itens de impostos não têm esse vínculo.
- `idx_despesas_funcionario_mes`: índice de usuário, funcionário e mês de referência.
- Triggers de inserção/atualização impedem vincular um gasto a funcionário de outra
  conta, deixar gasto de funcionário sem vínculo ou associar um imposto a funcionário.
- `despesas_lotes`: chave por usuário e hash do formulário normalizado. Serve apenas
  para evitar reenvios duplicados; não armazena despesas em JSON nem totais.
- `despesas_envios`: preservada para identificar o envio de cada item, inclusive
  depois de sua exclusão. As chaves de itens são derivadas da chave do formulário.

Esta organização usa `funcionarios` + os lançamentos já existentes em
`despesas_operacionais`, evitando duplicar a estrutura de impostos/funcionários ou
romper os vínculos com o Caixa.

Migração de registros antigos: como antes não existia um nome de funcionário separado,
a descrição original é usada como nome inicial. Registros da mesma conta com esse nome
são vinculados ao mesmo funcionário. Descrições diferentes continuam separadas, sem
inferir identidades a partir de texto livre. É possível corrigir o nome/vínculo ao
editar cada gasto. IDs, valores, meses, datas, observações e movimentos do Caixa são
preservados. A migração pode ser executada novamente sem duplicar funcionários.

## Caixa, relatórios e segurança

Cada item mantém uma única saída vinculada no Caixa, com sua data de pagamento.
Editar um item atualiza o mesmo movimento; excluir o item remove sua saída. Não é
permitida exclusão direta pelo Caixa. O vínculo permite abrir o gasto de origem.

O lote inteiro usa a transação `banco(escrita=True)` / `BEGIN IMMEDIATE`. Se qualquer
item, vínculo, registro de envio ou saída falhar, tudo é desfeito, inclusive um novo
cadastro de funcionário criado naquele envio. Reenvios simultâneos não duplicam itens.
Reutilizar o formulário com itens alterados, adicionados/removidos, ou após excluir
um item salvo, é rejeitado. Um novo formulário permite pagamentos adicionais legítimos.

Todas as consultas e alterações seguem o `usuario_id` autenticado e SQL parametrizado.
Os campos de propriedade enviados pelo navegador não atribuem a conta nem o vínculo.
O cadastro/seleção por nome só consulta os funcionários do usuário. O parâmetro de
pré-seleção `funcionario` também exige propriedade. As proteções globais de sessão,
plano, CSRF e requisições de outra origem continuam aplicadas.

Relatórios mantêm o detalhamento por data de pagamento. Os gastos já fazem parte das
saídas do Caixa e não são subtraídos novamente. Receita de vendas e Dashboard permanecem
inalterados. Pagamentos antigos registrados manualmente no Caixa não são importados
nem deduplicados por nome/valor: confira esses registros antes de cadastrar novamente.

## Rotas

Não foram necessárias novas URLs:

| Rota | Métodos | Uso |
| --- | --- | --- |
| `/despesas` | GET | Visão mensal, aba de impostos |
| `/despesas/impostos` | GET, POST | Histórico e cadastro de vários impostos |
| `/despesas/funcionarios` | GET, POST | Histórico por funcionário e cadastro de vários gastos |
| `/despesas/<id>/editar` | GET, POST | Editar um item |
| `/despesas/<id>/excluir` | POST | Excluir um item e sua saída |

Use `?mes=YYYY-MM` para histórico e `?mes=YYYY-MM&funcionario=<id>` para adicionar
itens a um funcionário já cadastrado. O formulário envia campos repetidos `descricao`,
`valor` e `tipo`, além de `funcionario_nome` para funcionários, `mes_referencia`,
`data_pagamento`, `observacao`, `csrf_token` e `chave_envio` no cadastro.

## Arquivos

Criado: `static/js/despesas.js`.

Modificados:

- `meufiado/database.py`
- `meufiado/services/despesas.py`
- `meufiado/routes/despesas.py`
- `templates/despesas.html`
- `static/style.css`
- `tests/test_despesas.py`
- `tests/test_despesas_browser.py`
- `DESPESAS.md`

## Verificação

Verificação final: **97 testes passaram, sem falhas, erros ou testes ignorados**, executados por módulos:

- Despesas/backend: 45.
- Despesas/navegador: 11, incluindo layout de 390 px e os formulários com vários itens.
- Fiado: 6; segurança e regras de negócio: 20; estrutura/migrações: 5.
- Vendas/navegador: 10.

Foram acrescentadas 17 regressões nesta atualização (12 de backend e 5 de navegador).
`compileall` também passou. As telas de computador e celular foram inspecionadas.
O teste móvel aguarda o carregamento completo antes de medir a largura da página.

A migração foi aplicada ao banco local após backup em
`.venv/tmp/meufiado-antes-itens-20261016-224916.db`. A comparação com o backup confirmou
os dados originais preservados nas 12 tabelas anteriores, integridade SQLite válida
e nenhuma nova violação de chave estrangeira. O servidor local foi reiniciado;
`/despesas/funcionarios` redireciona corretamente para login quando não autenticado,
e o novo JavaScript responde HTTP 200.

Abra `http://127.0.0.1:5000/despesas/funcionarios` ou
`http://127.0.0.1:5000/despesas/impostos` no computador em que o servidor está rodando.

As regressões incluem o exemplo completo de R$ 6.925,00, vários itens por funcionário,
vários impostos, várias pessoas/contas/meses, totais enviados adulterados, edição,
exclusão, novos gastos posteriores, valores inválidos, isolamento de vínculos, migração
legada, rollback do lote e reenvio após exclusão parcial. As verificações de navegador
cobrem prévia imediata, inclusão/remoção de linhas, correção de erros, arredondamento,
formulário vazio, envio simultâneo e layout móvel.

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe -m compileall -q app.py meufiado tests
```

Os testes usam apenas bancos temporários. Instale `requirements-dev.txt` e Edge ou
Playwright Chromium para os testes de navegador.

## Conferência manual

1. Recarregue a página após a atualização do servidor.
2. Cadastre João com salário 1.675, transporte 100 e comissão 200. Confira a prévia
   e o histórico de R$ 1.975,00.
3. Altere/remova linhas antes de salvar e confira a atualização imediata.
4. Cadastre Maria e Carlos e confira o total mensal de todos os funcionários.
5. Adicione posteriormente um gasto a João pelo link no histórico.
6. Edite/exclua um gasto salvo e confira os totais e o mesmo vínculo no Caixa.
7. Cadastre os três impostos do exemplo e confira R$ 900,00.
8. Mude o mês e entre em outra conta para conferir a separação dos dados.
9. Confira nomes migrados de registros antigos; ajuste o vínculo quando a descrição
   antiga não correspondia ao nome da pessoa.

