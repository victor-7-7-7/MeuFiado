# MeuFiado modular refactor

The application has been reorganized by extracting the existing functions. The
URLs, endpoint names, templates, assets, SQL, account ownership predicates, and
business transaction boundaries are preserved.

## Files

Created application files:

```text
meufiado/
  __init__.py                 create_app(config=None)
  config.py                   environment settings and project paths
  database.py                 SQLite connections, transactions, startup migrations
  filters.py                  existing Jinja filters
  security.py                 CSRF, sessions, admin permissions, global hooks
  utils.py                    money, date, and input helpers
  cli.py                      three existing account management commands
  services/
    __init__.py
    contas.py                 account validation, creation, administrative lookup
    planos.py                 plan validation, billing dates, access checks
    ownership.py              account-scoped customer/product/supplier lookups
    clientes.py               customer form normalization and duplicate names
    fiado.py                  balances and payment-to-cash recording
    painel.py                 dashboard queries
  routes/
    __init__.py                domain registration in the original route order
    auth.py                   login throttling, session creation, logout
    admin.py                  accounts, passwords, plans, activation, deletion
    painel.py                 landing page, dashboard, summary API
    clientes.py               customer CRUD
    fiado.py                  credit purchases, debt statements, payments, WhatsApp
    estoque.py                inventory and product management
    fornecedores.py           supplier management
    vendas.py                 sales, inventory deduction, cash/credit integration
    relatorios.py             reports
    caixa.py                  income, expenses, protected manual deletion
```

Additional files created: `tests/test_security_and_business.py`,
`tests/test_structure.py`, and this document.

Files modified: `app.py` and `tests/test_app.py`.

`app.py` retains the default application object, re-exports `create_app`, preserves
`BASE_DIR`, `DB_PATH`, and the connection/transaction/initialization helpers for
existing scripts, and runs the development server with `debug=False`.

## Architecture decisions

- Route modules use `register_routes(app)` and `app.add_url_rule` rather than
  Blueprints. The existing templates, CSS body classes, and global security hook
  rely on unqualified `request.endpoint` names. This keeps those names and the
  `/admin` versus `/contas` URL-building order intact without compatibility aliases.
- Modules depend on shared services and Flask context proxies; they do not import
  the default application from `app.py`, avoiding circular dependencies.
- The factory reads environment settings on each call. Database access uses the
  current application's `DB_PATH`, allowing independent applications in tests.
- The existing initialization/migration SQL remains in `database.py` and executes
  at application creation, as it previously did during `app.py` import. Legacy
  backup behavior and database-backed persistent secret keys remain in place.
- CLI callbacks retain an application context through Flask's `with_appcontext`.
- Security hooks apply globally before domain handlers. The existing same-origin
  CSRF fallback, token checks, login limits, session version checks, plan checks,
  cookie settings, and response headers are retained.
- Sales and payments retain their existing `BEGIN IMMEDIATE` transactions; their
  SQL was not split into independently committed operations.
- Shared helpers are available from their owning modules, for example
  `meufiado.services.painel.dados_painel`. Request-dependent helpers still require
  an application/request context and the authenticated `g.usuario`.

## Verification

Completed checks:

- All 31 regression tests pass using temporary databases.
- All 61 non-database function bodies and signatures match the original source.
- The database initialization/migration strings remain unchanged.
- All 31 route entries (including static), 23 schema objects, three CLI command
  names, and 35 template/asset hashes match the pre-refactor snapshot.
- Python compilation and the existing Flask route/CLI discovery commands pass.


The original six tests predated authentication and CSRF. Their fixtures now create
an account, assign customer ownership, log in, provide real CSRF tokens, and read
the dashboard in an application context. Assertions still cover the same customer,
fiado, payment, invalid-value, HTML escaping, and WhatsApp scenarios. The dashboard
empty-state assertion now uses its existing `/painel` URL; `/` is the landing page.

The additional tests cover the original route/method/endpoint contract, factory
isolation, cookie/environment configuration, legacy migrations and backups,
startup helpers, authentication, login throttling, CSRF tokens and origin fallback,
session revocation, account isolation, inventory, suppliers, cash and credit sales,
transaction rollback, cash protections, reports, administration, and all CLI commands.
All test databases are temporary; tests never open the project's business database.

During extraction, the original route map, SQLite schema, CLI names, source
function bodies, and template/asset hashes were captured for comparison. Those
local comparison artifacts are under the ignored `.venv/` directory.

From PowerShell, using the existing local environment:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe -m compileall -q app.py meufiado tests
.\.venv\Scripts\python.exe -m flask --app app routes
.\.venv\Scripts\python.exe -m flask --app app --help
.\.venv\Scripts\python.exe app.py
```

For a fresh environment, first run `python -m venv .venv`. Existing launch forms
`python app.py`, `flask --app app run`, and WSGI `app:app` remain supported. A direct
factory launch is also available:

```powershell
.\.venv\Scripts\python.exe -m flask --app meufiado:create_app run
```

`MEUFIADO_DB_PATH`, `MEUFIADO_SECRET_KEY`, and `MEUFIADO_HTTPS` retain their meanings.
Route listing and server commands initialize the configured database just as the
original entry point did. Use a disposable `MEUFIADO_DB_PATH` for isolated checks.

## Manual checks

Check login/logout and an existing browser session, admin plan/password changes,
customer dialogs, fiado partial/full payments, WhatsApp message links, cash and
credit sales, inventory quantities, supplier screens, and report totals. Confirm
that two accounts cannot see or change each other's records. Check HTTPS cookie
behavior using the actual reverse proxy configuration.

The original legacy-backup connection uses a SQLite transaction context, which
does not explicitly close the backup handle. On Windows, immediate backup-file
cleanup can wait for garbage collection. This existing lifecycle is retained;
the migration test releases it before deleting its temporary files.

The automated suite exercises Flask requests and database effects. It does not
exercise browser JavaScript, external WhatsApp navigation, production WSGI/proxy
configuration, or concurrent writes from multiple processes. Existing UI behavior
and business rules were retained, including any pre-existing limitations.


## Sales submission fix

The sales template's Finalizar venda button had no submission handler, so its
cart never reached the existing POST /vendas transaction. The template now loads
static/js/vendas.js. That file retains cart rendering and submits payment type,
customer ID, and product IDs/quantities as JSON, with the existing X-CSRFToken
header and session cookies. A synchronous in-flight guard and disabled controls
block duplicate clicks and cart edits until the response finishes.

On success the cart is cleared and product options are read back from GET /vendas,
so their displayed stock comes from committed database quantities. Refresh failures
show that the sale succeeded and ask for a page refresh; they never repeat the
POST. Errors retain the cart and display the backend's JSON/plain-text error or a
readable HTML error response. Network failures do not retry automatically.

The backend sales module, stock SQL, ownership checks, security hooks, and schema
were unchanged. The sales template and its new script are intentional changes
after the refactor's original template/asset comparison recorded above.

New files: static/js/vendas.js, tests/test_sales_browser.py, requirements-dev.txt.
Modified files: templates/vendas.html and this document.

The full suite now passes 41 tests, including ten headless-browser tests against
an isolated Flask server and temporary SQLite database. The browser checks confirm
cash sales and fiado sales, actual persisted stock, duplicate clicks, insufficient
stock, transaction rollback, foreign-account product IDs, CSRF failures, expired
sessions, network failures, and failed stock refresh after a successful sale.
JavaScript syntax and the final readable 404 error check also pass.

Examples confirmed directly in SQLite: a five-unit cash sale reduced stock from
10 to 5 and created one 2500-cent cash entry; a two-unit fiado sale reduced stock
from 10 to 8 and created a 10.00 debt. Rapid double-clicks produced one POST and
one sale. These checks never used the business database.

Install browser-test dependencies and run:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe -m unittest discover -s tests -p test_sales_browser.py -v
```

Browser tests use installed Edge on Windows. To use Playwright Chromium instead,
run python -m playwright install chromium and set MEUFIADO_TEST_BROWSER_CHANNEL
to chromium. Without Playwright/browser dependencies, browser tests are skipped;
the standard Flask regression tests remain available. Reload the sales page after
updating a running server so it loads the new script.
