"""Jinja filters for Brazilian currency, dates, and customer initials."""

from datetime import datetime


def format_moeda(valor):

    try:
        valor = float(valor)

    except (TypeError, ValueError):
        valor = 0.0

    partes = (
        f"{valor:,.2f}"
        .replace(",", "X")
        .replace(".", ",")
        .replace("X", ".")
    )

    return f"R$ {partes}"



def data_br(valor):

    try:

        return datetime.strptime(
            valor,
            "%Y-%m-%d"
        ).strftime(
            "%d/%m/%Y"
        )

    except (TypeError, ValueError):

        return (
            valor
            or "Data não informada"
        )



def iniciais(nome):

    partes = (
        nome or ""
    ).split()

    if not partes:
        return "?"

    return (
        partes[0][0]
        +
        (
            partes[-1][0]
            if len(partes) > 1
            else ""
        )
    ).upper()



def register_filters(app):
    app.jinja_env.filters.update(
        moeda=format_moeda, data_br=data_br, iniciais=iniciais
    )
