"""Account-owned expense items, employee history, monthly totals and cash outflows."""

from datetime import datetime
import hashlib
import json
import re

from flask import abort

from meufiado.utils import centavos, data_valida, mes_valido, valor_positivo


TIPOS_FUNCIONARIOS = {
    'salario': 'Salário',
    'transporte': 'Transporte',
    'comissoes': 'Comissão',
    'alimentacao': 'Vale alimentação',
    'beneficios': 'Benefícios',
    'encargos': 'INSS / encargos',
    'hora_extra': 'Hora extra',
    'bonus': 'Bonificação',
    'outros': 'Outros',
}
CATEGORIAS = {'imposto', 'funcionario'}
CAMPOS_DESPESA = ('categoria', 'descricao', 'valor_centavos', 'data_pagamento',
                  'mes_referencia', 'tipo', 'observacao')


def validar_chave_envio(chave):
    if not re.fullmatch(r'[0-9a-f]{32}', chave or ''):
        raise ValueError('Atualize a página antes de registrar a despesa.')
    return chave


def validar_despesa(form, categoria):
    if categoria not in CATEGORIAS:
        raise ValueError('Categoria de despesa inválida.')
    tipo = form.get('tipo', '') if categoria == 'funcionario' else ''
    funcionario_nome = ''
    if categoria == 'funcionario':
        if tipo not in TIPOS_FUNCIONARIOS:
            raise ValueError('Selecione um tipo de despesa com funcionários válido.')
        funcionario_nome = ' '.join(form.get('funcionario_nome', '').split())
        if not funcionario_nome or len(funcionario_nome) > 150:
            raise ValueError('Informe o nome do funcionário, com até 150 caracteres.')
    descricao = ' '.join(form.get('descricao', '').split())
    if not descricao and categoria == 'funcionario':
        descricao = TIPOS_FUNCIONARIOS[tipo]
    if not descricao or len(descricao) > 150:
        raise ValueError('Informe uma descrição de até 150 caracteres.')
    valor = centavos(valor_positivo(form.get('valor')))
    pagamento = data_valida(form.get('data_pagamento'))
    if pagamento > datetime.now().strftime('%Y-%m-%d'):
        raise ValueError('Registre somente pagamentos já realizados, até a data de hoje.')
    referencia = mes_valido(form.get('mes_referencia'))
    observacao = form.get('observacao', '').strip()
    if len(observacao) > 500:
        raise ValueError('Use uma observação de até 500 caracteres.')
    return {
        'categoria': categoria, 'descricao': descricao, 'valor_centavos': valor,
        'data_pagamento': pagamento, 'mes_referencia': referencia,
        'tipo': tipo, 'observacao': observacao, 'funcionario_nome': funcionario_nome,
    }


def linhas_formulario(form):
    """Retain every submitted row when validation fails (including incomplete rows)."""
    campos = {campo: form.getlist(campo) for campo in ('descricao', 'valor', 'tipo')}
    quantidade = max((len(valores) for valores in campos.values()), default=0)
    return [{campo: valores[i] if i < len(valores) else '' for campo, valores in campos.items()}
            for i in range(quantidade)]


def validar_lancamentos(form, categoria):
    descricoes, valores, tipos = (form.getlist(c) for c in ('descricao', 'valor', 'tipo'))
    if not valores or len(descricoes) != len(valores) or (categoria == 'funcionario' and len(tipos) != len(valores)):
        raise ValueError('Adicione pelo menos um gasto e preencha todas as linhas.')
    itens = []
    for numero, linha in enumerate(linhas_formulario(form), 1):
        try:
            itens.append(validar_despesa({**form.to_dict(), **linha}, categoria))
        except ValueError as exc:
            raise ValueError(f'Gasto {numero}: {exc}') from exc
    return itens


def obter_funcionario(conn, usuario_id, funcionario_id):
    funcionario = conn.execute('SELECT * FROM funcionarios WHERE id=? AND usuario_id=?',
                               (funcionario_id, usuario_id)).fetchone()
    if funcionario is None:
        abort(404)
    return funcionario


def listar_funcionarios(conn, usuario_id):
    return conn.execute('SELECT id, nome FROM funcionarios WHERE usuario_id=? ORDER BY nome_normalizado',
                        (usuario_id,)).fetchall()


def _funcionario_da_despesa(conn, usuario_id, dados):
    if dados['categoria'] != 'funcionario':
        return None
    nome = dados['funcionario_nome']
    conn.execute('INSERT OR IGNORE INTO funcionarios (usuario_id, nome, nome_normalizado) VALUES (?, ?, ?)',
                 (usuario_id, nome, nome.casefold()))
    return conn.execute('SELECT id FROM funcionarios WHERE usuario_id=? AND nome_normalizado=?',
                        (usuario_id, nome.casefold())).fetchone()['id']


def obter_despesa(conn, usuario_id, despesa_id):
    despesa = conn.execute(
        '''SELECT d.*, f.nome AS funcionario_nome FROM despesas_operacionais d
           LEFT JOIN funcionarios f ON f.id=d.funcionario_id AND f.usuario_id=d.usuario_id
           WHERE d.id=? AND d.usuario_id=?''', (despesa_id, usuario_id),
    ).fetchone()
    if despesa is None:
        abort(404)
    return despesa


def listar_despesas(conn, usuario_id, mes, categoria):
    return conn.execute(
        '''SELECT d.*, f.nome AS funcionario_nome FROM despesas_operacionais d
           LEFT JOIN funcionarios f ON f.id=d.funcionario_id AND f.usuario_id=d.usuario_id
           WHERE d.usuario_id=? AND d.mes_referencia=? AND d.categoria=?
           ORDER BY d.data_pagamento DESC, d.id DESC''', (usuario_id, mes, categoria),
    ).fetchall()


def resumo_funcionarios(conn, usuario_id, mes):
    return conn.execute(
        '''SELECT f.id, f.nome, SUM(d.valor_centavos) AS total_centavos, COUNT(*) AS quantidade
           FROM funcionarios f JOIN despesas_operacionais d
             ON d.funcionario_id=f.id AND d.usuario_id=f.usuario_id
           WHERE f.usuario_id=? AND d.mes_referencia=? AND d.categoria='funcionario'
           GROUP BY f.id, f.nome ORDER BY f.nome_normalizado''', (usuario_id, mes),
    ).fetchall()


def _totais(conn, usuario_id, condicao, parametros):
    # Conditions are fixed by the two services below; request values stay parameterized.
    rows = conn.execute(
        '''SELECT categoria, COALESCE(SUM(valor_centavos), 0) AS total
           FROM despesas_operacionais WHERE usuario_id=? AND ''' + condicao +
        ' GROUP BY categoria', (usuario_id, *parametros),
    ).fetchall()
    totais = {row['categoria']: row['total'] for row in rows}
    impostos = totais.get('imposto', 0)
    funcionarios = totais.get('funcionario', 0)
    return {'impostos_centavos': impostos, 'funcionarios_centavos': funcionarios,
            'total_centavos': impostos + funcionarios}


def resumo_mes(conn, usuario_id, mes):
    return _totais(conn, usuario_id, 'mes_referencia=?', (mes,))


def resumo_pagamentos(conn, usuario_id, inicio, fim):
    return _totais(conn, usuario_id, 'data_pagamento BETWEEN ? AND ?', (inicio, fim))


def _sincronizar_caixa(conn, usuario_id, despesa_id):
    despesa = obter_despesa(conn, usuario_id, despesa_id)
    prefixo = 'Imposto' if despesa['categoria'] == 'imposto' else f"Funcionário {despesa['funcionario_nome']}"
    descricao = f"{prefixo}: {despesa['descricao']}"
    movimento = conn.execute(
        'SELECT id FROM caixa_movimentos WHERE despesa_id=? AND usuario_id=?',
        (despesa_id, usuario_id),
    ).fetchone()
    if movimento:
        conn.execute(
            '''UPDATE caixa_movimentos SET descricao=?, valor_centavos=?, data=?
               WHERE id=? AND usuario_id=? AND despesa_id=?''',
            (descricao, despesa['valor_centavos'], despesa['data_pagamento'],
             movimento['id'], usuario_id, despesa_id),
        )
    else:
        conn.execute(
            '''INSERT INTO caixa_movimentos
               (usuario_id, tipo, descricao, valor_centavos, data, origem, despesa_id)
               VALUES (?, 'saida', ?, ?, ?, 'manual', ?)''',
            (usuario_id, descricao, despesa['valor_centavos'], despesa['data_pagamento'], despesa_id),
        )


def criar_despesa(conn, usuario_id, dados, chave_envio=None):
    """Caller uses banco(escrita=True) so expense, cash and receipt commit together."""
    funcionario_id = _funcionario_da_despesa(conn, usuario_id, dados)
    if chave_envio is not None:
        validar_chave_envio(chave_envio)
        envio = conn.execute(
            'SELECT despesa_id FROM despesas_envios WHERE usuario_id=? AND chave=?',
            (usuario_id, chave_envio),
        ).fetchone()
        if envio is not None:
            if envio['despesa_id'] is None:
                raise ValueError('Esta despesa já foi excluída. Atualize a página para registrar outro pagamento.')
            despesa = obter_despesa(conn, usuario_id, envio['despesa_id'])
            if (any(despesa[campo] != dados[campo] for campo in CAMPOS_DESPESA)
                    or despesa['funcionario_id'] != funcionario_id):
                raise ValueError('Este formulário já foi utilizado. Atualize a página para registrar outro pagamento.')
            return despesa['id']
    despesa_id = conn.execute(
        '''INSERT INTO despesas_operacionais
           (usuario_id, categoria, descricao, valor_centavos, data_pagamento,
            mes_referencia, tipo, observacao, funcionario_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
        (usuario_id, *(dados[campo] for campo in CAMPOS_DESPESA), funcionario_id),
    ).lastrowid
    _sincronizar_caixa(conn, usuario_id, despesa_id)
    if chave_envio is not None:
        conn.execute(
            'INSERT INTO despesas_envios (usuario_id, chave, despesa_id) VALUES (?, ?, ?)',
            (usuario_id, chave_envio, despesa_id),
        )
    return despesa_id


def criar_lancamentos(conn, usuario_id, itens, chave_envio):
    """Persist the whole form atomically; never accept a browser-provided total."""
    validar_chave_envio(chave_envio)
    if not itens:
        raise ValueError('Adicione pelo menos um gasto.')
    # Honor receipts issued by the previous single-item form after an upgrade.
    legado = conn.execute('SELECT despesa_id FROM despesas_envios WHERE usuario_id=? AND chave=?',
                          (usuario_id, chave_envio)).fetchone()
    if legado is not None:
        if len(itens) != 1:
            raise ValueError('Este formulário já foi utilizado. Atualize a página para registrar outros gastos.')
        return [criar_despesa(conn, usuario_id, itens[0], chave_envio=chave_envio)]
    # Only the fingerprint is stored, never a JSON expense document or a total.
    assinatura = hashlib.sha256(json.dumps(itens, sort_keys=True, ensure_ascii=True).encode()).hexdigest()
    lote = conn.execute('SELECT assinatura FROM despesas_lotes WHERE usuario_id=? AND chave=?',
                        (usuario_id, chave_envio)).fetchone()
    if lote is not None and lote['assinatura'] != assinatura:
        raise ValueError('Este formulário já foi utilizado. Atualize a página para registrar outros gastos.')
    if lote is None:
        conn.execute('INSERT INTO despesas_lotes (usuario_id, chave, assinatura) VALUES (?, ?, ?)',
                     (usuario_id, chave_envio, assinatura))
    ids = []
    for indice, dados in enumerate(itens):
        chave_item = hashlib.sha256(f'{chave_envio}:{indice}'.encode()).hexdigest()[:32]
        ids.append(criar_despesa(conn, usuario_id, dados, chave_envio=chave_item))
    return ids


def atualizar_despesa(conn, usuario_id, despesa_id, dados):
    despesa = obter_despesa(conn, usuario_id, despesa_id)
    if dados['categoria'] != despesa['categoria']:
        raise ValueError('A categoria da despesa não pode ser alterada.')
    funcionario_id = _funcionario_da_despesa(conn, usuario_id, dados)
    conn.execute(
        '''UPDATE despesas_operacionais SET descricao=?, valor_centavos=?,
           data_pagamento=?, mes_referencia=?, tipo=?, observacao=?, funcionario_id=?,
           atualizado_em=CURRENT_TIMESTAMP WHERE id=? AND usuario_id=?''',
        (dados['descricao'], dados['valor_centavos'], dados['data_pagamento'],
         dados['mes_referencia'], dados['tipo'], dados['observacao'], funcionario_id, despesa_id, usuario_id),
    )
    _sincronizar_caixa(conn, usuario_id, despesa_id)


def excluir_despesa(conn, usuario_id, despesa_id):
    obter_despesa(conn, usuario_id, despesa_id)
    conn.execute('DELETE FROM caixa_movimentos WHERE despesa_id=? AND usuario_id=?',
                 (despesa_id, usuario_id))
    conn.execute('DELETE FROM despesas_operacionais WHERE id=? AND usuario_id=?',
                 (despesa_id, usuario_id))
