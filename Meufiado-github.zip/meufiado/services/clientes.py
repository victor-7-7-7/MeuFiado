"""Customer form normalization and account-scoped duplicate-name checks."""

from flask import g, request


def dados_cliente():

    return (

        " ".join(
            request.form.get(
                "nome",
                ""
            ).split()
        ),

        request.form.get(
            "celular",
            ""
        ).strip(),

        request.form.get(
            "endereco",
            ""
        ).strip()

    )



def nome_duplicado(
    conn,
    nome,
    excluir_id=0
):

    return conn.execute(
        """
        SELECT id

        FROM clientes

        WHERE usuario_id=?

          AND TRIM(nome)=?
              COLLATE NOCASE

          AND id!=?
        """,
        (
            g.usuario[
                "id"
            ],

            nome,

            excluir_id
        )
    ).fetchone() is not None

