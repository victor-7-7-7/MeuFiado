"""Account validation, creation, and administrative account lookup."""

from datetime import datetime
import re

from flask import abort
from werkzeug.security import generate_password_hash


def validar_conta(
    nome,
    login,
    senha
):

    nome = " ".join(
        nome.split()
    )

    login = (
        login
        .strip()
        .lower()
    )

    if (
        not nome
        or len(nome) > 100
    ):

        raise ValueError(
            "Informe um nome de até 100 caracteres."
        )

    if not re.fullmatch(
        r"[a-z0-9_.@+-]{3,100}",
        login
    ):

        raise ValueError(
            "O login deve ter de 3 a 100 caracteres: "
            "letras, números, ponto, @, +, - ou _."
        )

    if (
        len(senha) < 8
        or len(senha) > 128
    ):

        raise ValueError(
            "Use uma senha de 8 a 128 caracteres."
        )

    return (
        nome,
        login
    )



def criar_conta(
    conn,
    nome,
    login,
    senha,
    admin=False,
    plano=None
):

    nome, login = validar_conta(
        nome,
        login,
        senha
    )

    if conn.execute(
        """
        SELECT id
        FROM contas
        WHERE login=?
        """,
        (
            login,
        )
    ).fetchone():

        raise ValueError(
            "Este login já está cadastrado."
        )

    plano = plano or {

        "plano_nome":
            "Vitalício",

        "plano_tipo":
            "unico",

        "plano_valor_centavos":
            0,

        "plano_inicio":
            datetime.now().strftime(
                "%Y-%m-%d"
            ),

        "plano_vencimento":
            None,

        "plano_status":
            "ativo",

        "plano_observacao":
            "",

    }

    return conn.execute(
        """
        INSERT INTO contas (

            nome,
            login,
            senha_hash,
            admin,

            plano_nome,
            plano_tipo,
            plano_valor_centavos,

            plano_inicio,
            plano_vencimento,
            plano_status,
            plano_observacao

        )

        VALUES (
            ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?
        )
        """,
        (
            nome,

            login,

            generate_password_hash(
                senha
            ),

            int(
                admin
            ),

            plano[
                "plano_nome"
            ],

            plano[
                "plano_tipo"
            ],

            plano[
                "plano_valor_centavos"
            ],

            plano[
                "plano_inicio"
            ],

            plano[
                "plano_vencimento"
            ],

            plano[
                "plano_status"
            ],

            plano[
                "plano_observacao"
            ],
        )
    ).lastrowid



def conta_gerenciavel(
    conn,
    usuario_id
):

    usuario = conn.execute(
        """
        SELECT *

        FROM contas

        WHERE id=?
        """,
        (
            usuario_id,
        )
    ).fetchone()

    if not usuario:

        abort(404)

    if usuario[
        "admin"
    ]:

        raise ValueError(
            "Contas administradoras não podem ser alteradas por este painel."
        )

    return usuario

