"""Plan validation, billing dates, and account access eligibility."""

from datetime import datetime

from flask import request

from meufiado.utils import adicionar_meses, data_valida, valor_nao_negativo


def status_plano(usuario):

    if usuario["admin"]:
        return "admin"

    if not usuario["ativo"]:
        return "inativo"

    if usuario["plano_status"] != "ativo":

        return (
            usuario["plano_status"]
            or "suspenso"
        )

    vencimento = usuario[
        "plano_vencimento"
    ]

    if vencimento:

        try:

            if datetime.strptime(
                vencimento,
                "%Y-%m-%d"
            ).date() < datetime.now().date():

                return "vencido"

        except ValueError:

            return "vencido"

    return "ativo"



def plano_liberado(usuario):

    return (
        bool(
            usuario["admin"]
        )
        or status_plano(
            usuario
        ) == "ativo"
    )



def validar_plano_form():

    tipos = {
        "unico",
        "mensal",
        "anual"
    }

    estados = {
        "ativo",
        "suspenso"
    }

    tipo = request.form.get(
        "plano_tipo",
        "mensal"
    ).strip().lower()

    if tipo not in tipos:

        raise ValueError(
            "Tipo de cobrança inválido."
        )

    estado = request.form.get(
        "plano_status",
        "ativo"
    ).strip().lower()

    if estado not in estados:

        raise ValueError(
            "Status do plano inválido."
        )

    nome = " ".join(
        request.form.get(
            "plano_nome",
            ""
        ).split()
    )[:60]

    if not nome:

        nome = {
            "unico": "Vitalício",
            "mensal": "Mensal",
            "anual": "Anual"
        }[tipo]

    valor_centavos = valor_nao_negativo(
        request.form.get(
            "plano_valor",
            "0"
        )
    )

    inicio_txt = request.form.get(
        "plano_inicio",
        ""
    ).strip()

    if inicio_txt:

        inicio = datetime.strptime(
            data_valida(
                inicio_txt
            ),
            "%Y-%m-%d"
        ).date()

    else:

        inicio = datetime.now().date()

    vencimento_txt = request.form.get(
        "plano_vencimento",
        ""
    ).strip()

    if tipo == "unico":

        vencimento = None

    elif vencimento_txt:

        vencimento = data_valida(
            vencimento_txt
        )

    else:

        meses = (
            1
            if tipo == "mensal"
            else 12
        )

        vencimento = adicionar_meses(
            inicio,
            meses
        ).strftime(
            "%Y-%m-%d"
        )

    if (
        vencimento
        and vencimento
        < inicio.strftime(
            "%Y-%m-%d"
        )
    ):

        raise ValueError(
            "O vencimento não pode ser anterior ao início do plano."
        )

    observacao = request.form.get(
        "plano_observacao",
        ""
    ).strip()[:300]

    return {

        "plano_nome":
            nome,

        "plano_tipo":
            tipo,

        "plano_valor_centavos":
            valor_centavos,

        "plano_inicio":
            inicio.strftime(
                "%Y-%m-%d"
            ),

        "plano_vencimento":
            vencimento,

        "plano_status":
            estado,

        "plano_observacao":
            observacao,

    }

