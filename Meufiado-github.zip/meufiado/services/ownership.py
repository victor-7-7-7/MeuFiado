"""Account-scoped lookups that reject access to another account's records."""

from flask import abort, g


def meu_cliente(
    conn,
    cliente_id
):

    cliente = conn.execute(
        """
        SELECT *

        FROM clientes

        WHERE id=?
          AND usuario_id=?
        """,
        (
            cliente_id,
            g.usuario[
                "id"
            ]
        )
    ).fetchone()

    if not cliente:

        abort(404)

    return cliente



def meu_produto(
    conn,
    produto_id
):

    produto = conn.execute(
        """
        SELECT *

        FROM produtos

        WHERE id=?
          AND usuario_id=?
          AND ativo=1
        """,
        (
            produto_id,
            g.usuario[
                "id"
            ]
        )
    ).fetchone()

    if not produto:

        abort(404)

    return produto



def meu_fornecedor(
    conn,
    fornecedor_id
):

    fornecedor = conn.execute(
        """
        SELECT *

        FROM fornecedores

        WHERE id=?
          AND usuario_id=?
          AND ativo=1
        """,
        (
            fornecedor_id,
            g.usuario[
                "id"
            ]
        )
    ).fetchone()

    if not fornecedor:

        abort(404)

    return fornecedor

