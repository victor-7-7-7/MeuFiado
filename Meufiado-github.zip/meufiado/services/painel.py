"""Dashboard queries restricted to the authenticated account."""

from flask import g


def dados_painel(conn):

    uid = g.usuario[
        "id"
    ]

    pendentes = conn.execute(
        """
        SELECT

            c.id,

            c.nome,

            MIN(
                CASE
                    WHEN v.status='fiado'
                    THEN v.data
                END
            ) AS primeira_compra,

            ROUND(
                SUM(
                    CASE
                        WHEN v.status='fiado'
                        THEN v.valor

                        ELSE -v.valor
                    END
                ),
                2
            ) AS saldo

        FROM clientes c

        JOIN vendas v
            ON c.id=v.cliente_id

        WHERE c.usuario_id=?
          AND v.status IN (
              'fiado',
              'abatimento'
          )

        GROUP BY c.id

        HAVING saldo > 0

        ORDER BY
            primeira_compra ASC,
            c.nome COLLATE NOCASE
        """,
        (
            uid,
        )
    ).fetchall()


    compras_quitadas = conn.execute(
        """
        SELECT COUNT(*)

        FROM vendas v

        JOIN clientes c
            ON c.id=v.cliente_id

        WHERE c.usuario_id=?
          AND v.status='pago'
          AND v.produto != 'Pagamento Parcial'
        """,
        (
            uid,
        )
    ).fetchone()[0]


    return {

        "clientes_ativos":

            conn.execute(
                """
                SELECT COUNT(*)

                FROM clientes

                WHERE usuario_id=?
                """,
                (
                    uid,
                )
            ).fetchone()[0],


        "fiados_abertos":

            conn.execute(
                """
                SELECT COUNT(*)

                FROM vendas v

                JOIN clientes c
                    ON c.id=v.cliente_id

                WHERE c.usuario_id=?
                  AND v.status='fiado'
                """,
                (
                    uid,
                )
            ).fetchone()[0],


        "compras_quitadas":
            compras_quitadas,


        "a_receber":

            sum(
                p[
                    "saldo"
                ]
                for p in pendentes
            ),


        "pendentes":
            pendentes[:5],


        "quantidade_pendentes":
            len(
                pendentes
            ),

    }

