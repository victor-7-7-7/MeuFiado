"""Account-scoped debt balances and cash receipts within payment transactions."""

from datetime import datetime

from flask import g


def saldo_cliente(
    conn,
    cliente_id
):

    return conn.execute(
        """
        SELECT ROUND(

            COALESCE(

                SUM(

                    CASE

                        WHEN v.status='fiado'
                        THEN v.valor

                        ELSE -v.valor

                    END

                ),

                0

            ),

            2

        )

        FROM vendas v

        JOIN clientes c
            ON c.id=v.cliente_id

        WHERE c.usuario_id=?
          AND c.id=?
          AND v.status IN (
              'fiado',
              'abatimento'
          )
        """,
        (
            g.usuario[
                "id"
            ],
            cliente_id
        )
    ).fetchone()[0]



def registrar_recebimento(
    conn,
    cliente,
    valor_centavos,
    descricao
):

    conn.execute(
        """
        INSERT INTO caixa_movimentos (

            usuario_id,

            tipo,

            descricao,

            valor_centavos,

            data,

            origem,

            cliente_id

        )

        VALUES (
            ?,
            'entrada',
            ?,
            ?,
            ?,
            'fiado',
            ?
        )
        """,
        (
            g.usuario[
                "id"
            ],

            (
                f"{descricao} — "
                f"{cliente['nome']}"
            ),

            valor_centavos,

            datetime.now().strftime(
                "%Y-%m-%d"
            ),

            cliente[
                "id"
            ]
        )
    )

