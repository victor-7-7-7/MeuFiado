﻿"""Flask application factory for MeuFiado."""

from flask import Flask

from .config import BASE_DIR, default_config
from .database import init_db
from .filters import register_filters
from .security import register_security


def create_app(config=None):
    """Create an independent app, keeping the existing startup initialization.

    Optional settings allow tests to use isolated databases. Importing this
    package alone does not create an app or open a database.
    """
    app = Flask("app", root_path=str(BASE_DIR))
    app.config.update(default_config())
    if config is not None:
        app.config.update(config)

    # Imports stay here so the factory owns application registration.
    from .cli import register_commands
    from .routes import register_routes

    register_filters(app)
    register_security(app)
    register_routes(app)
    register_commands(app)

    with app.app_context():
        init_db()

    # init_db retains the environment/database-backed secret for normal startup.
    if config is not None and config.get("SECRET_KEY"):
        app.config["SECRET_KEY"] = config["SECRET_KEY"]

    return app
