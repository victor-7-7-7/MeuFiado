"""Global session, plan access, CSRF, authorization, and response protections."""

from functools import wraps
import secrets
import urllib.parse

from flask import abort, g, redirect, request, session, url_for

from meufiado.database import banco
from meufiado.services.planos import plano_liberado


def csrf_token():

    if "csrf_token" not in session:

        session[
            "csrf_token"
        ] = secrets.token_urlsafe(
            32
        )

    return session[
        "csrf_token"
    ]



def contexto_conta():

    return dict(
        usuario_atual=g.get(
            "usuario"
        ),
        csrf_token=csrf_token
    )



def admin_required(view):

    @wraps(view)
    def wrapped(
        *args,
        **kwargs
    ):

        if not g.usuario[
            "admin"
        ]:

            abort(403)

        return view(
            *args,
            **kwargs
        )

    return wrapped



def proteger_acesso():

    g.usuario = None

    if request.endpoint == "static":
        return

    if session.get(
        "usuario_id"
    ):

        with banco() as conn:

            usuario = conn.execute(
                """
                SELECT *
                FROM contas

                WHERE id=?
                  AND ativo=1
                """,
                (
                    session[
                        "usuario_id"
                    ],
                )
            ).fetchone()

        if (
            usuario
            and session.get(
                "versao_sessao"
            )
            == usuario[
                "versao_sessao"
            ]
            and plano_liberado(
                usuario
            )
        ):

            g.usuario = usuario

        else:

            session.clear()

    if (
        request.endpoint
        not in (
            "login",
            "landing"
        )
        and not g.usuario
    ):

        if (
            request.method
            not in (
                "GET",
                "HEAD"
            )
            or request.path
            == "/painel/resumo"
        ):

            return (
                "Sua sessão terminou. Entre novamente em /login.",
                401
            )

        return redirect(
            url_for(
                "login"
            )
        )

    if request.method in (
        "POST",
        "PUT",
        "PATCH",
        "DELETE"
    ):

        token = (
            request.form.get(
                "csrf_token"
            )
            or request.headers.get(
                "X-CSRFToken"
            )
        )

        esperado = session.get(
            "csrf_token",
            ""
        )

        if token:

            valido = (
                bool(
                    esperado
                )
                and secrets.compare_digest(
                    token.encode(),
                    esperado.encode()
                )
            )

        else:

            origem = (
                request.headers.get(
                    "Origin"
                )
                or request.headers.get(
                    "Referer",
                    ""
                )
            )

            try:

                recebido = urllib.parse.urlsplit(
                    origem
                )

                local = urllib.parse.urlsplit(
                    request.host_url
                )

                valido = (
                    bool(
                        origem
                    )
                    and (
                        recebido.scheme,
                        recebido.netloc
                    )
                    == (
                        local.scheme,
                        local.netloc
                    )
                )

            except ValueError:

                valido = False

        if (
            not valido
            or request.headers.get(
                "Sec-Fetch-Site"
            ) == "cross-site"
        ):

            return (
                "Solicitação inválida. Atualize a página e tente novamente.",
                400
            )



def proteger_resposta(response):

    if request.endpoint != "static":

        response.headers[
            "Cache-Control"
        ] = "no-store"

        response.headers[
            "Vary"
        ] = "Cookie"

    response.headers[
        "X-Content-Type-Options"
    ] = "nosniff"

    response.headers[
        "X-Frame-Options"
    ] = "SAMEORIGIN"

    response.headers[
        "Referrer-Policy"
    ] = "same-origin"

    return response



def register_security(app):
    """Install account context and global protections for every route."""
    app.context_processor(contexto_conta)
    app.before_request(proteger_acesso)
    app.after_request(proteger_resposta)
