"""Account management and explicit legacy-data assignment commands."""

from flask.cli import with_appcontext
from werkzeug.security import generate_password_hash
import click

from meufiado.database import banco
from meufiado.services.contas import criar_conta, validar_conta


@click.command('criar-usuario')
@click.option(
    "--nome",
    prompt="Nome"
)
@click.option(
    "--login",
    "nome_login",
    prompt="Login"
)
@click.option(
    "--senha",
    prompt="Senha (mínimo 8 caracteres)",
    hide_input=True,
    confirmation_prompt=True
)
@click.option(
    "--admin",
    is_flag=True,
    help=(
        "Permite criar outras contas; "
        "não dá acesso aos seus fiados."
    )
)
@with_appcontext
def criar_usuario_cli(
    nome,
    nome_login,
    senha,
    admin
):

    try:

        with banco(
            escrita=True
        ) as conn:

            criar_conta(
                conn,
                nome,
                nome_login,
                senha,
                admin
            )

    except ValueError as exc:

        raise click.ClickException(
            str(
                exc
            )
        ) from exc


    click.echo(
        "Conta criada com sucesso."
    )



@click.command('atribuir-dados-antigos')
@click.option(
    "--login",
    "nome_login",
    required=True,
    help=(
        "Conta que será dona de TODOS "
        "os clientes antigos sem dono."
    )
)
@click.option(
    "--confirmar",
    is_flag=True,
    help=(
        "Confirma a atribuição dos dados "
        "antigos à conta escolhida."
    )
)
@with_appcontext
def atribuir_dados_antigos_cli(
    nome_login,
    confirmar
):

    if not confirmar:

        raise click.ClickException(
            "Revise o login de destino e repita com --confirmar."
        )


    with banco(
        escrita=True
    ) as conn:

        usuario = conn.execute(
            """
            SELECT id

            FROM contas

            WHERE login=?
            """,
            (
                nome_login
                .strip()
                .lower(),
            )
        ).fetchone()


        if not usuario:

            raise click.ClickException(
                "Conta não encontrada. Crie a conta primeiro."
            )


        total = conn.execute(
            """
            UPDATE clientes

            SET usuario_id=?

            WHERE usuario_id IS NULL
            """,
            (
                usuario[
                    "id"
                ],
            )
        ).rowcount


    click.echo(
        f"{total} cliente(s) antigo(s) vinculado(s). "
        "O histórico de fiados foi preservado."
    )



@click.command('redefinir-senha')
@click.option(
    "--login",
    "nome_login",
    required=True
)
@click.option(
    "--senha",
    prompt="Nova senha",
    hide_input=True,
    confirmation_prompt=True
)
@with_appcontext
def redefinir_senha_cli(
    nome_login,
    senha
):

    with banco(
        escrita=True
    ) as conn:

        usuario = conn.execute(
            """
            SELECT *

            FROM contas

            WHERE login=?
            """,
            (
                nome_login
                .strip()
                .lower(),
            )
        ).fetchone()


        if not usuario:

            raise click.ClickException(
                "Conta não encontrada."
            )


        try:

            validar_conta(
                usuario[
                    "nome"
                ],
                usuario[
                    "login"
                ],
                senha
            )

        except ValueError as exc:

            raise click.ClickException(
                str(
                    exc
                )
            ) from exc


        conn.execute(
            """
            UPDATE contas

            SET
                senha_hash=?,

                versao_sessao=
                    versao_sessao + 1

            WHERE id=?
            """,
            (
                generate_password_hash(
                    senha
                ),

                usuario[
                    "id"
                ]
            )
        )


    click.echo(
        "Senha atualizada. Faça login novamente."
    )



def register_commands(app):
    app.cli.add_command(criar_usuario_cli)
    app.cli.add_command(atribuir_dados_antigos_cli)
    app.cli.add_command(redefinir_senha_cli)
