﻿"""Tax and employee expense pages using the application's global security hooks."""

from datetime import datetime
from decimal import Decimal
import secrets

from flask import flash, g, redirect, render_template, request, url_for

from meufiado.database import banco
from meufiado.services.despesas import (
    TIPOS_FUNCIONARIOS, atualizar_despesa, criar_lancamentos,
    excluir_despesa as excluir_registro, linhas_formulario, listar_despesas,
    listar_funcionarios, obter_despesa, obter_funcionario, resumo_funcionarios,
    resumo_mes, validar_chave_envio, validar_lancamentos,
)
from meufiado.utils import centavos, mes_valido, valor_positivo


MESES = ('Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
         'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro')


def _endpoint(categoria):
    return 'despesas_impostos' if categoria == 'imposto' else 'despesas_funcionarios'


def _mes_selecionado():
    return mes_valido(request.args.get('mes', datetime.now().strftime('%Y-%m')))


def _pagina(categoria, mes, *, editando=None, formulario=None, erro=None, status=200):
    hoje = datetime.now().strftime('%Y-%m-%d')
    with banco() as conn:
        if formulario is None:
            if editando is not None:
                formulario = dict(editando)
                formulario['valor'] = f"{Decimal(editando['valor_centavos']) / 100:.2f}"
            else:
                formulario = {'data_pagamento': hoje, 'mes_referencia': mes}
                if categoria == 'funcionario' and request.args.get('funcionario'):
                    funcionario = obter_funcionario(conn, g.usuario['id'], request.args['funcionario'])
                    formulario['funcionario_nome'] = funcionario['nome']
        resumo = resumo_mes(conn, g.usuario['id'], mes)
        registros = listar_despesas(conn, g.usuario['id'], mes, categoria)
        funcionarios = listar_funcionarios(conn, g.usuario['id']) if categoria == 'funcionario' else []
        totais_funcionarios = resumo_funcionarios(conn, g.usuario['id'], mes) if categoria == 'funcionario' else []
    try:
        chave_envio = validar_chave_envio(formulario.get('chave_envio'))
    except ValueError:
        chave_envio = secrets.token_hex(16)
    if hasattr(formulario, 'getlist'):
        linhas = linhas_formulario(formulario)
    else:
        linhas = [{campo: formulario.get(campo, '') for campo in ('descricao', 'valor', 'tipo')}]
    total_previa = 0
    for linha in linhas:
        try:
            total_previa += centavos(valor_positivo(linha['valor'])) if linha['valor'].strip() else 0
        except ValueError:
            total_previa = None
            break
    por_funcionario = {}
    for registro in registros:
        por_funcionario.setdefault(registro['funcionario_id'], []).append(registro)
    grupos = [{**dict(funcionario), 'registros': por_funcionario.get(funcionario['id'], [])}
              for funcionario in totais_funcionarios]
    return render_template(
        'despesas.html', categoria=categoria, mes=mes,
        mes_label=f'{MESES[int(mes[5:])-1]} de {mes[:4]}', hoje=hoje,
        resumo=resumo, registros=registros, formulario=formulario, linhas=linhas,
        tipos=TIPOS_FUNCIONARIOS, editando=editando, erro=erro,
        chave_envio=chave_envio, total_previa=total_previa,
        funcionarios=funcionarios, grupos_funcionarios=grupos,
        endpoint_categoria=_endpoint(categoria),
    ), status


def _erro_filtro(exc):
    return render_template('conta_erro.html', mensagem=str(exc), voltar=url_for('despesas')), 400


def _categoria(categoria):
    try:
        mes = _mes_selecionado()
    except ValueError as exc:
        return _erro_filtro(exc)
    if request.method == 'POST':
        try:
            chave_envio = validar_chave_envio(request.form.get('chave_envio'))
            itens = validar_lancamentos(request.form, categoria)
            with banco(escrita=True) as conn:
                criar_lancamentos(conn, g.usuario['id'], itens, chave_envio)
            flash('Gastos registrados. As saídas correspondentes foram lançadas no Caixa.', 'sucesso')
            return redirect(url_for(_endpoint(categoria), mes=itens[0]['mes_referencia']))
        except ValueError as exc:
            return _pagina(categoria, mes, formulario=request.form, erro=str(exc), status=400)
    return _pagina(categoria, mes)


def despesas():
    return _categoria('imposto')


def despesas_impostos():
    return _categoria('imposto')


def despesas_funcionarios():
    return _categoria('funcionario')


def editar_despesa(despesa_id):
    with banco() as conn:
        despesa = obter_despesa(conn, g.usuario['id'], despesa_id)
    categoria = despesa['categoria']
    if request.method == 'POST':
        try:
            itens = validar_lancamentos(request.form, categoria)
            if len(itens) != 1:
                raise ValueError('Edite um gasto por vez. Para adicionar gastos, use o formulário de cadastro.')
            dados = itens[0]
            with banco(escrita=True) as conn:
                atualizar_despesa(conn, g.usuario['id'], despesa_id, dados)
            flash('Gasto e saída do Caixa atualizados.', 'sucesso')
            return redirect(url_for(_endpoint(categoria), mes=dados['mes_referencia']))
        except ValueError as exc:
            return _pagina(categoria, despesa['mes_referencia'], editando=despesa,
                           formulario=request.form, erro=str(exc), status=400)
    return _pagina(categoria, despesa['mes_referencia'], editando=despesa)


def excluir_despesa(despesa_id):
    with banco(escrita=True) as conn:
        despesa = obter_despesa(conn, g.usuario['id'], despesa_id)
        categoria, mes = despesa['categoria'], despesa['mes_referencia']
        excluir_registro(conn, g.usuario['id'], despesa_id)
    flash('Gasto e saída correspondente do Caixa excluídos.', 'sucesso')
    return redirect(url_for(_endpoint(categoria), mes=mes))


def register_routes(app):
    app.add_url_rule('/despesas', endpoint='despesas', view_func=despesas)
    app.add_url_rule('/despesas/impostos', endpoint='despesas_impostos',
                     view_func=despesas_impostos, methods=['GET', 'POST'])
    app.add_url_rule('/despesas/funcionarios', endpoint='despesas_funcionarios',
                     view_func=despesas_funcionarios, methods=['GET', 'POST'])
    app.add_url_rule('/despesas/<int:despesa_id>/editar', endpoint='editar_despesa',
                     view_func=editar_despesa, methods=['GET', 'POST'])
    app.add_url_rule('/despesas/<int:despesa_id>/excluir', endpoint='excluir_despesa',
                     view_func=excluir_despesa, methods=['POST'])
