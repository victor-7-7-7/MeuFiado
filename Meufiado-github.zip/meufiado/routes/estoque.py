"""Product registration, editing, and inventory soft deletion routes."""

from flask import flash, g, redirect, render_template, request, url_for

from meufiado.database import banco
from meufiado.services.ownership import meu_produto
from meufiado.utils import (
    centavos,
    dinheiro_nao_negativo,
    inteiro_nao_negativo,
    valor_positivo,
)


def estoque():

    uid = g.usuario[
        "id"
    ]


    # cadastrar


    if request.method == "POST":

        try:

            nome = " ".join(
                request.form.get(
                    "nome",
                    ""
                ).split()
            )


            categoria = " ".join(
                request.form.get(
                    "categoria",
                    ""
                ).split()
            )[:100]


            if not nome:

                raise ValueError(
                    "Informe o nome do produto."
                )


            if len(nome) > 150:

                raise ValueError(
                    "O nome do produto deve ter até 150 caracteres."
                )


            preco_custo = dinheiro_nao_negativo(
                request.form.get(
                    "preco_custo",
                    "0"
                ),
                "Preço de custo"
            )


            preco_venda = centavos(
                valor_positivo(
                    request.form.get(
                        "preco_venda"
                    )
                )
            )


            quantidade = inteiro_nao_negativo(
                request.form.get(
                    "quantidade",
                    0
                ),
                "Quantidade"
            )


            estoque_minimo = inteiro_nao_negativo(
                request.form.get(
                    "estoque_minimo",
                    0
                ),
                "Estoque mínimo"
            )


            with banco(
                escrita=True
            ) as conn:

                existente = conn.execute(
                    """
                    SELECT id

                    FROM produtos

                    WHERE usuario_id=?
                      AND ativo=1

                      AND LOWER(
                          TRIM(nome)
                      )
                      =
                      LOWER(
                          TRIM(?)
                      )
                    """,
                    (
                        uid,
                        nome
                    )
                ).fetchone()


                if existente:

                    raise ValueError(
                        "Já existe um produto com este nome."
                    )


                conn.execute(
                    """
                    INSERT INTO produtos (

                        usuario_id,

                        nome,

                        categoria,

                        preco_custo_centavos,

                        preco_venda_centavos,

                        quantidade,

                        estoque_minimo

                    )

                    VALUES (
                        ?, ?, ?, ?, ?, ?, ?
                    )
                    """,
                    (
                        uid,

                        nome,

                        categoria,

                        preco_custo,

                        preco_venda,

                        quantidade,

                        estoque_minimo
                    )
                )


            flash(
                "Produto cadastrado com sucesso.",
                "sucesso"
            )


            return redirect(
                url_for(
                    "estoque"
                )
            )


        except ValueError as exc:

            flash(
                str(
                    exc
                ),
                "erro"
            )


            return redirect(
                url_for(
                    "estoque"
                )
            )


    # listar


    with banco() as conn:

        registros = conn.execute(
            """
            SELECT *

            FROM produtos

            WHERE usuario_id=?
              AND ativo=1

            ORDER BY nome COLLATE NOCASE
            """,
            (
                uid,
            )
        ).fetchall()


    produtos = []


    for registro in registros:

        produto = dict(
            registro
        )


        produto[
            "preco_custo"
        ] = (
            produto[
                "preco_custo_centavos"
            ]
            / 100
        )


        produto[
            "preco_venda"
        ] = (
            produto[
                "preco_venda_centavos"
            ]
            / 100
        )


        produtos.append(
            produto
        )


    total_produtos = len(
        produtos
    )


    total_unidades = sum(
        produto[
            "quantidade"
        ]
        for produto in produtos
    )


    produtos_baixos = sum(
        produto[
            "quantidade"
        ]
        <= produto[
            "estoque_minimo"
        ]
        for produto in produtos
    )


    valor_estoque_centavos = sum(

        produto[
            "preco_custo_centavos"
        ]
        *
        produto[
            "quantidade"
        ]

        for produto in produtos

    )


    return render_template(

        "estoque.html",

        produtos=produtos,

        total_produtos=
            total_produtos,

        total_unidades=
            total_unidades,

        produtos_baixos=
            produtos_baixos,

        valor_estoque=(
            valor_estoque_centavos
            / 100
        )

    )



def editar_produto(
    produto_id
):

    try:

        nome = " ".join(
            request.form.get(
                "nome",
                ""
            ).split()
        )


        categoria = " ".join(
            request.form.get(
                "categoria",
                ""
            ).split()
        )[:100]


        if not nome:

            raise ValueError(
                "Informe o nome do produto."
            )


        if len(nome) > 150:

            raise ValueError(
                "O nome do produto deve ter até 150 caracteres."
            )


        preco_custo = dinheiro_nao_negativo(
            request.form.get(
                "preco_custo",
                "0"
            ),
            "Preço de custo"
        )


        preco_venda = centavos(
            valor_positivo(
                request.form.get(
                    "preco_venda"
                )
            )
        )


        quantidade = inteiro_nao_negativo(
            request.form.get(
                "quantidade",
                0
            ),
            "Quantidade"
        )


        estoque_minimo = inteiro_nao_negativo(
            request.form.get(
                "estoque_minimo",
                0
            ),
            "Estoque mínimo"
        )


        with banco(
            escrita=True
        ) as conn:

            meu_produto(
                conn,
                produto_id
            )


            duplicado = conn.execute(
                """
                SELECT id

                FROM produtos

                WHERE usuario_id=?

                  AND id<>?

                  AND ativo=1

                  AND LOWER(
                      TRIM(nome)
                  )
                  =
                  LOWER(
                      TRIM(?)
                  )
                """,
                (
                    g.usuario[
                        "id"
                    ],

                    produto_id,

                    nome
                )
            ).fetchone()


            if duplicado:

                raise ValueError(
                    "Já existe outro produto com este nome."
                )


            conn.execute(
                """
                UPDATE produtos

                SET
                    nome=?,

                    categoria=?,

                    preco_custo_centavos=?,

                    preco_venda_centavos=?,

                    quantidade=?,

                    estoque_minimo=?,

                    atualizado_em=
                        CURRENT_TIMESTAMP

                WHERE id=?
                  AND usuario_id=?
                """,
                (
                    nome,

                    categoria,

                    preco_custo,

                    preco_venda,

                    quantidade,

                    estoque_minimo,

                    produto_id,

                    g.usuario[
                        "id"
                    ]
                )
            )


        flash(
            "Produto atualizado.",
            "sucesso"
        )


    except ValueError as exc:

        flash(
            str(
                exc
            ),
            "erro"
        )


    return redirect(
        url_for(
            "estoque"
        )
    )



def excluir_produto(
    produto_id
):

    with banco(
        escrita=True
    ) as conn:

        meu_produto(
            conn,
            produto_id
        )


        conn.execute(
            """
            UPDATE produtos

            SET
                ativo=0,

                atualizado_em=
                    CURRENT_TIMESTAMP

            WHERE id=?
              AND usuario_id=?
            """,
            (
                produto_id,

                g.usuario[
                    "id"
                ]
            )
        )


    flash(
        "Produto removido.",
        "sucesso"
    )


    return redirect(
        url_for(
            "estoque"
        )
    )



def register_routes(app):
    """Keep the original URLs, endpoint names, and methods."""
    app.add_url_rule('/estoque', methods=['GET', 'POST'], endpoint="estoque", view_func=estoque)
    app.add_url_rule('/estoque/produto/<int:produto_id>/editar', methods=['POST'], endpoint="editar_produto", view_func=editar_produto)
    app.add_url_rule('/estoque/produto/<int:produto_id>/excluir', methods=['POST'], endpoint="excluir_produto", view_func=excluir_produto)
