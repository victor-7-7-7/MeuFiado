"""Administrator-only account creation, plans, passwords, and access management."""

from datetime import datetime

from flask import flash, redirect, render_template, request, url_for
from werkzeug.security import generate_password_hash

from meufiado.database import banco
from meufiado.security import admin_required
from meufiado.services.contas import conta_gerenciavel, criar_conta, validar_conta
from meufiado.services.planos import status_plano, validar_plano_form


@admin_required
def contas():

    erro = None
    status = 200

    if request.method == "POST":

        try:

            plano = validar_plano_form()

            with banco(
                escrita=True
            ) as conn:

                criar_conta(
                    conn,
                    request.form.get(
                        "nome",
                        ""
                    ),
                    request.form.get(
                        "login",
                        ""
                    ),
                    request.form.get(
                        "senha",
                        ""
                    ),
                    plano=plano
                )

            flash(
                "Cliente criado com o plano configurado.",
                "sucesso"
            )

            return redirect(
                url_for(
                    "contas"
                )
            )

        except (
            ValueError,
            TypeError
        ) as exc:

            erro = str(
                exc
            )

            status = 400

    with banco() as conn:

        registros = conn.execute(
            """
            SELECT
                c.*,

                (
                    SELECT COUNT(*)

                    FROM clientes cl

                    WHERE cl.usuario_id=c.id

                ) AS qtd_clientes,

                (
                    SELECT COUNT(*)

                    FROM vendas v

                    JOIN clientes cl2
                        ON cl2.id=v.cliente_id

                    WHERE cl2.usuario_id=c.id

                ) AS qtd_movimentos

            FROM contas c

            ORDER BY
                c.admin DESC,
                c.nome COLLATE NOCASE
            """
        ).fetchall()

        antigos = conn.execute(
            """
            SELECT COUNT(*)

            FROM clientes

            WHERE usuario_id IS NULL
            """
        ).fetchone()[0]


    lista = []

    for registro in registros:

        item = dict(
            registro
        )

        item[
            "status_real"
        ] = status_plano(
            registro
        )

        item[
            "plano_valor"
        ] = (
            item[
                "plano_valor_centavos"
            ]
            or 0
        ) / 100

        lista.append(
            item
        )


    clientes_planos = [
        c
        for c in lista
        if not c[
            "admin"
        ]
    ]


    resumo = {

        "total_clientes":
            len(
                clientes_planos
            ),

        "planos_ativos":
            sum(
                c[
                    "status_real"
                ] == "ativo"
                for c in clientes_planos
            ),

        "planos_vencidos":
            sum(
                c[
                    "status_real"
                ] == "vencido"
                for c in clientes_planos
            ),

        "planos_suspensos":
            sum(
                c[
                    "status_real"
                ] in (
                    "suspenso",
                    "inativo"
                )
                for c in clientes_planos
            ),

        "receita_mensal":
            sum(
                c[
                    "plano_valor"
                ]
                for c in clientes_planos
                if (
                    c[
                        "status_real"
                    ] == "ativo"
                    and c[
                        "plano_tipo"
                    ] == "mensal"
                )
            ),

        "receita_anual":
            sum(
                c[
                    "plano_valor"
                ]
                for c in clientes_planos
                if (
                    c[
                        "status_real"
                    ] == "ativo"
                    and c[
                        "plano_tipo"
                    ] == "anual"
                )
            ),

    }


    return (
        render_template(
            "conta_usuarios.html",

            contas=lista,

            antigos=antigos,

            erro=erro,

            resumo=resumo,

            hoje=datetime.now().strftime(
                "%Y-%m-%d"
            )
        ),

        status
    )



@admin_required
def admin_alterar_senha(
    usuario_id
):

    nova_senha = request.form.get(
        "senha",
        ""
    )

    with banco(
        escrita=True
    ) as conn:

        try:

            usuario = conta_gerenciavel(
                conn,
                usuario_id
            )

            validar_conta(
                usuario[
                    "nome"
                ],
                usuario[
                    "login"
                ],
                nova_senha
            )

            conn.execute(
                """
                UPDATE contas

                SET
                    senha_hash=?,

                    versao_sessao=
                        versao_sessao + 1

                WHERE id=?
                """,
                (
                    generate_password_hash(
                        nova_senha
                    ),
                    usuario_id
                )
            )

        except ValueError as exc:

            flash(
                str(
                    exc
                ),
                "erro"
            )

            return redirect(
                url_for(
                    "contas"
                )
            )

    flash(
        "Senha alterada. As sessões anteriores desse cliente foram encerradas.",
        "sucesso"
    )

    return redirect(
        url_for(
            "contas"
        )
    )



@admin_required
def admin_editar_plano(
    usuario_id
):

    try:

        plano = validar_plano_form()

        with banco(
            escrita=True
        ) as conn:

            conta_gerenciavel(
                conn,
                usuario_id
            )

            conn.execute(
                """
                UPDATE contas

                SET
                    plano_nome=?,
                    plano_tipo=?,
                    plano_valor_centavos=?,
                    plano_inicio=?,
                    plano_vencimento=?,
                    plano_status=?,
                    plano_observacao=?

                WHERE id=?
                """,
                (
                    plano[
                        "plano_nome"
                    ],

                    plano[
                        "plano_tipo"
                    ],

                    plano[
                        "plano_valor_centavos"
                    ],

                    plano[
                        "plano_inicio"
                    ],

                    plano[
                        "plano_vencimento"
                    ],

                    plano[
                        "plano_status"
                    ],

                    plano[
                        "plano_observacao"
                    ],

                    usuario_id
                )
            )

        flash(
            "Plano atualizado.",
            "sucesso"
        )

    except (
        ValueError,
        TypeError
    ) as exc:

        flash(
            str(
                exc
            ),
            "erro"
        )

    return redirect(
        url_for(
            "contas"
        )
    )



@admin_required
def admin_alternar_usuario(
    usuario_id
):

    try:

        with banco(
            escrita=True
        ) as conn:

            usuario = conta_gerenciavel(
                conn,
                usuario_id
            )

            novo_status = (
                0
                if usuario[
                    "ativo"
                ]
                else 1
            )

            conn.execute(
                """
                UPDATE contas

                SET
                    ativo=?,

                    versao_sessao=
                        versao_sessao + 1

                WHERE id=?
                """,
                (
                    novo_status,
                    usuario_id
                )
            )

        flash(
            (
                "Acesso do cliente ativado."
                if novo_status
                else
                "Acesso do cliente desativado."
            ),
            "sucesso"
        )

    except ValueError as exc:

        flash(
            str(
                exc
            ),
            "erro"
        )

    return redirect(
        url_for(
            "contas"
        )
    )



@admin_required
def admin_excluir_usuario(
    usuario_id
):

    try:

        with banco(
            escrita=True
        ) as conn:

            usuario = conta_gerenciavel(
                conn,
                usuario_id
            )

            conn.execute(
                """
                DELETE FROM vendas

                WHERE cliente_id IN (

                    SELECT id

                    FROM clientes

                    WHERE usuario_id=?

                )
                """,
                (
                    usuario_id,
                )
            )

            conn.execute(
                """
                DELETE FROM caixa_movimentos
                WHERE usuario_id=?
                """,
                (
                    usuario_id,
                )
            )

            conn.execute(
                """
                DELETE FROM clientes
                WHERE usuario_id=?
                """,
                (
                    usuario_id,
                )
            )

            conn.execute(
                """
                DELETE FROM tentativas_login
                WHERE login=?
                """,
                (
                    usuario[
                        "login"
                    ],
                )
            )

            conn.execute(
                """
                DELETE FROM contas
                WHERE id=?
                """,
                (
                    usuario_id,
                )
            )

        flash(
            "Cliente e todos os dados da conta foram excluídos permanentemente.",
            "sucesso"
        )

    except ValueError as exc:

        flash(
            str(
                exc
            ),
            "erro"
        )

    return redirect(
        url_for(
            "contas"
        )
    )



def register_routes(app):
    """Keep the original URLs, endpoint names, and methods."""
    app.add_url_rule('/admin', methods=['GET', 'POST'], endpoint="contas", view_func=contas)
    app.add_url_rule('/contas', methods=['GET', 'POST'], endpoint="contas", view_func=contas)
    app.add_url_rule('/admin/usuario/<int:usuario_id>/senha', methods=['POST'], endpoint="admin_alterar_senha", view_func=admin_alterar_senha)
    app.add_url_rule('/admin/usuario/<int:usuario_id>/plano', methods=['POST'], endpoint="admin_editar_plano", view_func=admin_editar_plano)
    app.add_url_rule('/admin/usuario/<int:usuario_id>/status', methods=['POST'], endpoint="admin_alternar_usuario", view_func=admin_alternar_usuario)
    app.add_url_rule('/admin/usuario/<int:usuario_id>/excluir', methods=['POST'], endpoint="admin_excluir_usuario", view_func=admin_excluir_usuario)
