"""Atomic sales processing across inventory, sale items, cash, and credit debts."""

from datetime import datetime
import json

from flask import g, jsonify, render_template, request

from meufiado.database import banco
from meufiado.services.ownership import meu_cliente, meu_produto


def vendas_negocio():

    uid = g.usuario[
        "id"
    ]


    # finalizar venda


    if request.method == "POST":

        dados = request.get_json(
            silent=True
        )


        if not dados:

            dados = request.form.to_dict()

            try:

                dados[
                    "itens"
                ] = json.loads(
                    request.form.get(
                        "itens",
                        "[]"
                    )
                )

            except (
                TypeError,
                ValueError,
                json.JSONDecodeError
            ):

                dados[
                    "itens"
                ] = []


        forma_pagamento = str(
            dados.get(
                "forma_pagamento",
                ""
            )
        ).strip().lower()


        cliente_id = dados.get(
            "cliente_id"
        )


        itens = (
            dados.get(
                "itens"
            )
            or []
        )


        if forma_pagamento not in (
            "avista",
            "fiado"
        ):

            return (
                jsonify(
                    erro=(
                        "Forma de pagamento inválida."
                    )
                ),
                400
            )


        if (
            not isinstance(
                itens,
                list
            )
            or not itens
        ):

            return (
                jsonify(
                    erro=(
                        "Adicione pelo menos um produto."
                    )
                ),
                400
            )


        if forma_pagamento == "fiado":

            try:

                cliente_id = int(
                    cliente_id
                )

            except (
                TypeError,
                ValueError
            ):

                return (
                    jsonify(
                        erro=(
                            "Selecione um cliente para vender no fiado."
                        )
                    ),
                    400
                )


        hoje = datetime.now().strftime(
            "%Y-%m-%d"
        )


        try:

            with banco(
                escrita=True
            ) as conn:


                # cliente


                cliente = None


                if forma_pagamento == "fiado":

                    cliente = meu_cliente(
                        conn,
                        cliente_id
                    )


                # soma produtos iguais


                quantidades = {}


                for item in itens:

                    if not isinstance(
                        item,
                        dict
                    ):

                        raise ValueError(
                            "Há um item inválido na venda."
                        )


                    try:

                        produto_id = int(
                            item.get(
                                "id"
                            )
                        )


                        quantidade = int(
                            item.get(
                                "quantidade",
                                0
                            )
                        )


                    except (
                        TypeError,
                        ValueError
                    ):

                        raise ValueError(
                            "Há um item inválido na venda."
                        )


                    if quantidade <= 0:

                        raise ValueError(
                            "A quantidade precisa ser maior que zero."
                        )


                    quantidades[
                        produto_id
                    ] = (
                        quantidades.get(
                            produto_id,
                            0
                        )
                        +
                        quantidade
                    )


                itens_processados = []

                total_centavos = 0


                # valida estoque / preços


                for (
                    produto_id,
                    quantidade
                ) in quantidades.items():


                    produto = meu_produto(
                        conn,
                        produto_id
                    )


                    if (
                        produto[
                            "quantidade"
                        ]
                        <
                        quantidade
                    ):

                        raise ValueError(
                            f"Estoque insuficiente para "
                            f"{produto['nome']}. "
                            f"Disponível: "
                            f"{produto['quantidade']}."
                        )


                    preco = produto[
                        "preco_venda_centavos"
                    ]


                    if preco <= 0:

                        raise ValueError(
                            f"O produto "
                            f"{produto['nome']} "
                            "não possui preço de venda válido."
                        )


                    total_item = (
                        preco
                        *
                        quantidade
                    )


                    total_centavos += (
                        total_item
                    )


                    itens_processados.append(
                        {

                            "produto":
                                produto,

                            "quantidade":
                                quantidade,

                            "preco":
                                preco,

                            "total":
                                total_item,

                        }
                    )


                if total_centavos <= 0:

                    raise ValueError(
                        "O total da venda é inválido."
                    )


                # registra venda


                venda_id = conn.execute(
                    """
                    INSERT INTO vendas_negocio (

                        usuario_id,

                        cliente_id,

                        forma_pagamento,

                        total_centavos,

                        data

                    )

                    VALUES (
                        ?, ?, ?, ?, ?
                    )
                    """,
                    (
                        uid,

                        (
                            cliente_id
                            if cliente
                            else None
                        ),

                        forma_pagamento,

                        total_centavos,

                        hoje
                    )
                ).lastrowid


                # itens + baixa estoque


                for item in itens_processados:

                    produto = item[
                        "produto"
                    ]


                    conn.execute(
                        """
                        INSERT INTO venda_itens (

                            venda_id,

                            produto_id,

                            produto_nome,

                            quantidade,

                            preco_unitario_centavos,

                            total_centavos

                        )

                        VALUES (
                            ?, ?, ?, ?, ?, ?
                        )
                        """,
                        (
                            venda_id,

                            produto[
                                "id"
                            ],

                            produto[
                                "nome"
                            ],

                            item[
                                "quantidade"
                            ],

                            item[
                                "preco"
                            ],

                            item[
                                "total"
                            ]
                        )
                    )


                    conn.execute(
                        """
                        UPDATE produtos

                        SET
                            quantidade =
                                quantidade - ?,

                            atualizado_em =
                                CURRENT_TIMESTAMP

                        WHERE id=?
                          AND usuario_id=?
                        """,
                        (
                            item[
                                "quantidade"
                            ],

                            produto[
                                "id"
                            ],

                            uid
                        )
                    )


                # venda à vista


                if forma_pagamento == "avista":

                    conn.execute(
                        """
                        INSERT INTO caixa_movimentos (

                            usuario_id,

                            tipo,

                            descricao,

                            valor_centavos,

                            data,

                            origem,

                            venda_negocio_id

                        )

                        VALUES (
                            ?,
                            'entrada',
                            ?,
                            ?,
                            ?,
                            'manual',
                            ?
                        )
                        """,
                        (
                            uid,

                            (
                                f"Venda à vista "
                                f"#{venda_id}"
                            ),

                            total_centavos,

                            hoje,

                            venda_id
                        )
                    )


                # venda fiada


                else:

                    for item in itens_processados:

                        produto = item[
                            "produto"
                        ]


                        descricao = (
                            f"{item['quantidade']}x "
                            f"{produto['nome']}"
                        )


                        conn.execute(
                            """
                            INSERT INTO vendas (

                                cliente_id,

                                data,

                                produto,

                                valor,

                                status

                            )

                            VALUES (
                                ?, ?, ?, ?, 'fiado'
                            )
                            """,
                            (
                                cliente[
                                    "id"
                                ],

                                hoje,

                                descricao,

                                (
                                    item[
                                        "total"
                                    ]
                                    / 100
                                )
                            )
                        )


            return jsonify(

                sucesso=True,

                venda_id=
                    venda_id,

                mensagem=(
                    "Venda registrada com sucesso."
                )

            )


        except ValueError as exc:

            return (
                jsonify(
                    erro=str(
                        exc
                    )
                ),
                400
            )


    # abrir tela de vendas


    with banco() as conn:

        produtos_db = conn.execute(
            """
            SELECT *

            FROM produtos

            WHERE usuario_id=?
              AND ativo=1

            ORDER BY nome COLLATE NOCASE
            """,
            (
                uid,
            )
        ).fetchall()


        clientes = conn.execute(
            """
            SELECT *

            FROM clientes

            WHERE usuario_id=?

            ORDER BY nome COLLATE NOCASE
            """,
            (
                uid,
            )
        ).fetchall()


    produtos = []


    for registro in produtos_db:

        item = dict(
            registro
        )


        item[
            "preco_venda"
        ] = (
            item[
                "preco_venda_centavos"
            ]
            / 100
        )


        produtos.append(
            item
        )


    return render_template(

        "vendas.html",

        produtos=produtos,

        clientes=clientes

    )



def register_routes(app):
    """Keep the original URLs, endpoint names, and methods."""
    app.add_url_rule('/vendas', methods=['GET', 'POST'], endpoint="vendas_negocio", view_func=vendas_negocio)
