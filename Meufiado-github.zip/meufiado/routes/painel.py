"""Public landing page and authenticated dashboard routes."""

from datetime import datetime

from flask import g, jsonify, render_template

from meufiado.database import banco
from meufiado.services.painel import dados_painel


def landing():

    return render_template(
        "landing.html"
    )



def index():

    uid = g.usuario[
        "id"
    ]

    hoje = datetime.now().strftime(
        "%Y-%m-%d"
    )

    with banco() as conn:

        painel = dados_painel(
            conn
        )

        lista = conn.execute(
            """
            SELECT *

            FROM clientes

            WHERE usuario_id=?

            ORDER BY nome COLLATE NOCASE
            """,
            (
                uid,
            )
        ).fetchall()


        produtos_cadastrados = conn.execute(
            """
            SELECT COUNT(*)

            FROM produtos

            WHERE usuario_id=?
              AND ativo=1
            """,
            (
                uid,
            )
        ).fetchone()[0]


        estoque_baixo = conn.execute(
            """
            SELECT COUNT(*)

            FROM produtos

            WHERE usuario_id=?
              AND ativo=1
              AND quantidade <= estoque_minimo
            """,
            (
                uid,
            )
        ).fetchone()[0]


        vendas_hoje = conn.execute(
            """
            SELECT

                COUNT(*) AS quantidade,

                COALESCE(
                    SUM(
                        total_centavos
                    ),
                    0
                ) AS total

            FROM vendas_negocio

            WHERE usuario_id=?
              AND data=?
            """,
            (
                uid,
                hoje
            )
        ).fetchone()


    return render_template(

        "index.html",

        clientes=lista,

        produtos_cadastrados=
            produtos_cadastrados,

        estoque_baixo=
            estoque_baixo,

        vendas_hoje=
            vendas_hoje[
                "quantidade"
            ],

        faturamento_hoje=(
            vendas_hoje[
                "total"
            ]
            / 100
        ),

        **painel
    )



def resumo_painel():

    with banco() as conn:

        painel = dados_painel(
            conn
        )

    return jsonify(
        html=render_template(
            "_painel.html",
            **painel
        )
    )



def register_routes(app):
    """Keep the original URLs, endpoint names, and methods."""
    app.add_url_rule('/', endpoint="landing", view_func=landing)
    app.add_url_rule('/painel', endpoint="index", view_func=index)
    app.add_url_rule('/painel/resumo', endpoint="resumo_painel", view_func=resumo_painel)
