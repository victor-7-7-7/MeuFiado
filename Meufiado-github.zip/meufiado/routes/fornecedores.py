"""Account-scoped supplier management and soft deletion routes."""

from flask import flash, g, redirect, render_template, request, url_for

from meufiado.database import banco
from meufiado.services.ownership import meu_fornecedor


def fornecedores():

    uid = g.usuario[
        "id"
    ]


    if request.method == "POST":

        nome = " ".join(
            request.form.get(
                "nome",
                ""
            ).split()
        )


        telefone = request.form.get(
            "telefone",
            ""
        ).strip()[:30]


        contato = request.form.get(
            "contato",
            ""
        ).strip()[:100]


        categoria = request.form.get(
            "categoria",
            ""
        ).strip()[:100]


        observacao = request.form.get(
            "observacao",
            ""
        ).strip()[:500]


        if not nome:

            flash(
                "Informe o nome do fornecedor.",
                "erro"
            )


            return redirect(
                url_for(
                    "fornecedores"
                )
            )


        if len(nome) > 150:

            flash(
                "O nome do fornecedor deve ter até 150 caracteres.",
                "erro"
            )


            return redirect(
                url_for(
                    "fornecedores"
                )
            )


        with banco(
            escrita=True
        ) as conn:

            conn.execute(
                """
                INSERT INTO fornecedores (

                    usuario_id,

                    nome,

                    telefone,

                    contato,

                    categoria,

                    observacao

                )

                VALUES (
                    ?, ?, ?, ?, ?, ?
                )
                """,
                (
                    uid,

                    nome,

                    telefone,

                    contato,

                    categoria,

                    observacao
                )
            )


        flash(
            "Fornecedor cadastrado.",
            "sucesso"
        )


        return redirect(
            url_for(
                "fornecedores"
            )
        )


    with banco() as conn:

        lista = conn.execute(
            """
            SELECT *

            FROM fornecedores

            WHERE usuario_id=?
              AND ativo=1

            ORDER BY nome COLLATE NOCASE
            """,
            (
                uid,
            )
        ).fetchall()


    return render_template(
        "fornecedores.html",
        fornecedores=lista
    )



def editar_fornecedor(
    fornecedor_id
):

    nome = " ".join(
        request.form.get(
            "nome",
            ""
        ).split()
    )


    if not nome:

        flash(
            "Informe o nome do fornecedor.",
            "erro"
        )


        return redirect(
            url_for(
                "fornecedores"
            )
        )


    telefone = request.form.get(
        "telefone",
        ""
    ).strip()[:30]


    contato = request.form.get(
        "contato",
        ""
    ).strip()[:100]


    categoria = request.form.get(
        "categoria",
        ""
    ).strip()[:100]


    observacao = request.form.get(
        "observacao",
        ""
    ).strip()[:500]


    with banco(
        escrita=True
    ) as conn:

        meu_fornecedor(
            conn,
            fornecedor_id
        )


        conn.execute(
            """
            UPDATE fornecedores

            SET
                nome=?,

                telefone=?,

                contato=?,

                categoria=?,

                observacao=?

            WHERE id=?
              AND usuario_id=?
            """,
            (
                nome,

                telefone,

                contato,

                categoria,

                observacao,

                fornecedor_id,

                g.usuario[
                    "id"
                ]
            )
        )


    flash(
        "Fornecedor atualizado.",
        "sucesso"
    )


    return redirect(
        url_for(
            "fornecedores"
        )
    )



def excluir_fornecedor(
    fornecedor_id
):

    with banco(
        escrita=True
    ) as conn:

        meu_fornecedor(
            conn,
            fornecedor_id
        )


        conn.execute(
            """
            UPDATE fornecedores

            SET ativo=0

            WHERE id=?
              AND usuario_id=?
            """,
            (
                fornecedor_id,

                g.usuario[
                    "id"
                ]
            )
        )


    flash(
        "Fornecedor removido.",
        "sucesso"
    )


    return redirect(
        url_for(
            "fornecedores"
        )
    )



def register_routes(app):
    """Keep the original URLs, endpoint names, and methods."""
    app.add_url_rule('/fornecedores', methods=['GET', 'POST'], endpoint="fornecedores", view_func=fornecedores)
    app.add_url_rule('/fornecedor/<int:fornecedor_id>/editar', methods=['POST'], endpoint="editar_fornecedor", view_func=editar_fornecedor)
    app.add_url_rule('/fornecedor/<int:fornecedor_id>/excluir', methods=['POST'], endpoint="excluir_fornecedor", view_func=excluir_fornecedor)
