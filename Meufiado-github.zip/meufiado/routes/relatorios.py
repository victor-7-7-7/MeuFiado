"""Account-scoped sales, cash, inventory, and outstanding-debt reports."""

from datetime import datetime

from flask import g, render_template, request, url_for

from meufiado.database import banco
from meufiado.services.despesas import resumo_pagamentos
from meufiado.utils import data_valida


def relatorios():

    uid = g.usuario[
        "id"
    ]


    hoje = datetime.now().strftime(
        "%Y-%m-%d"
    )


    try:

        inicio = data_valida(
            request.args.get(
                "inicio",
                hoje[:8] + "01"
            )
        )


        fim = data_valida(
            request.args.get(
                "fim",
                hoje
            )
        )


        if inicio > fim:

            raise ValueError(
                "A data inicial precisa ser anterior ou igual à data final."
            )


    except ValueError as exc:

        return (
            render_template(
                "conta_erro.html",

                mensagem=str(
                    exc
                ),

                voltar=url_for(
                    "relatorios"
                )
            ),

            400
        )


    with banco() as conn:


        # vendas


        resumo_vendas = conn.execute(
            """
            SELECT

                COUNT(*) AS quantidade,

                COALESCE(
                    SUM(
                        total_centavos
                    ),
                    0
                ) AS total

            FROM vendas_negocio

            WHERE usuario_id=?

              AND data
                  BETWEEN ?
                  AND ?
            """,
            (
                uid,
                inicio,
                fim
            )
        ).fetchone()


        # caixa


        caixa_resumo = conn.execute(
            """
            SELECT

                COALESCE(
                    SUM(
                        CASE
                            WHEN tipo='entrada'
                            THEN valor_centavos
                            ELSE 0
                        END
                    ),
                    0
                ) AS entradas,

                COALESCE(
                    SUM(
                        CASE
                            WHEN tipo='saida'
                            THEN valor_centavos
                            ELSE 0
                        END
                    ),
                    0
                ) AS saidas

            FROM caixa_movimentos

            WHERE usuario_id=?

              AND data
                  BETWEEN ?
                  AND ?
            """,
            (
                uid,
                inicio,
                fim
            )
        ).fetchone()


        # estoque baixo


        estoque_baixo = conn.execute(
            """
            SELECT COUNT(*)

            FROM produtos

            WHERE usuario_id=?
              AND ativo=1
              AND quantidade <= estoque_minimo
            """,
            (
                uid,
            )
        ).fetchone()[0]


        # produtos vendidos


        produtos_vendidos = conn.execute(
            """
            SELECT

                COALESCE(
                    SUM(
                        vi.quantidade
                    ),
                    0
                )

            FROM venda_itens vi

            JOIN vendas_negocio vn
                ON vn.id=vi.venda_id

            WHERE vn.usuario_id=?

              AND vn.data
                  BETWEEN ?
                  AND ?
            """,
            (
                uid,
                inicio,
                fim
            )
        ).fetchone()[0]


        # ranking


        ranking_db = conn.execute(
            """
            SELECT

                vi.produto_nome AS nome,

                SUM(
                    vi.quantidade
                ) AS quantidade,

                SUM(
                    vi.total_centavos
                ) AS total_centavos

            FROM venda_itens vi

            JOIN vendas_negocio vn
                ON vn.id=vi.venda_id

            WHERE vn.usuario_id=?

              AND vn.data
                  BETWEEN ?
                  AND ?

            GROUP BY
                vi.produto_nome

            ORDER BY
                quantidade DESC,
                total_centavos DESC

            LIMIT 10
            """,
            (
                uid,
                inicio,
                fim
            )
        ).fetchall()


        # fiados em aberto


        devedores = conn.execute(
            """
            SELECT

                c.id,

                ROUND(
                    SUM(
                        CASE

                            WHEN v.status='fiado'
                            THEN v.valor

                            ELSE -v.valor

                        END
                    ),
                    2
                ) AS saldo

            FROM clientes c

            JOIN vendas v
                ON v.cliente_id=c.id

            WHERE c.usuario_id=?

              AND v.status IN (
                  'fiado',
                  'abatimento'
              )

            GROUP BY c.id

            HAVING saldo > 0
            """,
            (
                uid,
            )
        ).fetchall()


        despesas_operacionais = resumo_pagamentos(conn, uid, inicio, fim)


    total_a_receber = sum(
        item[
            "saldo"
        ]
        for item in devedores
    )


    ranking = [

        {

            "nome":
                item[
                    "nome"
                ],

            "quantidade":
                item[
                    "quantidade"
                ],

            "total":
                (
                    item[
                        "total_centavos"
                    ]
                    / 100
                )

        }

        for item in ranking_db

    ]


    recebimentos = (
        caixa_resumo[
            "entradas"
        ]
        / 100
    )


    despesas = (
        caixa_resumo[
            "saidas"
        ]
        / 100
    )


    return render_template(

        "relatorios.html",

        inicio=inicio,

        fim=fim,

        total_vendas=(
            resumo_vendas[
                "total"
            ]
            / 100
        ),

        quantidade_vendas=
            resumo_vendas[
                "quantidade"
            ],

        recebimentos=
            recebimentos,

        despesas=
            despesas,

        resultado=(
            recebimentos
            -
            despesas
        ),

        total_a_receber=
            total_a_receber,

        clientes_devedores=
            len(
                devedores
            ),

        estoque_baixo=
            estoque_baixo,

        produtos_vendidos=
            produtos_vendidos,

        despesas_operacionais=despesas_operacionais,

        ranking_produtos=
            ranking

    )



def register_routes(app):
    """Keep the original URLs, endpoint names, and methods."""
    app.add_url_rule('/relatorios', endpoint="relatorios", view_func=relatorios)
