"""Account-scoped customer registration, editing, and deletion routes."""

from flask import g, redirect, render_template, url_for

from meufiado.database import banco
from meufiado.services.clientes import dados_cliente, nome_duplicado
from meufiado.services.ownership import meu_cliente


def clientes():

    with banco() as conn:

        lista = conn.execute(
            """
            SELECT *

            FROM clientes

            WHERE usuario_id=?

            ORDER BY nome COLLATE NOCASE
            """,
            (
                g.usuario[
                    "id"
                ],
            )
        ).fetchall()


    return render_template(
        "clientes.html",
        clientes=lista
    )



def cadastrar_cliente():

    dados = dados_cliente()


    if not dados[0]:

        return (
            "Informe o nome do cliente.",
            400
        )


    with banco(
        escrita=True
    ) as conn:

        if nome_duplicado(
            conn,
            dados[0]
        ):

            return (
                "Já existe um cliente com este nome nesta conta. "
                "Use um nome que diferencie os cadastros.",
                400
            )


        conn.execute(
            """
            INSERT INTO clientes (

                nome,

                celular,

                endereco,

                usuario_id

            )

            VALUES (
                ?, ?, ?, ?
            )
            """,
            (
                *dados,

                g.usuario[
                    "id"
                ]
            )
        )


    return redirect(
        url_for(
            "clientes"
        )
    )



def editar_cliente(
    cliente_id
):

    dados = dados_cliente()


    with banco(
        escrita=True
    ) as conn:

        meu_cliente(
            conn,
            cliente_id
        )


        if not dados[0]:

            return (
                "Informe o nome do cliente.",
                400
            )


        if nome_duplicado(
            conn,
            dados[0],
            cliente_id
        ):

            return (
                "Já existe outro cliente com este nome nesta conta.",
                400
            )


        conn.execute(
            """
            UPDATE clientes

            SET
                nome=?,

                celular=?,

                endereco=?

            WHERE id=?
              AND usuario_id=?
            """,
            (
                *dados,

                cliente_id,

                g.usuario[
                    "id"
                ]
            )
        )


    return redirect(
        url_for(
            "clientes"
        )
    )



def excluir_cliente(
    cliente_id
):

    with banco(
        escrita=True
    ) as conn:

        meu_cliente(
            conn,
            cliente_id
        )

        conn.execute(
            """
            DELETE FROM vendas

            WHERE cliente_id=?
            """,
            (
                cliente_id,
            )
        )

        conn.execute(
            """
            DELETE FROM clientes

            WHERE id=?
              AND usuario_id=?
            """,
            (
                cliente_id,

                g.usuario[
                    "id"
                ]
            )
        )


    return redirect(
        url_for(
            "clientes"
        )
    )



def register_routes(app):
    """Keep the original URLs, endpoint names, and methods."""
    app.add_url_rule('/clientes', endpoint="clientes", view_func=clientes)
    app.add_url_rule('/cadastrar_cliente', methods=['POST'], endpoint="cadastrar_cliente", view_func=cadastrar_cliente)
    app.add_url_rule('/editar_cliente/<int:cliente_id>', methods=['POST'], endpoint="editar_cliente", view_func=editar_cliente)
    app.add_url_rule('/excluir_cliente/<int:cliente_id>', methods=['POST'], endpoint="excluir_cliente", view_func=excluir_cliente)
