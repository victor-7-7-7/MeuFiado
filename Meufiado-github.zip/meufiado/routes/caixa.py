"""Cash entries, expenses, and protected deletion of manual movements."""

from datetime import datetime

from flask import abort, flash, g, redirect, render_template, request, url_for

from meufiado.database import banco
from meufiado.utils import centavos, data_valida, valor_positivo


def caixa():

    if request.method == "POST":

        try:

            tipo = request.form.get(
                "tipo",
                ""
            )


            descricao = request.form.get(
                "descricao",
                ""
            ).strip()


            if (
                tipo not in (
                    "entrada",
                    "saida"
                )
                or not descricao
                or len(
                    descricao
                ) > 200
            ):

                raise ValueError(
                    "Escolha entrada ou saída e informe uma descrição de até 200 caracteres."
                )


            valor = centavos(
                valor_positivo(
                    request.form.get(
                        "valor"
                    )
                )
            )


            data = data_valida(
                request.form.get(
                    "data"
                )
            )


            if data > datetime.now().strftime(
                "%Y-%m-%d"
            ):

                raise ValueError(
                    "Registre somente movimentações já realizadas, até a data de hoje."
                )


            with banco(
                escrita=True
            ) as conn:

                conn.execute(
                    """
                    INSERT INTO caixa_movimentos (

                        usuario_id,

                        tipo,

                        descricao,

                        valor_centavos,

                        data

                    )

                    VALUES (
                        ?, ?, ?, ?, ?
                    )
                    """,
                    (
                        g.usuario[
                            "id"
                        ],

                        tipo,

                        descricao,

                        valor,

                        data
                    )
                )


            flash(
                "Movimentação registrada.",
                "sucesso"
            )


            return redirect(
                url_for(
                    "caixa",

                    inicio=(
                        data[:8]
                        + "01"
                    ),

                    fim=max(
                        data,

                        datetime.now().strftime(
                            "%Y-%m-%d"
                        )
                    )
                )
            )


        except ValueError as exc:

            return (
                render_template(
                    "conta_erro.html",

                    mensagem=str(
                        exc
                    ),

                    voltar=url_for(
                        "caixa"
                    )
                ),

                400
            )


    hoje = datetime.now().strftime(
        "%Y-%m-%d"
    )


    try:

        inicio = data_valida(
            request.args.get(
                "inicio",
                hoje[:8] + "01"
            )
        )


        fim = data_valida(
            request.args.get(
                "fim",
                hoje
            )
        )


        if inicio > fim:

            raise ValueError(
                "A data inicial deve ser anterior ou igual à data final."
            )


    except ValueError as exc:

        return (
            render_template(
                "conta_erro.html",

                mensagem=str(
                    exc
                ),

                voltar=url_for(
                    "caixa"
                )
            ),

            400
        )


    uid = g.usuario[
        "id"
    ]


    with banco() as conn:

        movimentos = conn.execute(
            """
            SELECT *

            FROM caixa_movimentos

            WHERE usuario_id=?

              AND data
                  BETWEEN ?
                  AND ?

            ORDER BY
                data DESC,
                id DESC
            """,
            (
                uid,
                inicio,
                fim
            )
        ).fetchall()


        anterior = conn.execute(
            """
            SELECT

                COALESCE(

                    SUM(

                        CASE

                            WHEN tipo='entrada'
                            THEN valor_centavos

                            ELSE -valor_centavos

                        END

                    ),

                    0

                )

            FROM caixa_movimentos

            WHERE usuario_id=?
              AND data < ?
            """,
            (
                uid,
                inicio
            )
        ).fetchone()[0]


    entradas = sum(

        m[
            "valor_centavos"
        ]

        for m in movimentos

        if m[
            "tipo"
        ] == "entrada"

    )


    saidas = sum(

        m[
            "valor_centavos"
        ]

        for m in movimentos

        if m[
            "tipo"
        ] == "saida"

    )


    return render_template(

        "conta_caixa.html",

        movimentos=movimentos,

        inicio=inicio,

        fim=fim,

        hoje=hoje,

        entradas=(
            entradas
            / 100
        ),

        saidas=(
            saidas
            / 100
        ),

        saldo_anterior=(
            anterior
            / 100
        ),

        saldo_periodo=(
            entradas
            -
            saidas
        ) / 100,

        saldo=(
            anterior
            +
            entradas
            -
            saidas
        ) / 100

    )



def excluir_movimento(
    movimento_id
):

    with banco(
        escrita=True
    ) as conn:

        movimento = conn.execute(
            """
            SELECT *

            FROM caixa_movimentos

            WHERE id=?
              AND usuario_id=?
            """,
            (
                movimento_id,

                g.usuario[
                    "id"
                ]
            )
        ).fetchone()


        if not movimento:

            abort(404)


        if (
            movimento[
                "origem"
            ] != "manual"
            or movimento[
                "venda_negocio_id"
            ] is not None
            or movimento["despesa_id"] is not None
        ):

            return (
                render_template(

                    "conta_erro.html",

                    mensagem=(
                        "Esta movimentação foi criada automaticamente "
                        "pelo sistema e não pode ser apagada diretamente "
                        "pelo caixa."
                    ),

                    voltar=url_for(
                        "caixa"
                    )

                ),

                400
            )


        conn.execute(
            """
            DELETE FROM caixa_movimentos

            WHERE id=?
              AND usuario_id=?
            """,
            (
                movimento_id,

                g.usuario[
                    "id"
                ]
            )
        )


    flash(
        "Movimentação excluída.",
        "sucesso"
    )


    return redirect(
        url_for(
            "caixa"
        )
    )



def register_routes(app):
    """Keep the original URLs, endpoint names, and methods."""
    app.add_url_rule('/caixa', methods=['GET', 'POST'], endpoint="caixa", view_func=caixa)
    app.add_url_rule('/caixa/<int:movimento_id>/excluir', methods=['POST'], endpoint="excluir_movimento", view_func=excluir_movimento)
