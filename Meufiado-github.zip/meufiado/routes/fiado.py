"""Credit purchases, debt statements, WhatsApp links, and payment routes."""

from datetime import datetime
import re
import urllib.parse

from flask import g, redirect, render_template, request, url_for

from meufiado.database import banco
from meufiado.filters import data_br, format_moeda
from meufiado.services.fiado import registrar_recebimento, saldo_cliente
from meufiado.services.ownership import meu_cliente
from meufiado.utils import centavos, valor_positivo


def registrar_fiado():

    nome = " ".join(
        request.form.get(
            "cliente_nome",
            ""
        ).split()
    )

    produto = request.form.get(
        "produto",
        ""
    ).strip()

    try:

        valor = valor_positivo(
            request.form.get(
                "valor"
            )
        )

    except ValueError as erro:

        return (
            str(
                erro
            ),
            400
        )

    if (
        not nome
        or not produto
    ):

        return (
            "Preencha o cliente e a descrição da compra.",
            400
        )


    with banco(
        escrita=True
    ) as conn:

        lista = conn.execute(
            """
            SELECT id

            FROM clientes

            WHERE usuario_id=?
              AND TRIM(nome)=?
                  COLLATE NOCASE
            """,
            (
                g.usuario[
                    "id"
                ],
                nome
            )
        ).fetchall()


        if len(
            lista
        ) != 1:

            return (
                "Cliente não encontrado ou nome duplicado. Confira o cadastro.",
                400
            )


        conn.execute(
            """
            INSERT INTO vendas (

                cliente_id,
                data,
                produto,
                valor,
                status

            )

            VALUES (
                ?, ?, ?, ?, ?
            )
            """,
            (
                lista[0][
                    "id"
                ],

                datetime.now().strftime(
                    "%Y-%m-%d"
                ),

                produto,

                valor,

                "fiado"
            )
        )


    return (
        "Compra registrada com sucesso!",
        200
    )



def fiados():

    with banco() as conn:

        vendas = conn.execute(
            """
            SELECT

                c.id AS cliente_id,

                c.nome,

                c.celular,

                c.endereco,

                v.data,

                v.produto,

                v.valor,

                v.status

            FROM vendas v

            JOIN clientes c
                ON v.cliente_id=c.id

            WHERE c.usuario_id=?

              AND v.status IN (
                  'fiado',
                  'abatimento'
              )

            ORDER BY
                v.data ASC,
                v.id ASC
            """,
            (
                g.usuario[
                    "id"
                ],
            )
        ).fetchall()


    devedores = {}


    for v in vendas:

        cid = v[
            "cliente_id"
        ]

        if cid not in devedores:

            devedores[
                cid
            ] = dict(

                cliente_id=cid,

                nome=v[
                    "nome"
                ],

                celular=v[
                    "celular"
                ],

                endereco=v[
                    "endereco"
                ],

                total_fiado=0.0,

                total_abatido=0.0,

                saldo=0.0,

                itens=[]

            )


        d = devedores[
            cid
        ]


        d[
            (
                "total_fiado"
                if v[
                    "status"
                ] == "fiado"
                else "total_abatido"
            )
        ] += v[
            "valor"
        ]


        d[
            "itens"
        ].append(
            dict(

                data=v[
                    "data"
                ],

                produto=v[
                    "produto"
                ],

                valor=v[
                    "valor"
                ],

                status=v[
                    "status"
                ]

            )
        )


        d[
            "saldo"
        ] = round(
            d[
                "total_fiado"
            ]
            -
            d[
                "total_abatido"
            ],
            2
        )


    lista = [

        d

        for d in devedores.values()

        if d[
            "saldo"
        ] > 0

    ]


    for d in lista:

        numero = re.sub(
            r"\D",
            "",
            d[
                "celular"
            ]
            or ""
        )


        if len(
            numero
        ) in (
            10,
            11
        ):

            numero = (
                "55"
                + numero
            )


        itens = "\n".join(

            f"{data_br(i['data'])} - "
            f"{i['produto']} "
            f"({'- ' if i['status'] == 'abatimento' else ''}"
            f"{format_moeda(i['valor'])})"

            for i in d[
                "itens"
            ]

        )


        mensagem = (

            f"Oi {d['nome']}, tudo bem?\n"

            "Passando para lembrar da sua conta em aberto "

            f"no valor total de {format_moeda(d['saldo'])}.\n\n"

            f"Detalhes da conta:\n{itens}\n"

        )


        d[
            "link_zap"
        ] = (

            f"https://wa.me/{numero}"
            f"?text={urllib.parse.quote(mensagem)}"

            if numero

            else None

        )


    return render_template(

        "fiados.html",

        devedores=lista,

        total_a_receber=sum(
            d[
                "saldo"
            ]
            for d in lista
        )
    )



def abater_fiado(
    cliente_id
):

    with banco(
        escrita=True
    ) as conn:

        cliente = meu_cliente(
            conn,
            cliente_id
        )

        try:

            valor = valor_positivo(
                request.form.get(
                    "valor_abatimento"
                )
            )

        except ValueError as erro:

            return (
                str(
                    erro
                ),
                400
            )


        saldo = centavos(
            saldo_cliente(
                conn,
                cliente_id
            )
        )

        pago = centavos(
            valor
        )


        if (
            saldo <= 0
            or pago > saldo
        ):

            return (
                "O abatimento precisa ser menor ou igual ao saldo em aberto.",
                400
            )


        conn.execute(
            """
            INSERT INTO vendas (

                cliente_id,

                data,

                produto,

                valor,

                status

            )

            VALUES (
                ?, ?, ?, ?, ?
            )
            """,
            (
                cliente_id,

                datetime.now().strftime(
                    "%Y-%m-%d"
                ),

                "Pagamento Parcial",

                valor,

                "abatimento"
            )
        )


        registrar_recebimento(
            conn,
            cliente,
            pago,
            "Pagamento de fiado"
        )


        if pago == saldo:

            conn.execute(
                """
                UPDATE vendas

                SET status='pago'

                WHERE cliente_id=?

                  AND status IN (
                      'fiado',
                      'abatimento'
                  )
                """,
                (
                    cliente_id,
                )
            )


    return redirect(
        url_for(
            "fiados"
        )
    )



def pagar_total(
    cliente_id
):

    with banco(
        escrita=True
    ) as conn:

        cliente = meu_cliente(
            conn,
            cliente_id
        )


        restante = centavos(
            saldo_cliente(
                conn,
                cliente_id
            )
        )


        if restante <= 0:

            return (
                "Este cliente não possui saldo em aberto.",
                400
            )


        registrar_recebimento(

            conn,

            cliente,

            restante,

            "Quitação de fiado"

        )


        conn.execute(
            """
            UPDATE vendas

            SET status='pago'

            WHERE cliente_id=?

              AND status IN (
                  'fiado',
                  'abatimento'
              )
            """,
            (
                cliente_id,
            )
        )


    return redirect(
        url_for(
            "fiados"
        )
    )



def pagamentos():

    with banco() as conn:

        registros = conn.execute(
            """
            SELECT

                c.nome,

                v.*

            FROM vendas v

            JOIN clientes c
                ON c.id=v.cliente_id

            WHERE c.usuario_id=?

              AND v.status IN (
                  'pago',
                  'abatimento'
              )

            ORDER BY
                v.data DESC,
                v.id DESC
            """,
            (
                g.usuario[
                    "id"
                ],
            )
        ).fetchall()


    return render_template(
        "pagamentos.html",
        registros=registros
    )



def register_routes(app):
    """Keep the original URLs, endpoint names, and methods."""
    app.add_url_rule('/registrar_fiado', methods=['POST'], endpoint="registrar_fiado", view_func=registrar_fiado)
    app.add_url_rule('/fiados', endpoint="fiados", view_func=fiados)
    app.add_url_rule('/abater_fiado/<int:cliente_id>', methods=['POST'], endpoint="abater_fiado", view_func=abater_fiado)
    app.add_url_rule('/pagar_total/<int:cliente_id>', methods=['POST'], endpoint="pagar_total", view_func=pagar_total)
    app.add_url_rule('/pagamentos', endpoint="pagamentos", view_func=pagamentos)
