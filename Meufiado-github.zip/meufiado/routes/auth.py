"""Login throttling, session creation, and logout routes."""

import secrets
import time

from flask import g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from meufiado.database import banco
from meufiado.security import csrf_token
from meufiado.services.planos import plano_liberado, status_plano


DUMMY_HASH = generate_password_hash(secrets.token_urlsafe(32))


def login():

    if g.usuario:

        return redirect(
            url_for(
                "contas"
                if g.usuario[
                    "admin"
                ]
                else "index"
            )
        )

    erro = None

    status = 200

    if request.method == "POST":

        nome_login = request.form.get(
            "login",
            ""
        ).strip().lower()[:100]

        senha = request.form.get(
            "senha",
            ""
        )

        ip = (
            request.remote_addr
            or ""
        )

        agora = time.time()

        with banco(
            escrita=True
        ) as conn:

            conn.execute(
                """
                DELETE FROM tentativas_login
                WHERE instante < ?
                """,
                (
                    agora - 900,
                )
            )

            quantidade = conn.execute(
                """
                SELECT COUNT(*)

                FROM tentativas_login

                WHERE login=?
                  AND ip=?
                """,
                (
                    nome_login,
                    ip
                )
            ).fetchone()[0]

            if quantidade >= 10:

                erro = (
                    "Muitas tentativas. "
                    "Aguarde 15 minutos e tente novamente."
                )

                status = 429

            else:

                usuario = conn.execute(
                    """
                    SELECT *

                    FROM contas

                    WHERE login=?
                      AND ativo=1
                    """,
                    (
                        nome_login,
                    )
                ).fetchone()

                hash_senha = (
                    usuario[
                        "senha_hash"
                    ]
                    if usuario
                    else DUMMY_HASH
                )

                valido = (
                    len(senha) <= 128
                    and check_password_hash(
                        hash_senha,
                        senha
                    )
                )

                if (
                    usuario
                    and valido
                ):

                    conn.execute(
                        """
                        DELETE FROM tentativas_login

                        WHERE login=?
                          AND ip=?
                        """,
                        (
                            nome_login,
                            ip
                        )
                    )

                    if not plano_liberado(
                        usuario
                    ):

                        estado = status_plano(
                            usuario
                        )

                        if estado == "vencido":

                            erro = (
                                "Seu plano venceu. "
                                "Entre em contato com o administrador para renovar."
                            )

                        else:

                            erro = (
                                "Seu acesso está suspenso. "
                                "Entre em contato com o administrador."
                            )

                        status = 403

                    else:

                        session.clear()

                        session[
                            "usuario_id"
                        ] = usuario[
                            "id"
                        ]

                        session[
                            "versao_sessao"
                        ] = usuario[
                            "versao_sessao"
                        ]

                        session.permanent = True

                        csrf_token()

                        return redirect(
                            url_for(
                                "contas"
                                if usuario[
                                    "admin"
                                ]
                                else "index"
                            )
                        )

                else:

                    conn.execute(
                        """
                        INSERT INTO tentativas_login

                        VALUES (?, ?, ?)
                        """,
                        (
                            nome_login,
                            ip,
                            agora
                        )
                    )

                    erro = (
                        "Login ou senha incorretos."
                    )

                    status = 401

    return (
        render_template(
            "conta_login.html",
            erro=erro
        ),
        status
    )



def logout():

    session.clear()

    return redirect(
        url_for(
            "login"
        )
    )



def register_routes(app):
    """Keep the original URLs, endpoint names, and methods."""
    app.add_url_rule('/login', methods=['GET', 'POST'], endpoint="login", view_func=login)
    app.add_url_rule('/logout', methods=['POST'], endpoint="logout", view_func=logout)
