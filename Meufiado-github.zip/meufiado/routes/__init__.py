"""Register domain routes without changing their public endpoint names.

Templates, navigation styles, and security checks use unqualified endpoints.
Explicit Flask registration preserves that contract when routes move modules.
"""

from . import (
    admin, auth, caixa, clientes, estoque, fiado, fornecedores,
    painel, relatorios, vendas, despesas,
)


def register_routes(app):
    for module in (
        auth, admin, painel, fiado, clientes, estoque,
        fornecedores, vendas, relatorios, caixa, despesas,
    ):
        module.register_routes(app)
