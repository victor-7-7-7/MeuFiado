"""Shared money, date, and nonnegative input validation."""

from datetime import datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import calendar


def centavos(valor):

    return int(
        (
            Decimal(str(valor))
            * 100
        ).quantize(
            Decimal("1"),
            rounding=ROUND_HALF_UP
        )
    )



def valor_positivo(texto):

    texto = (
        texto or ""
    ).strip().replace(
        "R$",
        ""
    ).replace(
        " ",
        ""
    )

    if "," in texto:

        texto = (
            texto
            .replace(".", "")
            .replace(",", ".")
        )

    try:

        valor = Decimal(
            texto
        )

        if (
            not valor.is_finite()
            or valor <= 0
            or valor > Decimal(
                "999999999.99"
            )
        ):

            raise ValueError

        valor = valor.quantize(
            Decimal("0.01"),
            rounding=ROUND_HALF_UP
        )

        if valor <= 0:

            raise ValueError

        return float(valor)

    except (
        InvalidOperation,
        ValueError
    ):

        raise ValueError(
            "Informe um valor válido, maior que zero."
        )



def data_valida(texto):

    try:

        if datetime.strptime(
            texto or "",
            "%Y-%m-%d"
        ).strftime(
            "%Y-%m-%d"
        ) != texto:

            raise ValueError

        return texto

    except (
        TypeError,
        ValueError
    ):

        raise ValueError(
            "Informe uma data válida."
        )



def valor_nao_negativo(texto):

    texto = (
        texto or "0"
    ).strip().replace(
        "R$",
        ""
    ).replace(
        " ",
        ""
    )

    if "," in texto:

        texto = (
            texto
            .replace(".", "")
            .replace(",", ".")
        )

    try:

        valor = Decimal(
            texto or "0"
        )

        if (
            not valor.is_finite()
            or valor < 0
            or valor > Decimal(
                "999999999.99"
            )
        ):

            raise ValueError

        return int(
            (
                valor * 100
            ).quantize(
                Decimal("1"),
                rounding=ROUND_HALF_UP
            )
        )

    except (
        InvalidOperation,
        ValueError
    ):

        raise ValueError(
            "Informe um valor de plano válido."
        )



def dinheiro_nao_negativo(
    texto,
    nome="Valor"
):

    texto = (
        texto or "0"
    ).strip().replace(
        "R$",
        ""
    ).replace(
        " ",
        ""
    )

    if "," in texto:

        texto = (
            texto
            .replace(".", "")
            .replace(",", ".")
        )

    try:

        valor = Decimal(
            texto or "0"
        )

        if (
            not valor.is_finite()
            or valor < 0
            or valor > Decimal(
                "999999999.99"
            )
        ):

            raise ValueError

        return int(
            (
                valor * 100
            ).quantize(
                Decimal("1"),
                rounding=ROUND_HALF_UP
            )
        )

    except (
        InvalidOperation,
        ValueError
    ):

        raise ValueError(
            f"Informe {nome.lower()} válido."
        )



def inteiro_nao_negativo(
    valor,
    nome="Quantidade"
):

    try:

        numero = int(
            valor
        )

    except (
        TypeError,
        ValueError
    ):

        raise ValueError(
            f"{nome} inválida."
        )

    if numero < 0:

        raise ValueError(
            f"{nome} não pode ser negativa."
        )

    return numero



def adicionar_meses(
    data_base,
    meses
):

    ano = (
        data_base.year
        +
        (
            data_base.month
            - 1
            + meses
        )
        // 12
    )

    mes = (
        (
            data_base.month
            - 1
            + meses
        )
        % 12
        + 1
    )

    dia = min(
        data_base.day,
        calendar.monthrange(
            ano,
            mes
        )[1]
    )

    return data_base.replace(
        year=ano,
        month=mes,
        day=dia
    )



def mes_valido(texto):
    """Validate a canonical reference month, using the existing date conventions."""
    try:
        if datetime.strptime(texto or '', '%Y-%m').strftime('%Y-%m') != texto:
            raise ValueError
        return texto
    except (TypeError, ValueError):
        raise ValueError('Informe um m\u00eas de refer\u00eancia v\u00e1lido.')
