﻿"""Environment settings shared by the factory and the legacy entry point."""

from datetime import timedelta
import os
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent.parent


def default_config():
    """Read environment settings when an application is created."""
    return {
        "DB_PATH": os.path.abspath(os.environ.get(
            "MEUFIADO_DB_PATH", str(BASE_DIR / "sistema_fiado.db")
        )),
        "SESSION_COOKIE_HTTPONLY": True,
        "SESSION_COOKIE_SAMESITE": "Lax",
        "SESSION_COOKIE_SECURE": os.environ.get("MEUFIADO_HTTPS", "0") == "1",
        "PERMANENT_SESSION_LIFETIME": timedelta(hours=8),
        "MAX_CONTENT_LENGTH": 2 * 1024 * 1024,
    }
