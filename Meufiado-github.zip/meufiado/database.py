"""SQLite connections, transactions, and idempotent startup migrations."""

from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
import os
import secrets
import sqlite3

from flask import current_app


def get_db_connection(db_path=None):

    conn = sqlite3.connect(
        db_path or current_app.config["DB_PATH"],
        timeout=30
    )

    conn.row_factory = sqlite3.Row

    conn.execute(
        "PRAGMA foreign_keys = ON"
    )

    return conn



@contextmanager
def banco(escrita=False, db_path=None):

    conn = get_db_connection(db_path)

    try:

        if escrita:

            conn.execute(
                "BEGIN IMMEDIATE"
            )

        yield conn

        if escrita:
            conn.commit()

    except Exception:

        conn.rollback()

        raise

    finally:

        conn.close()



def init_db():

    DB_PATH = current_app.config["DB_PATH"]

    Path(
        DB_PATH
    ).parent.mkdir(
        parents=True,
        exist_ok=True
    )


    # backup de banco antigo


    with banco() as conn:

        colunas = {
            r["name"]
            for r in conn.execute(
                "PRAGMA table_info(clientes)"
            )
        }

        if (
            colunas
            and "usuario_id"
            not in colunas
        ):

            destino = (
                f"{DB_PATH}.antes_login_"
                f"{datetime.now():%Y%m%d_%H%M%S}_"
                f"{secrets.token_hex(3)}.bak"
            )

            with sqlite3.connect(
                destino
            ) as backup:

                conn.backup(
                    backup
                )


    with banco(escrita=True) as conn:


        # contas


        conn.execute("""
            CREATE TABLE IF NOT EXISTS contas (

                id INTEGER PRIMARY KEY AUTOINCREMENT,

                nome TEXT NOT NULL,

                login TEXT NOT NULL
                    UNIQUE COLLATE NOCASE,

                senha_hash TEXT NOT NULL,

                admin INTEGER NOT NULL
                    DEFAULT 0,

                ativo INTEGER NOT NULL
                    DEFAULT 1,

                versao_sessao INTEGER NOT NULL
                    DEFAULT 1,

                criado_em TEXT NOT NULL
                    DEFAULT CURRENT_TIMESTAMP,

                plano_nome TEXT NOT NULL
                    DEFAULT 'Legado',

                plano_tipo TEXT NOT NULL
                    DEFAULT 'unico',

                plano_valor_centavos INTEGER NOT NULL
                    DEFAULT 0,

                plano_inicio TEXT,

                plano_vencimento TEXT,

                plano_status TEXT NOT NULL
                    DEFAULT 'ativo',

                plano_observacao TEXT NOT NULL
                    DEFAULT ''

            )
        """)


        # migração das contas


        colunas_contas = {
            r["name"]
            for r in conn.execute(
                "PRAGMA table_info(contas)"
            )
        }

        migracoes = (

            (
                "plano_nome",
                "TEXT NOT NULL DEFAULT 'Legado'"
            ),

            (
                "plano_tipo",
                "TEXT NOT NULL DEFAULT 'unico'"
            ),

            (
                "plano_valor_centavos",
                "INTEGER NOT NULL DEFAULT 0"
            ),

            (
                "plano_inicio",
                "TEXT"
            ),

            (
                "plano_vencimento",
                "TEXT"
            ),

            (
                "plano_status",
                "TEXT NOT NULL DEFAULT 'ativo'"
            ),

            (
                "plano_observacao",
                "TEXT NOT NULL DEFAULT ''"
            ),

        )

        for coluna, definicao in migracoes:

            if coluna not in colunas_contas:

                conn.execute(
                    f"""
                    ALTER TABLE contas
                    ADD COLUMN {coluna} {definicao}
                    """
                )


        # clientes


        conn.execute("""
            CREATE TABLE IF NOT EXISTS clientes (

                id INTEGER PRIMARY KEY AUTOINCREMENT,

                nome TEXT,

                celular TEXT,

                endereco TEXT,

                usuario_id INTEGER
                    REFERENCES contas(id)

            )
        """)

        colunas = {
            r["name"]
            for r in conn.execute(
                "PRAGMA table_info(clientes)"
            )
        }

        if "usuario_id" not in colunas:

            conn.execute("""
                ALTER TABLE clientes
                ADD COLUMN usuario_id
                INTEGER REFERENCES contas(id)
            """)


        # fiados antigos


        conn.execute("""
            CREATE TABLE IF NOT EXISTS vendas (

                id INTEGER PRIMARY KEY AUTOINCREMENT,

                cliente_id INTEGER,

                data TEXT,

                produto TEXT,

                valor REAL,

                status TEXT,

                FOREIGN KEY(cliente_id)
                    REFERENCES clientes(id)

            )
        """)


        # caixa


        conn.execute("""
            CREATE TABLE IF NOT EXISTS caixa_movimentos (

                id INTEGER PRIMARY KEY AUTOINCREMENT,

                usuario_id INTEGER NOT NULL
                    REFERENCES contas(id),

                tipo TEXT NOT NULL
                    CHECK(
                        tipo IN (
                            'entrada',
                            'saida'
                        )
                    ),

                descricao TEXT NOT NULL,

                valor_centavos INTEGER NOT NULL
                    CHECK(
                        valor_centavos > 0
                    ),

                data TEXT NOT NULL,

                origem TEXT NOT NULL
                    DEFAULT 'manual'
                    CHECK(
                        origem IN (
                            'manual',
                            'fiado'
                        )
                    ),

                cliente_id INTEGER
                    REFERENCES clientes(id)
                    ON DELETE SET NULL,

                criado_em TEXT NOT NULL
                    DEFAULT CURRENT_TIMESTAMP

            )
        """)


        # produtos / estoque


        conn.execute("""
            CREATE TABLE IF NOT EXISTS produtos (

                id INTEGER PRIMARY KEY AUTOINCREMENT,

                usuario_id INTEGER NOT NULL
                    REFERENCES contas(id)
                    ON DELETE CASCADE,

                nome TEXT NOT NULL,

                categoria TEXT NOT NULL
                    DEFAULT '',

                preco_custo_centavos INTEGER NOT NULL
                    DEFAULT 0
                    CHECK(
                        preco_custo_centavos >= 0
                    ),

                preco_venda_centavos INTEGER NOT NULL
                    DEFAULT 0
                    CHECK(
                        preco_venda_centavos >= 0
                    ),

                quantidade INTEGER NOT NULL
                    DEFAULT 0
                    CHECK(
                        quantidade >= 0
                    ),

                estoque_minimo INTEGER NOT NULL
                    DEFAULT 0
                    CHECK(
                        estoque_minimo >= 0
                    ),

                ativo INTEGER NOT NULL
                    DEFAULT 1,

                criado_em TEXT NOT NULL
                    DEFAULT CURRENT_TIMESTAMP,

                atualizado_em TEXT NOT NULL
                    DEFAULT CURRENT_TIMESTAMP

            )
        """)


        # fornecedores


        conn.execute("""
            CREATE TABLE IF NOT EXISTS fornecedores (

                id INTEGER PRIMARY KEY AUTOINCREMENT,

                usuario_id INTEGER NOT NULL
                    REFERENCES contas(id)
                    ON DELETE CASCADE,

                nome TEXT NOT NULL,

                telefone TEXT NOT NULL
                    DEFAULT '',

                contato TEXT NOT NULL
                    DEFAULT '',

                categoria TEXT NOT NULL
                    DEFAULT '',

                observacao TEXT NOT NULL
                    DEFAULT '',

                ativo INTEGER NOT NULL
                    DEFAULT 1,

                criado_em TEXT NOT NULL
                    DEFAULT CURRENT_TIMESTAMP

            )
        """)


        # vendas do negócio


        conn.execute("""
            CREATE TABLE IF NOT EXISTS vendas_negocio (

                id INTEGER PRIMARY KEY AUTOINCREMENT,

                usuario_id INTEGER NOT NULL
                    REFERENCES contas(id)
                    ON DELETE CASCADE,

                cliente_id INTEGER
                    REFERENCES clientes(id)
                    ON DELETE SET NULL,

                forma_pagamento TEXT NOT NULL
                    CHECK(
                        forma_pagamento
                        IN (
                            'avista',
                            'fiado'
                        )
                    ),

                total_centavos INTEGER NOT NULL
                    CHECK(
                        total_centavos > 0
                    ),

                data TEXT NOT NULL,

                criado_em TEXT NOT NULL
                    DEFAULT CURRENT_TIMESTAMP

            )
        """)


        # itens das vendas


        conn.execute("""
            CREATE TABLE IF NOT EXISTS venda_itens (

                id INTEGER PRIMARY KEY AUTOINCREMENT,

                venda_id INTEGER NOT NULL
                    REFERENCES vendas_negocio(id)
                    ON DELETE CASCADE,

                produto_id INTEGER
                    REFERENCES produtos(id)
                    ON DELETE SET NULL,

                produto_nome TEXT NOT NULL,

                quantidade INTEGER NOT NULL
                    CHECK(
                        quantidade > 0
                    ),

                preco_unitario_centavos INTEGER NOT NULL
                    CHECK(
                        preco_unitario_centavos >= 0
                    ),

                total_centavos INTEGER NOT NULL
                    CHECK(
                        total_centavos >= 0
                    )

            )
        """)


        # liga caixa à venda


        colunas_caixa = {
            r["name"]
            for r in conn.execute(
                "PRAGMA table_info(caixa_movimentos)"
            )
        }

        if (
            "venda_negocio_id"
            not in colunas_caixa
        ):

            conn.execute("""
                ALTER TABLE caixa_movimentos

                ADD COLUMN venda_negocio_id
                INTEGER
                REFERENCES vendas_negocio(id)
            """)


        # Paid operating expenses and their one-to-one cash movements.
        conn.execute("""
            CREATE TABLE IF NOT EXISTS despesas_operacionais (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id INTEGER NOT NULL REFERENCES contas(id) ON DELETE CASCADE,
                categoria TEXT NOT NULL CHECK(categoria IN ('imposto', 'funcionario')),
                descricao TEXT NOT NULL,
                valor_centavos INTEGER NOT NULL CHECK(valor_centavos > 0),
                data_pagamento TEXT NOT NULL,
                mes_referencia TEXT NOT NULL,
                tipo TEXT NOT NULL DEFAULT '',
                observacao TEXT NOT NULL DEFAULT '',
                criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        # Employees own individual expense rows; no monthly total is stored.
        conn.execute("""
            CREATE TABLE IF NOT EXISTS funcionarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id INTEGER NOT NULL REFERENCES contas(id) ON DELETE CASCADE,
                nome TEXT NOT NULL,
                nome_normalizado TEXT NOT NULL,
                criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(usuario_id, nome_normalizado)
            )
        """)
        colunas_despesas = {r['name'] for r in conn.execute('PRAGMA table_info(despesas_operacionais)')}
        if 'funcionario_id' not in colunas_despesas:
            conn.execute("""
                ALTER TABLE despesas_operacionais ADD COLUMN funcionario_id INTEGER
                REFERENCES funcionarios(id) ON DELETE CASCADE
            """)
        # Legacy records had only a description. Preserve their IDs, values and cash
        # links, using that description as the initial employee name.
        for despesa in conn.execute("""
            SELECT id, usuario_id, descricao FROM despesas_operacionais
            WHERE categoria='funcionario' AND funcionario_id IS NULL
        """).fetchall():
            nome = ' '.join(despesa['descricao'].split()) or 'Funcionário'
            conn.execute('INSERT OR IGNORE INTO funcionarios (usuario_id, nome, nome_normalizado) VALUES (?, ?, ?)',
                         (despesa['usuario_id'], nome, nome.casefold()))
            funcionario = conn.execute('SELECT id FROM funcionarios WHERE usuario_id=? AND nome_normalizado=?',
                                       (despesa['usuario_id'], nome.casefold())).fetchone()
            conn.execute('UPDATE despesas_operacionais SET funcionario_id=? WHERE id=? AND usuario_id=?',
                         (funcionario['id'], despesa['id'], despesa['usuario_id']))
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_despesas_funcionario_mes
            ON despesas_operacionais(usuario_id, funcionario_id, mes_referencia)
        """)
        for evento in ('INSERT', 'UPDATE'):
            conn.execute(f"""
                CREATE TRIGGER IF NOT EXISTS validar_funcionario_despesa_{evento.lower()}
                BEFORE {evento} ON despesas_operacionais
                WHEN (NEW.categoria='funcionario' AND NOT EXISTS (
                    SELECT 1 FROM funcionarios WHERE id=NEW.funcionario_id AND usuario_id=NEW.usuario_id
                )) OR (NEW.categoria='imposto' AND NEW.funcionario_id IS NOT NULL)
                BEGIN SELECT RAISE(ABORT, 'Funcionario invalido para esta conta'); END
            """)

        if 'despesa_id' not in colunas_caixa:
            conn.execute("""
                ALTER TABLE caixa_movimentos ADD COLUMN despesa_id INTEGER
                REFERENCES despesas_operacionais(id) ON DELETE CASCADE
            """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_despesas_usuario_mes
            ON despesas_operacionais(usuario_id, mes_referencia, categoria, data_pagamento)
        """)
        conn.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS idx_caixa_despesa
            ON caixa_movimentos(despesa_id) WHERE despesa_id IS NOT NULL
        """)

        # Retain consumed form keys after deletion to block delayed payment retries.
        conn.execute("""
            CREATE TABLE IF NOT EXISTS despesas_envios (
                usuario_id INTEGER NOT NULL REFERENCES contas(id) ON DELETE CASCADE,
                chave TEXT NOT NULL,
                despesa_id INTEGER UNIQUE REFERENCES despesas_operacionais(id) ON DELETE SET NULL,
                criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (usuario_id, chave)
            )
        """)

        # Batch fingerprints prevent changed or partial retries of a multi-item form.
        conn.execute("""
            CREATE TABLE IF NOT EXISTS despesas_lotes (
                usuario_id INTEGER NOT NULL REFERENCES contas(id) ON DELETE CASCADE,
                chave TEXT NOT NULL,
                assinatura TEXT NOT NULL,
                criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(usuario_id, chave)
            )
        """)

        # configuração


        conn.execute("""
            CREATE TABLE IF NOT EXISTS configuracao_app (

                chave TEXT PRIMARY KEY,

                valor TEXT NOT NULL

            )
        """)

        conn.execute(
            """
            INSERT OR IGNORE
            INTO configuracao_app
            VALUES (?, ?)
            """,
            (
                "secret_key",
                secrets.token_hex(32)
            )
        )


        # login


        conn.execute("""
            CREATE TABLE IF NOT EXISTS tentativas_login (

                login TEXT NOT NULL,

                ip TEXT NOT NULL,

                instante REAL NOT NULL

            )
        """)


        # índices


        for sql in (

            """
            CREATE INDEX IF NOT EXISTS
            idx_clientes_usuario
            ON clientes(
                usuario_id,
                nome
            )
            """,

            """
            CREATE INDEX IF NOT EXISTS
            idx_vendas_cliente
            ON vendas(
                cliente_id,
                status
            )
            """,

            """
            CREATE INDEX IF NOT EXISTS
            idx_caixa_usuario_data
            ON caixa_movimentos(
                usuario_id,
                data
            )
            """,

            """
            CREATE INDEX IF NOT EXISTS
            idx_tentativas_login
            ON tentativas_login(
                login,
                ip,
                instante
            )
            """,

            """
            CREATE INDEX IF NOT EXISTS
            idx_contas_plano
            ON contas(
                admin,
                plano_status,
                plano_vencimento
            )
            """,

            """
            CREATE INDEX IF NOT EXISTS
            idx_produtos_usuario
            ON produtos(
                usuario_id,
                nome
            )
            """,

            """
            CREATE INDEX IF NOT EXISTS
            idx_produtos_estoque
            ON produtos(
                usuario_id,
                ativo,
                quantidade
            )
            """,

            """
            CREATE INDEX IF NOT EXISTS
            idx_fornecedores_usuario
            ON fornecedores(
                usuario_id,
                nome
            )
            """,

            """
            CREATE INDEX IF NOT EXISTS
            idx_vendas_negocio_usuario_data
            ON vendas_negocio(
                usuario_id,
                data
            )
            """,

            """
            CREATE INDEX IF NOT EXISTS
            idx_venda_itens_venda
            ON venda_itens(
                venda_id
            )
            """,

        ):

            conn.execute(sql)


        secret = conn.execute(
            """
            SELECT valor
            FROM configuracao_app
            WHERE chave='secret_key'
            """
        ).fetchone()[0]


    current_app.config["SECRET_KEY"] = (
        os.environ.get(
            "MEUFIADO_SECRET_KEY"
        )
        or secret
    )

