"""Browser checks for expense forms, editing/deletion, navigation and historical totals."""

from datetime import datetime
import os
from pathlib import Path
import tempfile
import threading
import unittest
from urllib.parse import urlsplit

from werkzeug.serving import WSGIRequestHandler, make_server

from meufiado import create_app
from meufiado.database import banco
from meufiado.services.contas import criar_conta
from meufiado.services.despesas import criar_despesa, validar_despesa

try:
    from playwright.sync_api import Error, expect, sync_playwright
except ImportError:
    sync_playwright = None


class QuietHandler(WSGIRequestHandler):
    def log(self, type, message, *args):
        pass


@unittest.skipUnless(sync_playwright, 'Install requirements-dev.txt for browser tests.')
class ExpenseBrowserTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        expect.set_options(timeout=15000)
        cls.driver = sync_playwright().start()
        cls.addClassCleanup(cls.driver.stop)
        channel = os.environ.get('MEUFIADO_TEST_BROWSER_CHANNEL','msedge' if os.name=='nt' else 'chromium')
        try:
            cls.browser = cls.driver.chromium.launch(headless=True,**({'channel':channel} if channel!='chromium' else {}))
        except Error as exc:
            if 'not found' in str(exc) or "Executable doesn't exist" in str(exc):
                raise unittest.SkipTest('Install Edge or Playwright Chromium.') from exc
            raise
        cls.addClassCleanup(cls.browser.close)
        cls.temp = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.temp.cleanup)
        cls.app = create_app({'TESTING':True,'DB_PATH':str(Path(cls.temp.name)/'browser-expenses.db'),
                              'SESSION_COOKIE_SECURE':False,'SECRET_KEY':'expense-browser-test-key'})
        with cls.app.app_context(),banco(escrita=True) as conn:
            cls.uid = criar_conta(conn,'Expense owner','owner','password123')
        cls.server = make_server('127.0.0.1',0,cls.app,threaded=True,request_handler=QuietHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
        cls.url = f'http://127.0.0.1:{cls.server.server_port}'
        cls.addClassCleanup(cls.stop_server)

    @classmethod
    def stop_server(cls):
        cls.server.shutdown()
        cls.thread.join(timeout=5)
        cls.server.server_close()

    def setUp(self):
        with self.app.app_context(),banco(escrita=True) as conn:
            conn.execute('DELETE FROM despesas_lotes')
            conn.execute('DELETE FROM despesas_envios')
            conn.execute('DELETE FROM caixa_movimentos')
            conn.execute('DELETE FROM despesas_operacionais')
            conn.execute('DELETE FROM funcionarios')
        self.context = self.browser.new_context(viewport={'width':1280,'height':900})
        self.context.route('**/*',lambda route: route.continue_()
                           if (urlsplit(route.request.url).netloc==urlsplit(self.url).netloc
                               and urlsplit(route.request.url).path!='/static/favicon.svg') else route.abort())
        self.addCleanup(self.close_context)
        self.page = self.context.new_page()
        self.page.goto(self.url+'/login',wait_until='domcontentloaded')
        self.page.locator('input[name="login"]').fill('owner')
        self.page.locator('input[name="senha"]').fill('password123')
        self.page.locator('button[type="submit"]').click()
        self.page.wait_for_url(self.url+'/painel',wait_until='domcontentloaded')
        self.page.goto(self.url+'/despesas/impostos?mes=2026-10',wait_until='domcontentloaded')

    def close_context(self):
        try:
            if self.context.pages:
                self.page.wait_for_load_state('networkidle')
        finally:
            self.context.close()

    def rows(self, sql, args=()):
        with self.app.app_context(),banco() as conn:
            return [dict(row) for row in conn.execute(sql,args)]

    def fill_expense(self, descricao='DAS', valor='1250', mes='2026-10', tipo=None):
        form = self.page.locator('#formDespesa')
        form.locator('input[name="descricao"]').fill(descricao)
        form.locator('input[name="valor"]').fill(valor)
        form.locator('input[name="data_pagamento"]').fill('2026-01-15')
        form.locator('input[name="mes_referencia"]').fill(mes)
        if tipo:
            form.locator('input[name="funcionario_nome"]').fill('Ana')
            form.locator('select[name="tipo"]').select_option(tipo)
        form.locator('button[type="submit"]').click()

    def test_tax_and_employee_form_submissions_show_combined_monthly_total(self):
        self.fill_expense()
        expect(self.page.locator('#totalImpostos')).to_have_text('R$ 1.250,00')
        self.page.get_by_role('link',name='Funcionários',exact=True).click()
        self.fill_expense(descricao='Salário de Ana',valor='4800',tipo='salario')
        expect(self.page.locator('#totalFuncionarios')).to_have_text('R$ 4.800,00')
        expect(self.page.locator('#totalDespesas')).to_have_text('R$ 6.050,00')
        self.assertEqual(len(self.rows('SELECT * FROM despesas_operacionais')),2)
        cash = self.rows('SELECT tipo,valor_centavos,despesa_id FROM caixa_movimentos ORDER BY id')
        self.assertEqual([row['valor_centavos'] for row in cash],[125000,480000])
        self.assertTrue(all(row['tipo']=='saida' and row['despesa_id'] for row in cash))
        screenshot = os.environ.get('MEUFIADO_EXPENSE_SCREENSHOT')
        if screenshot:
            self.page.screenshot(path=screenshot,full_page=True)

    def test_edit_and_confirmed_delete_keep_cash_consistent(self):
        self.fill_expense(valor='100')
        expect(self.page.locator('#totalImpostos')).to_have_text('R$ 100,00')
        expense = self.rows('SELECT * FROM despesas_operacionais')[0]
        cash_id = self.rows('SELECT id FROM caixa_movimentos')[0]['id']
        article = self.page.locator(f"[data-despesa-id='{expense['id']}']")
        article.get_by_role('link',name='Editar',exact=True).click()
        self.fill_expense(valor='150,50',mes='2026-09')
        expect(self.page.locator('#totalImpostos')).to_have_text('R$ 150,50')
        cash = self.rows('SELECT * FROM caixa_movimentos')
        self.assertEqual(len(cash),1)
        self.assertEqual(cash[0]['id'],cash_id)
        self.assertEqual(cash[0]['valor_centavos'],15050)
        self.page.once('dialog',lambda dialog:dialog.accept())
        self.page.locator(f"[data-despesa-id='{expense['id']}']").locator('form button').click()
        expect(self.page.locator('#totalDespesas')).to_have_text('R$ 0,00')
        self.assertFalse(self.rows('SELECT * FROM despesas_operacionais'))
        self.assertFalse(self.rows('SELECT * FROM caixa_movimentos'))

    def test_concurrent_form_submissions_create_only_one_payment(self):
        form = self.page.locator('#formDespesa')
        form.locator('input[name="descricao"]').fill('DAS')
        form.locator('input[name="valor"]').fill('100')
        form.locator('input[name="data_pagamento"]').fill('2026-01-15')
        self.page.locator('#adicionarGasto').click()
        self.fill_row(1,'50',description='ICMS')
        self.page.locator('#adicionarGasto').click()
        self.fill_row(2,'25',description='ISS')
        results = self.page.evaluate('''async () => {
            const form = document.getElementById('formDespesa');
            const body = new URLSearchParams(new FormData(form)).toString();
            return Promise.all([1, 2].map(async () => {
                const response = await fetch(form.action, {
                    method: 'POST', credentials: 'same-origin', body,
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                });
                return response.status;
            }));
        }''')
        self.assertEqual(results, [200, 200])
        self.page.reload(wait_until='domcontentloaded')
        expect(self.page.locator('#totalImpostos')).to_have_text('R$ 175,00')
        self.assertEqual(len(self.rows('SELECT * FROM despesas_operacionais')), 3)
        self.assertEqual(len(self.rows('SELECT * FROM caixa_movimentos')), 3)

    def test_invalid_amount_can_be_corrected_on_the_same_form(self):
        key = self.page.locator('input[name="chave_envio"]').input_value()
        form = self.page.locator('#formDespesa')
        form.locator('input[name="descricao"]').fill('DAS')
        form.locator('input[name="valor"]').fill('-1')
        self.page.evaluate("document.getElementById('formDespesa').submit()")
        expect(self.page.get_by_role('alert')).to_contain_text('maior que zero')
        expect(self.page.locator('input[name="chave_envio"]')).to_have_value(key)
        self.assertFalse(self.rows('SELECT * FROM despesas_envios'))
        self.fill_expense(valor='100')
        expect(self.page.locator('#totalImpostos')).to_have_text('R$ 100,00')
        self.assertEqual(len(self.rows('SELECT * FROM caixa_movimentos')), 1)

    def test_reference_month_filter_and_navigation(self):
        current = datetime.now().strftime('%Y-%m')
        with self.app.app_context(),banco(escrita=True) as conn:
            for mes, valor in (('2025-12','99'),(current,'50')):
                dados = validar_despesa({'descricao':'DAS','valor':valor,
                    'data_pagamento':datetime.now().strftime('%Y-%m-%d'),'mes_referencia':mes},'imposto')
                criar_despesa(conn,self.uid,dados)
        self.page.goto(self.url+'/despesas',wait_until='domcontentloaded')
        expect(self.page.locator('#totalImpostos')).to_have_text('R$ 50,00')
        self.page.locator('.conta-filter input[name="mes"]').fill('2025-12')
        self.page.locator('.conta-filter button').click()
        expect(self.page.locator('#totalImpostos')).to_have_text('R$ 99,00')
        self.page.goto(self.url+'/caixa',wait_until='domcontentloaded')
        self.page.get_by_role('button',name='Abrir menu').click()
        self.page.get_by_role('link',name='Despesas',exact=True).click()
        expect(self.page.locator('#totalImpostos')).to_have_text('R$ 50,00')

    def test_report_date_filter_shows_paid_expense_breakdown(self):
        self.fill_expense(valor='100')
        expect(self.page.locator('#totalImpostos')).to_have_text('R$ 100,00')
        self.page.goto(self.url+'/relatorios',wait_until='domcontentloaded')
        form = self.page.locator('form.relatorio-filter')
        form.locator('input[name="inicio"]').fill('2026-01-01')
        form.locator('input[name="fim"]').fill('2026-01-31')
        form.locator('button').click()
        self.page.wait_for_url('**/relatorios?inicio=2026-01-01&fim=2026-01-31',wait_until='domcontentloaded')
        section = self.page.locator('section').filter(
            has=self.page.get_by_role('heading',name='Impostos e funcionários no período',exact=True))
        expect(section.locator('strong')).to_have_text(['R$ 100,00','R$ 0,00','R$ 100,00'])

    def employee_form(self, name='João'):
        self.page.goto(self.url+'/despesas/funcionarios?mes=2026-10', wait_until='domcontentloaded')
        form = self.page.locator('#formDespesa')
        form.locator('input[name="funcionario_nome"]').fill(name)
        form.locator('input[name="data_pagamento"]').fill('2026-01-15')
        return form

    def fill_row(self, index, value, tipo=None, description=None):
        row = self.page.locator('#gastosDespesa [data-gasto]').nth(index)
        if tipo:
            row.locator('select[name="tipo"]').select_option(tipo)
        if description is not None:
            row.locator('input[name="descricao"]').fill(description)
        row.locator('input[name="valor"]').fill(value)

    def test_employee_item_total_updates_on_add_edit_remove_and_save(self):
        form = self.employee_form()
        self.fill_row(0,'1675,00',tipo='salario')
        self.page.locator('#adicionarGasto').click()
        self.fill_row(1,'100',tipo='transporte')
        self.page.locator('#adicionarGasto').click()
        self.fill_row(2,'200',tipo='comissoes')
        expect(self.page.locator('#totalLancamentos')).to_have_text('R$ 1.975,00')
        self.fill_row(1,'150',tipo='transporte')
        expect(self.page.locator('#totalLancamentos')).to_have_text('R$ 2.025,00')
        self.page.get_by_role('button',name='Remover gasto 2',exact=True).click()
        expect(self.page.locator('#totalLancamentos')).to_have_text('R$ 1.875,00')
        self.page.locator('#adicionarGasto').click()
        self.fill_row(2,'100',tipo='transporte')
        expect(self.page.locator('#totalLancamentos')).to_have_text('R$ 1.975,00')
        form.locator('button[type="submit"]').click()
        expect(self.page.locator('#totalFuncionarios')).to_have_text('R$ 1.975,00')
        expect(self.page.locator('[data-total-funcionario]')).to_have_text('R$ 1.975,00')
        expect(self.page.locator('.despesa-funcionario h3')).to_have_text('João')
        self.assertEqual(len(self.rows('SELECT * FROM despesas_operacionais')),3)
        self.assertEqual(len(self.rows('SELECT * FROM caixa_movimentos')),3)
        self.page.get_by_role('link',name='+ Adicionar gasto para João',exact=True).click()
        expect(self.page.locator('input[name="funcionario_nome"]')).to_have_value('João')
        self.fill_row(0,'25',tipo='hora_extra')
        self.page.locator('#formDespesa button[type="submit"]').click()
        expect(self.page.locator('[data-total-funcionario]')).to_have_text('R$ 2.000,00')
        self.assertEqual(len(self.rows('SELECT * FROM funcionarios')),1)

    def test_multiple_tax_lines_edit_and_delete_recalculate_history(self):
        for index, description, value in ((0,'DAS','500'),(1,'ICMS','300'),(2,'Taxa municipal','100')):
            if index:
                self.page.locator('#adicionarGasto').click()
            self.fill_row(index,value,description=description)
        expect(self.page.locator('#totalLancamentos')).to_have_text('R$ 900,00')
        self.page.locator('#formDespesa button[type="submit"]').click()
        expect(self.page.locator('#totalImpostos')).to_have_text('R$ 900,00')
        article = self.page.locator('[data-despesa-id]').filter(has=self.page.get_by_text('ICMS',exact=True))
        article.get_by_role('link',name='Editar',exact=True).click()
        self.page.locator('input[name="valor"]').fill('400')
        expect(self.page.locator('#totalLancamentos')).to_have_text('R$ 400,00')
        self.page.locator('#formDespesa button[type="submit"]').click()
        expect(self.page.locator('#totalImpostos')).to_have_text('R$ 1.000,00')
        self.page.once('dialog',lambda dialog:dialog.accept())
        self.page.get_by_role('button',name='Excluir DAS',exact=True).click()
        expect(self.page.locator('#totalImpostos')).to_have_text('R$ 500,00')
        self.assertEqual(len(self.rows('SELECT * FROM caixa_movimentos')),2)

    def test_invalid_second_item_preserves_all_fields_without_partial_save(self):
        form = self.employee_form()
        key = form.locator('input[name="chave_envio"]').input_value()
        self.fill_row(0,'1675',tipo='salario')
        self.page.locator('#adicionarGasto').click()
        self.fill_row(1,'-100',tipo='transporte')
        expect(self.page.locator('#totalLancamentos')).to_have_text('Corrija os valores informados')
        self.page.evaluate("document.getElementById('formDespesa').submit()")
        expect(self.page.get_by_role('alert')).to_contain_text('Gasto 2')
        expect(self.page.locator('input[name="funcionario_nome"]')).to_have_value('João')
        expect(self.page.locator('input[name="chave_envio"]')).to_have_value(key)
        expect(self.page.locator('#gastosDespesa [data-gasto]')).to_have_count(2)
        self.assertFalse(self.rows('SELECT * FROM despesas_operacionais'))
        self.assertFalse(self.rows('SELECT * FROM funcionarios'))
        self.fill_row(1,'100',tipo='transporte')
        expect(self.page.locator('#totalLancamentos')).to_have_text('R$ 1.775,00')
        self.page.locator('#formDespesa button[type="submit"]').click()
        expect(self.page.locator('#totalFuncionarios')).to_have_text('R$ 1.775,00')

    def test_live_cent_rounding_and_empty_form(self):
        self.fill_row(0,'0,105',description='DAS')
        self.page.locator('#adicionarGasto').click()
        self.fill_row(1,'0,20',description='ICMS')
        expect(self.page.locator('#totalLancamentos')).to_have_text('R$ 0,31')
        self.page.locator('#formDespesa button[type="submit"]').click()
        expect(self.page.locator('#totalImpostos')).to_have_text('R$ 0,31')
        self.page.get_by_role('button',name='Remover gasto 1',exact=True).click()
        expect(self.page.locator('#totalLancamentos')).to_have_text('R$ 0,00')
        expect(self.page.locator('#formDespesa button[type="submit"]')).to_be_disabled()
        self.page.locator('#adicionarGasto').click()
        expect(self.page.locator('#formDespesa button[type="submit"]')).to_be_enabled()

    def test_employee_items_mobile_layout(self):
        self.page.set_viewport_size({'width':390,'height':844})
        form = self.employee_form()
        self.fill_row(0,'1675',tipo='salario')
        self.page.locator('#adicionarGasto').click()
        self.fill_row(1,'100',tipo='transporte')
        self.page.locator('#adicionarGasto').click()
        self.fill_row(2,'200',tipo='comissoes')
        expect(self.page.locator('#totalLancamentos')).to_have_text('R$ 1.975,00')
        self.page.wait_for_load_state('load')
        self.assertTrue(self.page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), self.page.evaluate("Array.from(document.querySelectorAll('body *')).filter(e => e.getBoundingClientRect().right > innerWidth).map(e => ({tag:e.tagName,cls:e.className,width:e.getBoundingClientRect().width,right:e.getBoundingClientRect().right}))"))
        form.locator('button[type="submit"]').click()
        expect(self.page.locator('[data-total-funcionario]')).to_have_text('R$ 1.975,00')
        self.page.wait_for_load_state('load')
        self.assertTrue(self.page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), self.page.evaluate("Array.from(document.querySelectorAll('body *')).filter(e => e.getBoundingClientRect().right > innerWidth).map(e => ({tag:e.tagName,cls:e.className,width:e.getBoundingClientRect().width,right:e.getBoundingClientRect().right}))"))
        screenshot = os.environ.get('MEUFIADO_EXPENSE_SCREENSHOT')
        if screenshot:
            path = Path(screenshot)
            self.page.screenshot(path=str(path.with_stem(path.stem+'-mobile')),full_page=True)
