"""Security and transactional regression checks using isolated SQLite databases."""

from datetime import datetime, timedelta
from pathlib import Path
import tempfile
import time
import unittest

from flask import g

from meufiado import create_app
from meufiado.database import banco
from meufiado.services.contas import criar_conta
from meufiado.services.painel import dados_painel


class SecurityAndBusinessTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.app = create_app({
            'TESTING': True, 'DB_PATH': str(Path(cls.temp.name) / 'regression.db'),
        })
        with cls.app.app_context(), banco(escrita=True) as conn:
            cls.alice = criar_conta(conn, 'Alice', 'alice', 'password123')
            cls.bob = criar_conta(conn, 'Bob', 'bob', 'password123')
            cls.admin = criar_conta(conn, 'Administrator', 'admin', 'password123', admin=True)
            cls.password_hashes = {row['id']: row['senha_hash'] for row in conn.execute('SELECT id,senha_hash FROM contas')}

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def setUp(self):
        with self.app.app_context(), banco(escrita=True) as conn:
            for table in ('caixa_movimentos', 'venda_itens', 'vendas_negocio', 'vendas',
                          'clientes', 'produtos', 'fornecedores', 'tentativas_login'):
                conn.execute(f'DELETE FROM {table}')
            conn.execute('DELETE FROM contas WHERE id NOT IN (?, ?, ?)',
                         (self.alice, self.bob, self.admin))
            conn.execute("UPDATE contas SET ativo=1, versao_sessao=1, plano_status='ativo', "
                         "plano_tipo='unico', plano_vencimento=NULL")
            for uid, password_hash in self.password_hashes.items():
                conn.execute('UPDATE contas SET senha_hash=? WHERE id=?', (password_hash, uid))
            for cid, uid in ((1, self.alice), (2, self.bob)):
                conn.execute('INSERT INTO clientes (id,nome,celular,endereco,usuario_id) '
                             'VALUES (?,?,?,?,?)', (cid, 'Customer', '24999999999', f'Address {uid}', uid))
                conn.execute('INSERT INTO produtos (id,usuario_id,nome,preco_custo_centavos,'
                             'preco_venda_centavos,quantidade,estoque_minimo) VALUES (?,?,?,?,?,?,?)',
                             (cid, uid, f'Product {uid}', 200, 500, 10, 2))
                conn.execute('INSERT INTO fornecedores (id,usuario_id,nome) VALUES (?,?,?)',
                             (cid, uid, f'Supplier {uid}'))
        self.client = self.app.test_client()

    def login(self, client=None, login='alice', senha='password123'):
        client = client or self.client
        client.get('/login')
        return self.post('/login', client=client, data={'login': login, 'senha': senha})

    def post(self, url, client=None, **kwargs):
        client = client or self.client
        with client.session_transaction() as sessao:
            token = sessao.get('csrf_token', '')
        headers = {'X-CSRFToken': token, **kwargs.pop('headers', {})}
        return client.post(url, headers=headers, **kwargs)

    def rows(self, sql, args=()):
        with self.app.app_context(), banco() as conn:
            return [dict(row) for row in conn.execute(sql, args)]

    def execute(self, sql, args=()):
        with self.app.app_context(), banco(escrita=True) as conn:
            return conn.execute(sql, args).lastrowid

    def sale(self, forma='avista', itens=None, cliente_id=1, client=None):
        return self.post('/vendas', client=client, json={
            'forma_pagamento': forma, 'cliente_id': cliente_id,
            'itens': itens if itens is not None else [{'id': 1, 'quantidade': 2}],
        })

    def debt(self, valor='50'):
        return self.post('/registrar_fiado', data={
            'cliente_nome': 'Customer', 'produto': 'Purchase', 'valor': valor,
        })

    def balance(self, uid=None):
        with self.app.test_request_context(), banco() as conn:
            g.usuario = conn.execute('SELECT * FROM contas WHERE id=?', (uid or self.alice,)).fetchone()
            return dados_painel(conn)['a_receber']

    def test_public_and_protected_routes(self):
        for url in ('/', '/login', '/static/style.css'):
            response = self.client.get(url)
            try:
                self.assertEqual(response.status_code, 200, url)
            finally:
                response.close()
        for url in ('/painel', '/clientes', '/fiados', '/pagamentos', '/estoque',
                    '/fornecedores', '/vendas', '/relatorios', '/caixa', '/admin', '/contas'):
            r = self.client.get(url)
            self.assertEqual(r.status_code, 302, url)
            self.assertEqual(r.location, '/login')
        self.assertEqual(self.client.get('/painel/resumo').status_code, 401)
        for url in ('/logout', '/registrar_fiado', '/cadastrar_cliente', '/vendas', '/caixa'):
            self.assertEqual(self.client.post(url).status_code, 401, url)

    def test_authenticated_pages_and_security_headers(self):
        self.assertEqual(self.login().location, '/painel')
        for url in ('/', '/painel', '/clientes', '/fiados', '/pagamentos', '/painel/resumo',
                    '/estoque', '/fornecedores', '/vendas', '/relatorios', '/caixa'):
            r = self.client.get(url)
            self.assertEqual(r.status_code, 200, url)
            self.assertEqual(r.headers['Cache-Control'], 'no-store')
            self.assertIn('Cookie', r.headers['Vary'])
            self.assertEqual(r.headers['X-Content-Type-Options'], 'nosniff')
            self.assertEqual(r.headers['X-Frame-Options'], 'SAMEORIGIN')
            self.assertEqual(r.headers['Referrer-Policy'], 'same-origin')
        self.assertIn('page-clientes', self.client.get('/clientes').get_data(as_text=True))
        response = self.client.get('/static/style.css')
        try:
            self.assertNotIn('no-store', response.headers['Cache-Control'])
        finally:
            response.close()

    def test_csrf_token_and_same_origin_fallback(self):
        self.login()
        self.assertEqual(self.client.post('/cadastrar_cliente', data={'nome': 'Rejected'}).status_code, 400)
        self.assertEqual(self.client.post('/cadastrar_cliente', data={'nome': 'Rejected'},
                         headers={'X-CSRFToken': 'invalid'}).status_code, 400)
        with self.client.session_transaction() as sessao:
            token = sessao['csrf_token']
        self.assertEqual(self.client.post('/cadastrar_cliente', data={'nome': 'Form Token',
                         'csrf_token': token}).status_code, 302)
        self.assertEqual(self.post('/cadastrar_cliente', data={'nome': 'Header Token'}).status_code, 302)
        for header, value, name in (
            ('Origin', 'http://localhost', 'Same Origin'),
            ('Referer', 'http://localhost/clientes', 'Same Referer'),
        ):
            self.assertEqual(self.client.post('/cadastrar_cliente', data={'nome': name},
                             headers={header: value}).status_code, 302)
        for headers in ({'Origin': 'https://other.example'},
                        {'Origin': 'http://localhost:9999'},
                        {'Origin': 'http://localhost', 'X-CSRFToken': 'invalid'},
                        {'X-CSRFToken': token, 'Sec-Fetch-Site': 'cross-site'}):
            self.assertEqual(self.client.post('/cadastrar_cliente', data={'nome': 'Rejected'},
                             headers=headers).status_code, 400)
        self.assertFalse(self.rows("SELECT id FROM clientes WHERE nome='Rejected'"))

    def test_login_rotation_logout_and_session_version(self):
        self.client.get('/login')
        with self.client.session_transaction() as s:
            old_token = s['csrf_token']
            s['old_state'] = 'must be cleared'
        self.assertEqual(self.login().status_code, 302)
        with self.client.session_transaction() as s:
            self.assertNotEqual(s['csrf_token'], old_token)
            self.assertEqual(s['usuario_id'], self.alice)
            self.assertTrue(s.permanent)
            self.assertNotIn('old_state', s)
        self.execute('UPDATE contas SET versao_sessao=versao_sessao+1 WHERE id=?', (self.alice,))
        self.assertEqual(self.client.get('/painel/resumo').status_code, 401)
        self.login()
        self.assertEqual(self.client.get('/logout').status_code, 405)
        self.assertEqual(self.post('/logout').location, '/login')
        with self.client.session_transaction() as s:
            self.assertNotIn('usuario_id', s)
            self.assertNotIn('csrf_token', s)

    def test_inactive_suspended_and_expired_accounts(self):
        for assignment in ("ativo=0", "plano_status='suspenso'", "plano_vencimento='1999-01-01'"):
            with self.subTest(assignment=assignment):
                self.execute("UPDATE contas SET ativo=1, plano_status='ativo', plano_vencimento=NULL WHERE id=?",
                             (self.alice,))
                self.client = self.app.test_client()
                self.assertEqual(self.login().status_code, 302)
                self.execute(f'UPDATE contas SET {assignment} WHERE id=?', (self.alice,))
                self.assertEqual(self.client.get('/painel/resumo').status_code, 401)
                self.assertEqual(self.login().status_code, 401 if assignment=='ativo=0' else 403)

    def test_login_throttling_and_expiry(self):
        for _ in range(10):
            self.assertEqual(self.login(senha='wrong-password').status_code, 401)
        self.assertEqual(self.login().status_code, 429)
        self.execute('UPDATE tentativas_login SET instante=?', (time.time()-901,))
        self.assertEqual(self.login().status_code, 302)
        self.assertFalse(self.rows('SELECT * FROM tentativas_login'))

    def test_tenant_scoped_customer_and_debt_operations(self):
        self.login()
        self.assertEqual(self.debt().status_code, 200)
        self.assertEqual(self.balance(), 50)
        self.assertEqual(self.balance(self.bob), 0)
        self.assertEqual(self.post('/cadastrar_cliente', data={'nome': ' customer '}).status_code, 400)
        for url, data in (
            ('/editar_cliente/2', {'nome': 'Changed'}), ('/excluir_cliente/2', {}),
            ('/abater_fiado/2', {'valor_abatimento': '1'}), ('/pagar_total/2', {}),
        ):
            self.assertEqual(self.post(url, data=data).status_code, 404, url)
        self.assertEqual(self.rows('SELECT nome FROM clientes WHERE id=2')[0]['nome'], 'Customer')
        self.assertEqual(self.rows('SELECT cliente_id FROM vendas')[0]['cliente_id'], 1)
        bob_client = self.app.test_client()
        self.login(bob_client, login='bob')
        self.assertNotIn('Purchase', bob_client.get('/fiados').get_data(as_text=True))
        self.assertNotIn(f'Address {self.bob}', self.client.get('/clientes').get_data(as_text=True))

    def test_tenant_scoped_products_suppliers_sales_and_cash(self):
        self.login()
        product = {'nome': 'Changed', 'preco_venda': '5', 'quantidade': '10', 'estoque_minimo': '0'}
        for url, data in (
            ('/estoque/produto/2/editar', product), ('/estoque/produto/2/excluir', {}),
            ('/fornecedor/2/editar', {'nome': 'Changed'}), ('/fornecedor/2/excluir', {}),
        ):
            self.assertEqual(self.post(url, data=data).status_code, 404, url)
        self.assertEqual(self.sale(itens=[{'id':2,'quantidade':1}]).status_code, 404)
        self.assertEqual(self.sale(forma='fiado', cliente_id=2).status_code, 404)
        movement = self.execute("INSERT INTO caixa_movimentos (usuario_id,tipo,descricao,valor_centavos,data) "
                                "VALUES (?,'entrada','Other account',100,'2020-01-01')", (self.bob,))
        self.assertEqual(self.post(f'/caixa/{movement}/excluir').status_code, 404)
        self.assertNotIn(f'Product {self.bob}', self.client.get('/estoque').get_data(as_text=True))
        self.assertNotIn(f'Supplier {self.bob}', self.client.get('/fornecedores').get_data(as_text=True))
        self.assertFalse(self.rows('SELECT * FROM vendas_negocio'))
        self.assertEqual(self.rows('SELECT quantidade FROM produtos WHERE id=2')[0]['quantidade'], 10)

    def test_cash_sale_aggregates_items_and_updates_inventory(self):
        self.login()
        r = self.sale(itens=[{'id':1,'quantidade':2}, {'id':1,'quantidade':3}])
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.json['sucesso'])
        self.assertEqual(self.rows('SELECT quantidade FROM produtos WHERE id=1')[0]['quantidade'], 5)
        self.assertEqual(self.rows('SELECT quantidade FROM venda_itens')[0]['quantidade'], 5)
        sale = self.rows('SELECT * FROM vendas_negocio')[0]
        self.assertEqual(sale['total_centavos'], 2500)
        self.assertIsNone(sale['cliente_id'])
        movement = self.rows('SELECT * FROM caixa_movimentos')[0]
        self.assertEqual(movement['valor_centavos'], 2500)
        self.assertEqual(movement['venda_negocio_id'], r.json['venda_id'])
        self.assertEqual(self.post(f"/caixa/{movement['id']}/excluir").status_code, 400)
        self.assertFalse(self.rows('SELECT * FROM vendas'))

    def test_credit_sale_and_payments_reconcile_cash(self):
        self.login()
        self.assertEqual(self.sale(forma='fiado').status_code, 200)
        self.assertEqual(self.balance(), 10)
        self.assertFalse(self.rows('SELECT * FROM caixa_movimentos'))
        self.assertEqual(self.post('/abater_fiado/1', data={'valor_abatimento': '3'}).status_code, 302)
        self.assertEqual(self.balance(), 7)
        self.assertEqual(self.post('/pagar_total/1').status_code, 302)
        self.assertEqual(self.balance(), 0)
        movements = self.rows('SELECT * FROM caixa_movimentos ORDER BY id')
        self.assertEqual([m['valor_centavos'] for m in movements], [300, 700])
        self.assertTrue(all(m['origem']=='fiado' for m in movements))
        self.assertTrue(all(v['status']=='pago' for v in self.rows('SELECT * FROM vendas')))
        self.assertEqual(self.post('/pagar_total/1').status_code, 400)
        self.assertEqual(len(self.rows('SELECT * FROM caixa_movimentos')), 2)
        self.assertEqual(self.post(f"/caixa/{movements[0]['id']}/excluir").status_code, 400)

    def test_invalid_sales_do_not_mutate_any_business_table(self):
        self.login()
        for items in ([], 'invalid', [None], [{'id':1,'quantidade':0}],
                      [{'id':1,'quantidade':11}], [{'id':1,'quantidade':'bad'}]):
            self.assertEqual(self.sale(itens=items).status_code, 400, items)
        self.assertEqual(self.sale(forma='invalid').status_code, 400)
        self.assertEqual(self.sale(forma='fiado', cliente_id='bad').status_code, 400)
        for table in ('vendas_negocio', 'venda_itens', 'caixa_movimentos', 'vendas'):
            self.assertFalse(self.rows(f'SELECT * FROM {table}'))
        self.assertEqual(self.rows('SELECT quantidade FROM produtos WHERE id=1')[0]['quantidade'], 10)

    def test_database_write_context_rolls_back_all_changes(self):
        with self.assertRaises(RuntimeError):
            with self.app.app_context(), banco(escrita=True) as conn:
                conn.execute('UPDATE produtos SET quantidade=0 WHERE id=1')
                conn.execute("INSERT INTO clientes (nome,usuario_id) VALUES ('Rollback',?)", (self.alice,))
                raise RuntimeError('abort transaction')
        self.assertEqual(self.rows('SELECT quantidade FROM produtos WHERE id=1')[0]['quantidade'], 10)
        self.assertFalse(self.rows("SELECT id FROM clientes WHERE nome='Rollback'"))

    def test_form_encoded_sales_keep_the_existing_json_response(self):
        self.login()
        r = self.post('/vendas', data={'forma_pagamento': 'avista',
                                     'itens': '[{"id":1,"quantidade":1}]'})
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.json['sucesso'])
        self.assertEqual(self.rows('SELECT total_centavos FROM vendas_negocio')[0]['total_centavos'], 500)
        self.assertEqual(self.post('/vendas', data={'forma_pagamento': 'avista', 'itens': 'invalid'}).status_code, 400)

    def test_product_validation_edit_and_soft_deletion(self):
        self.login()
        data = {'nome': ' New   product ', 'preco_custo': '2,50', 'preco_venda': '4,25',
                'quantidade': '3', 'estoque_minimo': '1', 'categoria': ' Food '}
        self.assertEqual(self.post('/estoque', data=data).status_code, 302)
        product = self.rows("SELECT * FROM produtos WHERE nome='New product'")[0]
        self.assertEqual(product['preco_custo_centavos'], 250)
        self.assertEqual(product['preco_venda_centavos'], 425)
        self.post('/estoque', data={**data, 'nome':'new product'})
        self.assertEqual(len(self.rows('SELECT * FROM produtos')), 3)
        self.post('/estoque', data={**data, 'nome':'Invalid', 'quantidade':'-1'})
        self.assertFalse(self.rows("SELECT id FROM produtos WHERE nome='Invalid'"))
        pid = product['id']
        self.assertEqual(self.post(f'/estoque/produto/{pid}/editar',
                                  data={**data, 'quantidade':'5'}).status_code, 302)
        self.assertEqual(self.rows('SELECT quantidade FROM produtos WHERE id=?', (pid,))[0]['quantidade'], 5)
        self.assertEqual(self.post(f'/estoque/produto/{pid}/excluir').status_code, 302)
        self.assertEqual(self.rows('SELECT ativo FROM produtos WHERE id=?', (pid,))[0]['ativo'], 0)
        self.assertEqual(self.sale(itens=[{'id':pid,'quantidade':1}]).status_code, 404)

    def test_supplier_create_edit_and_soft_deletion(self):
        self.login()
        self.assertEqual(self.post('/fornecedores', data={'nome':' New   supplier ',
                         'telefone':' 123 ', 'contato':'Person', 'observacao':'Notes'}).status_code, 302)
        supplier = self.rows("SELECT * FROM fornecedores WHERE nome='New supplier'")[0]
        self.assertEqual(supplier['usuario_id'], self.alice)
        sid = supplier['id']
        self.assertEqual(self.post(f'/fornecedor/{sid}/editar', data={'nome':'Edited'}).status_code, 302)
        self.assertEqual(self.rows('SELECT nome FROM fornecedores WHERE id=?', (sid,))[0]['nome'], 'Edited')
        self.assertEqual(self.post(f'/fornecedor/{sid}/excluir').status_code, 302)
        self.assertEqual(self.rows('SELECT ativo FROM fornecedores WHERE id=?', (sid,))[0]['ativo'], 0)
        self.assertNotIn('Edited', self.client.get('/fornecedores').get_data(as_text=True))

    def test_manual_cash_entries_and_date_validation(self):
        self.login()
        today = datetime.now().strftime('%Y-%m-%d')
        data = {'tipo':'saida','descricao':'Expense','valor':'2,50','data':today}
        self.assertEqual(self.post('/caixa', data=data).status_code, 302)
        movement = self.rows('SELECT * FROM caixa_movimentos')[0]
        self.assertEqual(movement['valor_centavos'], 250)
        self.assertEqual(movement['usuario_id'], self.alice)
        self.assertEqual(self.post(f"/caixa/{movement['id']}/excluir").status_code, 302)
        self.assertFalse(self.rows('SELECT * FROM caixa_movimentos'))
        tomorrow = (datetime.now()+timedelta(days=1)).strftime('%Y-%m-%d')
        for changes in ({'data':tomorrow}, {'data':'2026-02-30'}, {'tipo':'invalid'},
                        {'valor':'0'}, {'valor':'nan'}, {'descricao':''}):
            self.assertEqual(self.post('/caixa', data={**data,**changes}).status_code, 400)
        for url in ('/caixa?inicio=bad', '/relatorios?inicio=bad',
                    '/caixa?inicio=2026-02-02&fim=2026-01-01',
                    '/relatorios?inicio=2026-02-02&fim=2026-01-01'):
            self.assertEqual(self.client.get(url).status_code, 400)
        self.assertFalse(self.rows('SELECT * FROM caixa_movimentos'))

    def test_reports_reconcile_sales_cash_and_debts_by_account(self):
        from flask import template_rendered
        self.login()
        self.sale()
        self.sale(forma='fiado', itens=[{'id':1,'quantidade':3}])
        self.post('/abater_fiado/1', data={'valor_abatimento':'5'})
        today = datetime.now().strftime('%Y-%m-%d')
        self.post('/caixa', data={'tipo':'saida','descricao':'Expense','valor':'2','data':today})
        bob_client = self.app.test_client()
        self.login(bob_client, login='bob')
        self.sale(itens=[{'id':2,'quantidade':1}], client=bob_client)
        contexts = []
        def record(sender, template, context, **extra):
            contexts.append(context)
        with template_rendered.connected_to(record, self.app):
            r = self.client.get(f'/relatorios?inicio={today}&fim={today}')
        self.assertEqual(r.status_code, 200)
        report = contexts[-1]
        for key, value in {'total_vendas':25, 'quantidade_vendas':2, 'recebimentos':15,
                           'despesas':2, 'resultado':13, 'total_a_receber':10,
                           'clientes_devedores':1, 'produtos_vendidos':5, 'estoque_baixo':0}.items():
            self.assertEqual(report[key], value, key)
        self.assertEqual(report['ranking_produtos'][0]['quantidade'], 5)
        self.assertEqual(len(report['ranking_produtos']), 1)

    def test_admin_authorization_registration_and_session_revocation(self):
        self.login()
        self.assertEqual(self.client.get('/admin').status_code, 403)
        self.assertEqual(self.post(f'/admin/usuario/{self.bob}/status').status_code, 403)
        admin_client = self.app.test_client()
        self.assertEqual(self.login(admin_client, login='admin').location, '/admin')
        for url in ('/admin', '/contas'):
            self.assertEqual(admin_client.get(url).status_code, 200)
        self.assertEqual(self.post('/admin', client=admin_client, data={
            'nome':'New account', 'login':'new-account', 'senha':'password123',
            'plano_tipo':'mensal', 'plano_valor':'39,90',
        }).status_code, 302)
        account = self.rows("SELECT * FROM contas WHERE login='new-account'")[0]
        self.assertEqual(account['plano_valor_centavos'], 3990)
        self.assertIsNotNone(account['plano_vencimento'])
        self.assertEqual(self.post(f'/admin/usuario/{self.alice}/status', client=admin_client).status_code, 302)
        self.assertEqual(self.client.get('/painel/resumo').status_code, 401)
        self.assertEqual(self.rows('SELECT ativo FROM contas WHERE id=?', (self.alice,))[0]['ativo'], 0)
        self.assertEqual(self.post(f'/admin/usuario/{self.admin}/status', client=admin_client).status_code, 302)
        self.assertEqual(self.rows('SELECT ativo FROM contas WHERE id=?', (self.admin,))[0]['ativo'], 1)
        self.assertEqual(self.post(f"/admin/usuario/{account['id']}/excluir", client=admin_client).status_code, 302)
        self.assertFalse(self.rows('SELECT id FROM contas WHERE id=?', (account['id'],)))

    def test_admin_plan_and_password_changes(self):
        self.login()
        admin_client = self.app.test_client()
        self.login(admin_client, login='admin')
        r = self.post(f'/admin/usuario/{self.alice}/senha', client=admin_client, data={'senha':'new-password'})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.client.get('/painel/resumo').status_code, 401)
        self.assertEqual(self.login(senha='new-password').status_code, 302)
        self.assertEqual(self.post(f'/admin/usuario/{self.alice}/plano', client=admin_client,
                         data={'plano_tipo':'unico','plano_status':'suspenso'}).status_code, 302)
        self.assertEqual(self.client.get('/painel/resumo').status_code, 401)
        self.assertEqual(self.login(senha='new-password').status_code, 403)

    def test_cli_context_password_reset_and_explicit_legacy_assignment(self):
        runner = self.app.test_cli_runner()
        r = runner.invoke(args=['criar-usuario','--nome','CLI User','--login','cli-user',
                                '--senha','password123','--admin'])
        self.assertEqual(r.exit_code, 0, r.output)
        self.assertEqual(self.rows("SELECT admin FROM contas WHERE login='cli-user'")[0]['admin'], 1)
        self.execute("INSERT INTO clientes (nome) VALUES ('Legacy Customer')")
        r = runner.invoke(args=['atribuir-dados-antigos','--login','alice'])
        self.assertNotEqual(r.exit_code, 0)
        self.assertIsNone(self.rows("SELECT usuario_id FROM clientes WHERE nome='Legacy Customer'")[0]['usuario_id'])
        r = runner.invoke(args=['atribuir-dados-antigos','--login','alice','--confirmar'])
        self.assertEqual(r.exit_code, 0, r.output)
        self.assertEqual(self.rows("SELECT usuario_id FROM clientes WHERE nome='Legacy Customer'")[0]['usuario_id'], self.alice)
        self.login()
        r = runner.invoke(args=['redefinir-senha','--login','alice','--senha','cli-password'])
        self.assertEqual(r.exit_code, 0, r.output)
        self.assertEqual(self.client.get('/painel/resumo').status_code, 401)
        self.assertEqual(self.login(senha='cli-password').status_code, 302)
