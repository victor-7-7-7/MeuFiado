"""Actual sales-page submissions against a Flask server and temporary SQLite DB.

Install requirements-dev.txt. Windows uses installed Edge by default; elsewhere
run `python -m playwright install chromium`. MEUFIADO_TEST_BROWSER_CHANNEL can
select another installed browser, or use 'chromium' for Playwright's browser.
"""

import os
from pathlib import Path
import tempfile
import threading
import unittest
from urllib.parse import urlsplit

from werkzeug.serving import WSGIRequestHandler, make_server

from meufiado import create_app
from meufiado.database import banco
from meufiado.services.contas import criar_conta

try:
    from playwright.sync_api import Error, expect, sync_playwright
except ImportError:
    sync_playwright = None


class QuietRequestHandler(WSGIRequestHandler):
    def log(self, type, message, *args):
        pass


@unittest.skipUnless(sync_playwright, 'Install requirements-dev.txt for browser regression tests.')
class SalesBrowserTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        expect.set_options(timeout=15000)
        cls.playwright = sync_playwright().start()
        cls.addClassCleanup(cls.playwright.stop)
        channel = os.environ.get('MEUFIADO_TEST_BROWSER_CHANNEL', 'msedge' if os.name=='nt' else 'chromium')
        try:
            cls.browser = cls.playwright.chromium.launch(
                headless=True, **({'channel':channel} if channel!='chromium' else {}),
            )
        except Error as exc:
            if 'not found' in str(exc) or "Executable doesn't exist" in str(exc):
                raise unittest.SkipTest('Install Edge or run python -m playwright install chromium.') from exc
            raise
        cls.addClassCleanup(cls.browser.close)
        cls.temp = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.temp.cleanup)
        cls.app = create_app({
            'TESTING':True, 'DB_PATH':str(Path(cls.temp.name)/'sales.db'),
            'SECRET_KEY':'sales-browser-test-secret', 'SESSION_COOKIE_SECURE':False,
        })
        with cls.app.app_context(), banco(escrita=True) as conn:
            cls.uid = criar_conta(conn, 'Seller', 'seller', 'password123')
            cls.other = criar_conta(conn, 'Other', 'other', 'password123')
        cls.server = make_server('127.0.0.1', 0, cls.app, threaded=True,
                                 request_handler=QuietRequestHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base_url = f'http://127.0.0.1:{cls.server.server_port}'
        cls.addClassCleanup(cls.stop_server)

    @classmethod
    def stop_server(cls):
        cls.server.shutdown()
        cls.thread.join(timeout=5)
        cls.server.server_close()

    def setUp(self):
        with self.app.app_context(), banco(escrita=True) as conn:
            for table in ('caixa_movimentos','venda_itens','vendas_negocio','vendas',
                          'clientes','produtos','tentativas_login'):
                conn.execute(f'DELETE FROM {table}')
            conn.execute('UPDATE contas SET versao_sessao=1')
            for cid, uid, name in ((1,self.uid,'Customer'),(2,self.other,'Other Customer')):
                conn.execute('INSERT INTO clientes (id,nome,usuario_id) VALUES (?,?,?)', (cid,name,uid))
            for pid, uid, name, stock, price in (
                (1,self.uid,'Bread',10,500), (2,self.uid,'Milk',1,700),
                (3,self.other,'Other product',20,900),
            ):
                conn.execute('INSERT INTO produtos (id,usuario_id,nome,quantidade,preco_venda_centavos) '
                             'VALUES (?,?,?,?,?)', (pid,uid,name,stock,price))
        self.context = self.browser.new_context()
        self.addCleanup(self.close_browser_context)
        # Marketing/footer images must not make local sale tests depend on the Internet.
        self.context.route('**/*', lambda route: route.continue_()
                           if urlsplit(route.request.url).netloc==urlsplit(self.base_url).netloc
                           else route.abort())
        self.page = self.context.new_page()
        self.page.goto(self.base_url+'/login', wait_until='domcontentloaded')
        self.page.locator('input[name="login"]').fill('seller')
        self.page.locator('input[name="senha"]').fill('password123')
        self.page.locator('button[type="submit"]').click()
        self.page.wait_for_url(self.base_url+'/painel', wait_until='domcontentloaded')
        self.page.goto(self.base_url+'/vendas', wait_until='domcontentloaded')
        self.posts = []
        self.page.on('request', lambda r: self.posts.append(r)
                     if r.method=='POST' and urlsplit(r.url).path=='/vendas' else None)

    def close_browser_context(self):
        try:
            if self.context.pages:
                # Finish local static responses before disconnecting the test browser.
                self.context.pages[0].wait_for_load_state('networkidle')
        finally:
            self.context.close()

    def rows(self, sql, args=()):
        with self.app.app_context(), banco() as conn:
            return [dict(row) for row in conn.execute(sql,args)]

    def add_product(self, pid='1', quantity='2'):
        self.page.locator('#produtoVenda').select_option(pid)
        self.page.locator('#quantidadeVenda').fill(quantity)
        self.page.locator('#adicionarVenda').click()

    def assert_no_sale(self):
        for table in ('vendas_negocio','venda_itens','caixa_movimentos','vendas'):
            self.assertFalse(self.rows(f'SELECT * FROM {table}'),table)
        self.assertEqual(self.rows('SELECT quantidade FROM produtos WHERE id=1')[0]['quantidade'],10)

    def test_cash_sale_button_double_click_persists_once_and_refreshes_stock(self):
        expect(self.page.locator('#finalizarVenda')).to_be_disabled()
        self.add_product(quantity='2')
        self.add_product(quantity='3')
        # Force a second event even on a disabled button to exercise the JS guard.
        self.page.evaluate('''() => {
            const button = document.getElementById('finalizarVenda');
            button.click();
            button.dispatchEvent(new MouseEvent('click', {bubbles:true}));
            adicionarProdutoVenda();
            removerProdutoVenda(0);
        }''')
        expect(self.page.locator('#mensagemVenda')).to_have_text('Venda registrada com sucesso.')
        expect(self.page.locator('#produtoVenda option[value="1"]')).to_contain_text('Estoque: 5')
        expect(self.page.locator('#finalizarVenda')).to_be_disabled()
        expect(self.page.locator('#totalItens')).to_have_text('0')
        expect(self.page.locator('#totalVenda')).to_have_text('R$ 0,00')
        self.page.evaluate("document.getElementById('finalizarVenda').dispatchEvent(new MouseEvent('click'))")
        self.assertEqual(len(self.posts),1)
        request = self.posts[0]
        self.assertEqual(request.post_data_json, {'forma_pagamento':'avista','cliente_id':None,
                                                 'itens':[{'id':1,'quantidade':2},{'id':1,'quantidade':3}]})
        self.assertEqual(request.headers['x-csrftoken'],
                         self.page.locator('meta[name="csrf-token"]').get_attribute('content'))
        self.assertEqual(self.rows('SELECT quantidade FROM produtos WHERE id=1')[0]['quantidade'],5)
        self.assertEqual(len(self.rows('SELECT * FROM vendas_negocio')),1)
        self.assertEqual(self.rows('SELECT quantidade,total_centavos FROM venda_itens'),
                         [{'quantidade':5,'total_centavos':2500}])
        self.assertEqual(self.rows('SELECT valor_centavos,venda_negocio_id FROM caixa_movimentos')[0]['valor_centavos'],2500)
        self.assertFalse(self.rows('SELECT * FROM vendas'))

    def test_credit_sale_requires_customer_then_creates_debt_and_reduces_stock(self):
        self.add_product()
        self.page.locator('input[value="fiado"]').check()
        self.page.locator('#finalizarVenda').click()
        expect(self.page.locator('#mensagemVenda')).to_have_text('Selecione um cliente para vender no fiado.')
        self.assertEqual(len(self.posts),0)
        self.assert_no_sale()
        self.page.locator('#clienteVenda').select_option('1')
        self.page.locator('#finalizarVenda').click()
        expect(self.page.locator('#produtoVenda option[value="1"]')).to_contain_text('Estoque: 8')
        expect(self.page.locator('#finalizarVenda')).to_be_disabled()
        self.assertEqual(len(self.posts),1)
        self.assertEqual(self.posts[0].post_data_json['cliente_id'],1)
        self.assertEqual(self.rows('SELECT quantidade FROM produtos WHERE id=1')[0]['quantidade'],8)
        self.assertEqual(self.rows('SELECT cliente_id,valor,status FROM vendas'),
                         [{'cliente_id':1,'valor':10.0,'status':'fiado'}])
        self.assertFalse(self.rows('SELECT * FROM caixa_movimentos'))

    def test_insufficient_stock_displays_server_error_and_keeps_cart(self):
        self.add_product(quantity='11')
        self.page.locator('#finalizarVenda').click()
        expect(self.page.locator('#mensagemVenda')).to_contain_text('Estoque insuficiente para Bread.')
        expect(self.page.locator('#mensagemVenda')).to_contain_text('Dispon')
        expect(self.page.locator('#totalQuantidade')).to_have_text('11')
        expect(self.page.locator('#finalizarVenda')).to_be_enabled()
        self.assertEqual(len(self.posts),1)
        self.assert_no_sale()

    def test_partial_stock_validation_failure_rolls_back_entire_sale(self):
        self.add_product()
        self.add_product(pid='2',quantity='2')
        self.page.locator('#finalizarVenda').click()
        expect(self.page.locator('#mensagemVenda')).to_contain_text('Estoque insuficiente para Milk.')
        self.assert_no_sale()
        self.assertEqual(self.rows('SELECT quantidade FROM produtos WHERE id=2')[0]['quantidade'],1)

    def test_tampered_product_id_cannot_reduce_another_accounts_stock(self):
        self.page.evaluate('''() => {
            const select=document.getElementById('produtoVenda');
            const option=document.createElement('option');
            option.value='3'; option.dataset.nome='Other product'; option.dataset.preco='9';
            option.textContent='Other product'; select.appendChild(option);
        }''')
        self.add_product(pid='3',quantity='1')
        with self.page.expect_response(lambda r: r.request.method=='POST' and urlsplit(r.url).path=='/vendas') as response:
            self.page.locator('#finalizarVenda').click()
        self.assertEqual(response.value.status,404)
        expect(self.page.locator('#mensagemVenda')).to_contain_text('404: Not Found')
        expect(self.page.locator('#mensagemVenda')).not_to_contain_text('<html')
        self.assertEqual(self.rows('SELECT quantidade FROM produtos WHERE id=3')[0]['quantidade'],20)
        self.assert_no_sale()

    def test_invalid_csrf_displays_plain_server_error_without_changing_stock(self):
        self.add_product()
        self.page.locator('meta[name="csrf-token"]').evaluate("el => el.content='wrong-token'")
        self.page.locator('#finalizarVenda').click()
        expect(self.page.locator('#mensagemVenda')).to_contain_text('Atualize a p')
        expect(self.page.locator('#totalItens')).to_have_text('1')
        expect(self.page.locator('#finalizarVenda')).to_be_enabled()
        self.assert_no_sale()

    def test_expired_session_displays_actual_error_and_keeps_cart(self):
        self.add_product()
        with self.app.app_context(), banco(escrita=True) as conn:
            conn.execute('UPDATE contas SET versao_sessao=2 WHERE id=?',(self.uid,))
        self.page.locator('#finalizarVenda').click()
        expect(self.page.locator('#mensagemVenda')).to_contain_text('Entre novamente em /login.')
        expect(self.page.locator('#totalItens')).to_have_text('1')
        self.assert_no_sale()

    def test_successful_sale_is_not_reposted_when_stock_refresh_fails(self):
        self.add_product()
        self.page.route('**/vendas', lambda route: route.fulfill(status=503,body='Refresh unavailable')
                        if route.request.method=='GET' else route.continue_())
        self.page.locator('#finalizarVenda').click()
        expect(self.page.locator('#mensagemVenda')).to_contain_text('Venda registrada com sucesso.')
        expect(self.page.locator('#mensagemVenda')).to_contain_text('consultar o novo estoque.')
        expect(self.page.locator('#finalizarVenda')).to_be_disabled()
        expect(self.page.locator('#totalItens')).to_have_text('0')
        self.assertEqual(len(self.posts),1)
        self.assertEqual(self.rows('SELECT quantidade FROM produtos WHERE id=1')[0]['quantidade'],8)
        self.assertEqual(len(self.rows('SELECT * FROM vendas_negocio')),1)

    def test_network_failure_does_not_clear_cart_or_retry_automatically(self):
        self.add_product()
        self.page.route('**/vendas', lambda route: route.abort('failed')
                        if route.request.method=='POST' else route.continue_())
        self.page.locator('#finalizarVenda').click()
        expect(self.page.locator('#mensagemVenda')).to_contain_text('Confira as vendas e o estoque')
        expect(self.page.locator('#totalItens')).to_have_text('1')
        expect(self.page.locator('#finalizarVenda')).to_be_enabled()
        self.assertEqual(len(self.posts),1)
        self.assert_no_sale()

    def test_empty_sale_and_fractional_quantity_do_not_submit(self):
        self.page.evaluate("document.getElementById('finalizarVenda').dispatchEvent(new MouseEvent('click'))")
        expect(self.page.locator('#mensagemVenda')).to_have_text('Adicione pelo menos um produto.')
        self.add_product(quantity='1.5')
        expect(self.page.locator('#mensagemVenda')).to_contain_text('quantidade inteira')
        expect(self.page.locator('#finalizarVenda')).to_be_disabled()
        self.assertEqual(len(self.posts),0)
        self.assert_no_sale()
