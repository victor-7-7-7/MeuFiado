"""Testes com banco temporário. Nunca alteram o sistema_fiado.db do projeto."""
from pathlib import Path
import tempfile
import unittest
from types import SimpleNamespace

from flask import g
from meufiado import create_app
from meufiado.database import banco, get_db_connection
from meufiado.services.contas import criar_conta
from meufiado.services.painel import dados_painel


class FluxosFiadoTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        caminho = Path(cls.temp.name) / 'teste.db'
        app = create_app({'DB_PATH': str(caminho), 'TESTING': True})
        cls.mod = SimpleNamespace(
            app=app,
            get_db_connection=lambda: get_db_connection(db_path=str(caminho)),
        )
        with app.app_context(), banco(escrita=True) as conn:
            cls.usuario_id = criar_conta(conn, 'Conta de teste', 'teste', 'senha-teste')

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def setUp(self):
        with self.mod.app.app_context(), banco(escrita=True) as conn:
            conn.execute('DELETE FROM caixa_movimentos')
            conn.execute('DELETE FROM vendas')
            conn.execute('DELETE FROM clientes')
            conn.execute('INSERT INTO clientes (id,nome,celular,endereco,usuario_id) VALUES (1,?,?,?,?)',
                         ('João da Silva', '24999999999', 'Rua de Teste', self.usuario_id))
        self.client = self.mod.app.test_client()
        self.client.get('/login')
        resposta = self.post('/login', data={'login': 'teste', 'senha': 'senha-teste'})
        self.assertEqual(resposta.status_code, 302)

    def post(self, url, **kwargs):
        with self.client.session_transaction() as sessao:
            token = sessao['csrf_token']
        return self.client.post(url, headers={'X-CSRFToken': token}, **kwargs)

    def compra(self, valor='100', produto='Compra de teste'):
        return self.post('/registrar_fiado', data={'cliente_nome': '  João da Silva  ', 'produto': produto, 'valor': valor})

    def saldo(self):
        with self.mod.app.test_request_context('/painel'), banco() as conn:
            g.usuario = conn.execute('SELECT * FROM contas WHERE id=?', (self.usuario_id,)).fetchone()
            return dados_painel(conn)

    def test_telas_e_estado_vazio(self):
        for rota in ['/', '/painel', '/clientes', '/fiados', '/pagamentos', '/painel/resumo']:
            with self.subTest(rota=rota):
                self.assertEqual(self.client.get(rota).status_code, 200)
        self.assertIn('Tudo em dia', self.client.get('/painel').get_data(as_text=True))

    def test_cadastro_edicao_e_exclusao(self):
        self.assertEqual(self.post('/cadastrar_cliente', data={'nome':'  Ana   Costa ', 'celular':'24988888888','endereco':'Centro'}).status_code,302)
        conn = self.mod.get_db_connection()
        cid = conn.execute('SELECT id FROM clientes WHERE nome = ?', ('Ana Costa',)).fetchone()[0]
        conn.close()
        self.assertEqual(self.post(f'/editar_cliente/{cid}',data={'nome':'Ana Souza','celular':'24988888888','endereco':'Rua Nova'}).status_code,302)
        self.assertIn('Ana Souza',self.client.get('/clientes').get_data(as_text=True))
        self.post('/registrar_fiado',data={'cliente_nome':'Ana Souza','produto':'Teste','valor':'20'})
        self.assertEqual(self.post(f'/excluir_cliente/{cid}').status_code,302)
        conn = self.mod.get_db_connection()
        self.assertEqual(conn.execute('SELECT COUNT(*) FROM vendas WHERE cliente_id=?',(cid,)).fetchone()[0],0)
        conn.close()

    def test_resumo_e_abatimento(self):
        self.assertEqual(self.compra('1.234,56').status_code,200)
        self.assertAlmostEqual(self.saldo()['a_receber'],1234.56)
        self.post('/abater_fiado/1',data={'valor_abatimento':'234,56'})
        self.assertAlmostEqual(self.saldo()['a_receber'],1000)
        self.assertEqual(self.saldo()['fiados_abertos'],1)
        self.assertIn('R$ 1.000,00',self.client.get('/fiados').get_data(as_text=True))
        self.assertIn('R$ 1.000,00',self.client.get('/painel/resumo').json['html'])
        self.assertIn('Abatimento',self.client.get('/pagamentos').get_data(as_text=True))

    def test_contas_anteriores_nao_quitam_compra_nova(self):
        self.compra('200')
        self.post('/pagar_total/1')
        self.compra('100')
        self.post('/abater_fiado/1',data={'valor_abatimento':'20'})
        self.assertAlmostEqual(self.saldo()['a_receber'],80)
        self.assertEqual(self.saldo()['compras_quitadas'],1)
        self.post('/abater_fiado/1',data={'valor_abatimento':'80'})
        self.assertEqual(self.saldo()['a_receber'],0)
        self.assertEqual(self.saldo()['compras_quitadas'],2)
        self.assertEqual(self.saldo()['fiados_abertos'],0)

    def test_valores_invalidos_nao_alteram_saldo(self):
        for valor in ['-10','0','nan','inf','', 'texto']:
            with self.subTest(valor=valor):
                self.assertEqual(self.compra(valor).status_code,400)
        self.compra('50')
        for valor in ['0','-5','60','nan']:
            self.assertEqual(self.post('/abater_fiado/1',data={'valor_abatimento':valor}).status_code,400)
        self.assertEqual(self.saldo()['a_receber'],50)
        self.assertEqual(self.post('/registrar_fiado',data={'cliente_nome':'Não existe','produto':'Pão','valor':'5'}).status_code,400)

    def test_escapamento_e_link_whatsapp(self):
        self.compra('20', '<script>alert(1)</script>')
        html = self.client.get('/fiados').get_data(as_text=True)
        self.assertIn('&lt;script&gt;',html)
        self.assertNotIn('<script>alert(1)</script>',html)
        self.assertIn('https://wa.me/5524999999999?',html)


if __name__ == '__main__':
    unittest.main()
