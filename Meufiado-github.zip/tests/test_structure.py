"""Factory, startup, route-contract and legacy migration compatibility checks."""

from datetime import timedelta
import importlib.util
import gc
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest
import warnings
from unittest.mock import patch

from meufiado import create_app
from meufiado.config import BASE_DIR
from meufiado.database import banco, init_db
from meufiado.services.contas import criar_conta


class ApplicationStructureTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db = str(Path(self.temp.name) / 'test.db')
        self.app = create_app({'TESTING': True, 'DB_PATH': self.db})

    def test_original_route_and_cli_contract(self):
        actual = [
            {'rule':r.rule, 'endpoint':r.endpoint, 'methods':sorted(r.methods), 'defaults':r.defaults}
            for r in self.app.url_map.iter_rules()
        ]
        self.assertEqual(actual[:len(ORIGINAL_ROUTES)], ORIGINAL_ROUTES)
        self.assertTrue(all(route['rule'].startswith('/despesas') for route in actual[len(ORIGINAL_ROUTES):]))
        self.assertEqual(sorted(self.app.cli.commands),
                         ['atribuir-dados-antigos', 'criar-usuario', 'redefinir-senha'])

    def test_factory_apps_use_independent_databases_and_secrets(self):
        second_db = str(Path(self.temp.name) / 'second.db')
        second = create_app({'TESTING':True, 'DB_PATH':second_db})
        with self.app.app_context(), banco(escrita=True) as conn:
            criar_conta(conn, 'First', 'first', 'password123')
        with second.app_context(), banco() as conn:
            self.assertEqual(conn.execute('SELECT COUNT(*) FROM contas').fetchone()[0], 0)
        self.assertNotEqual(self.app.secret_key, second.secret_key)
        reopened = create_app({'TESTING':True, 'DB_PATH':self.db})
        self.assertEqual(reopened.secret_key, self.app.secret_key)
        with reopened.app_context(), banco() as conn:
            self.assertEqual(conn.execute('SELECT login FROM contas').fetchone()[0], 'first')
            self.assertEqual(conn.execute('PRAGMA foreign_keys').fetchone()[0], 1)

    def test_environment_config_cookie_settings_and_explicit_overrides(self):
        env_db = str(Path(self.temp.name) / 'environment.db')
        with patch.dict(os.environ, {'MEUFIADO_DB_PATH':env_db, 'MEUFIADO_HTTPS':'1',
                                     'MEUFIADO_SECRET_KEY':'environment-test-secret'}):
            app = create_app({'TESTING':True})
            override = create_app({'TESTING':True, 'DB_PATH':self.db, 'SECRET_KEY':'explicit-test-secret'})
        self.assertEqual(app.config['DB_PATH'], env_db)
        self.assertEqual(app.secret_key, 'environment-test-secret')
        self.assertEqual(override.secret_key, 'explicit-test-secret')
        self.assertEqual(override.config['DB_PATH'], self.db)
        self.assertTrue(app.config['SESSION_COOKIE_SECURE'])
        self.assertTrue(app.config['SESSION_COOKIE_HTTPONLY'])
        self.assertEqual(app.config['SESSION_COOKIE_SAMESITE'], 'Lax')
        self.assertEqual(app.config['PERMANENT_SESSION_LIFETIME'], timedelta(hours=8))
        self.assertEqual(app.config['MAX_CONTENT_LENGTH'], 2*1024*1024)
        self.assertEqual(Path(app.root_path), BASE_DIR)
        r = app.test_client().get('/login', base_url='https://localhost')
        self.assertEqual(r.status_code, 200)
        for flag in ('Secure', 'HttpOnly', 'SameSite=Lax'):
            self.assertIn(flag, r.headers['Set-Cookie'])

    def test_app_py_entry_point_and_database_helpers(self):
        path = BASE_DIR / 'app.py'
        with patch.dict(os.environ, {'MEUFIADO_DB_PATH':self.db}):
            spec = importlib.util.spec_from_file_location('entrypoint_test', path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
        self.assertIsNotNone(module.app)
        self.assertIs(module.create_app, create_app)
        conn = module.get_db_connection()
        try:
            self.assertEqual(conn.execute('PRAGMA foreign_keys').fetchone()[0], 1)
        finally:
            conn.close()
        with module.banco() as conn:
            self.assertEqual(conn.execute('SELECT COUNT(*) FROM contas').fetchone()[0], 0)
        module.init_db()
        self.assertEqual(module.DB_PATH, self.db)
        self.assertEqual(module.app.test_client().get('/login').status_code, 200)

    def test_legacy_migration_preserves_history_and_makes_backup(self):
        # Original init_db uses a SQLite transaction context for its backup,
        # which does not close the connection. Preserve that application code,
        # but release its cyclic reference before Windows removes test files.
        def release_original_backup_handle():
            with warnings.catch_warnings():
                warnings.filterwarnings('ignore', message='unclosed database', category=ResourceWarning)
                gc.collect()
        self.addCleanup(release_original_backup_handle)
        old_db = Path(self.temp.name) / 'legacy.db'
        conn = sqlite3.connect(old_db)
        try:
            conn.execute('CREATE TABLE clientes (id INTEGER PRIMARY KEY AUTOINCREMENT,nome TEXT,celular TEXT,endereco TEXT)')
            conn.execute('INSERT INTO clientes VALUES (1,?,?,?)', ('Legacy Customer','123','Address'))
            conn.execute('CREATE TABLE vendas (id INTEGER PRIMARY KEY AUTOINCREMENT,cliente_id INTEGER,data TEXT,produto TEXT,valor REAL,status TEXT)')
            conn.execute('INSERT INTO vendas VALUES (1,1,?,?,?,?)', ('2020-01-01','Old purchase',25.5,'fiado'))
            conn.commit()
        finally:
            conn.close()
        app = create_app({'TESTING':True, 'DB_PATH':str(old_db)})
        with app.app_context(), banco() as conn:
            customer = conn.execute('SELECT * FROM clientes').fetchone()
            self.assertEqual(customer['nome'], 'Legacy Customer')
            self.assertIsNone(customer['usuario_id'])
            self.assertEqual(conn.execute('SELECT valor FROM vendas').fetchone()[0], 25.5)
            init_db()
        backups = list(Path(self.temp.name).glob('legacy.db.antes_login_*.bak'))
        self.assertEqual(len(backups), 1)
        conn = sqlite3.connect(backups[0])
        try:
            self.assertNotIn('usuario_id', [r[1] for r in conn.execute('PRAGMA table_info(clientes)')])
            self.assertEqual(conn.execute('SELECT valor FROM vendas').fetchone()[0], 25.5)
        finally:
            conn.close()


# Frozen before extraction: URLs, endpoint names, methods and registration order.
ORIGINAL_ROUTES = [{'rule': '/static/<path:filename>',
  'endpoint': 'static',
  'methods': ['GET', 'HEAD', 'OPTIONS'],
  'defaults': None},
 {'rule': '/login',
  'endpoint': 'login',
  'methods': ['GET', 'HEAD', 'OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/logout', 'endpoint': 'logout', 'methods': ['OPTIONS', 'POST'], 'defaults': None},
 {'rule': '/admin',
  'endpoint': 'contas',
  'methods': ['GET', 'HEAD', 'OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/contas',
  'endpoint': 'contas',
  'methods': ['GET', 'HEAD', 'OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/admin/usuario/<int:usuario_id>/senha',
  'endpoint': 'admin_alterar_senha',
  'methods': ['OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/admin/usuario/<int:usuario_id>/plano',
  'endpoint': 'admin_editar_plano',
  'methods': ['OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/admin/usuario/<int:usuario_id>/status',
  'endpoint': 'admin_alternar_usuario',
  'methods': ['OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/admin/usuario/<int:usuario_id>/excluir',
  'endpoint': 'admin_excluir_usuario',
  'methods': ['OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/', 'endpoint': 'landing', 'methods': ['GET', 'HEAD', 'OPTIONS'], 'defaults': None},
 {'rule': '/painel', 'endpoint': 'index', 'methods': ['GET', 'HEAD', 'OPTIONS'], 'defaults': None},
 {'rule': '/painel/resumo',
  'endpoint': 'resumo_painel',
  'methods': ['GET', 'HEAD', 'OPTIONS'],
  'defaults': None},
 {'rule': '/registrar_fiado',
  'endpoint': 'registrar_fiado',
  'methods': ['OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/fiados', 'endpoint': 'fiados', 'methods': ['GET', 'HEAD', 'OPTIONS'], 'defaults': None},
 {'rule': '/abater_fiado/<int:cliente_id>',
  'endpoint': 'abater_fiado',
  'methods': ['OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/pagar_total/<int:cliente_id>',
  'endpoint': 'pagar_total',
  'methods': ['OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/pagamentos',
  'endpoint': 'pagamentos',
  'methods': ['GET', 'HEAD', 'OPTIONS'],
  'defaults': None},
 {'rule': '/clientes',
  'endpoint': 'clientes',
  'methods': ['GET', 'HEAD', 'OPTIONS'],
  'defaults': None},
 {'rule': '/cadastrar_cliente',
  'endpoint': 'cadastrar_cliente',
  'methods': ['OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/editar_cliente/<int:cliente_id>',
  'endpoint': 'editar_cliente',
  'methods': ['OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/excluir_cliente/<int:cliente_id>',
  'endpoint': 'excluir_cliente',
  'methods': ['OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/estoque',
  'endpoint': 'estoque',
  'methods': ['GET', 'HEAD', 'OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/estoque/produto/<int:produto_id>/editar',
  'endpoint': 'editar_produto',
  'methods': ['OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/estoque/produto/<int:produto_id>/excluir',
  'endpoint': 'excluir_produto',
  'methods': ['OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/fornecedores',
  'endpoint': 'fornecedores',
  'methods': ['GET', 'HEAD', 'OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/fornecedor/<int:fornecedor_id>/editar',
  'endpoint': 'editar_fornecedor',
  'methods': ['OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/fornecedor/<int:fornecedor_id>/excluir',
  'endpoint': 'excluir_fornecedor',
  'methods': ['OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/vendas',
  'endpoint': 'vendas_negocio',
  'methods': ['GET', 'HEAD', 'OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/relatorios',
  'endpoint': 'relatorios',
  'methods': ['GET', 'HEAD', 'OPTIONS'],
  'defaults': None},
 {'rule': '/caixa',
  'endpoint': 'caixa',
  'methods': ['GET', 'HEAD', 'OPTIONS', 'POST'],
  'defaults': None},
 {'rule': '/caixa/<int:movimento_id>/excluir',
  'endpoint': 'excluir_movimento',
  'methods': ['OPTIONS', 'POST'],
  'defaults': None}]
