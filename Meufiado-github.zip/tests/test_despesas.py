"""Operating expense CRUD, isolation, monthly accounting, migrations and cash consistency."""

from datetime import datetime, timedelta
from pathlib import Path
import secrets
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from flask import template_rendered

from meufiado import create_app
from meufiado.database import banco, init_db
from meufiado.services.contas import criar_conta
from meufiado.services.despesas import (criar_despesa, criar_lancamentos, resumo_mes,
    resumo_funcionarios, validar_despesa, _sincronizar_caixa)


class ExpensesTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.app = create_app({'TESTING':True, 'DB_PATH':str(Path(cls.temp.name)/'expenses.db')})
        with cls.app.app_context(), banco(escrita=True) as conn:
            cls.uid = criar_conta(conn, 'Owner', 'owner', 'password123')
            cls.other = criar_conta(conn, 'Other', 'other', 'password123')
            cls.admin = criar_conta(conn, 'Admin', 'admin', 'password123', admin=True)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def setUp(self):
        with self.app.app_context(), banco(escrita=True) as conn:
            for table in ('despesas_lotes','despesas_envios','caixa_movimentos','despesas_operacionais',
                          'funcionarios','venda_itens',
                          'vendas_negocio','vendas','clientes','tentativas_login'):
                conn.execute(f'DELETE FROM {table}')
            conn.execute('UPDATE contas SET versao_sessao=1')
        self.client = self.login('owner')

    def login(self, login):
        client = self.app.test_client()
        client.get('/login')
        with client.session_transaction() as session:
            token = session['csrf_token']
        response = client.post('/login', data={'login':login,'senha':'password123'},
                               headers={'X-CSRFToken':token})
        self.assertEqual(response.status_code,302)
        return client

    def post(self, url, data=None, client=None):
        client = client or self.client
        with client.session_transaction() as session:
            token = session['csrf_token']
        return client.post(url, data=data or {}, headers={'X-CSRFToken':token})

    def data(self, **changes):
        return {'descricao':'DAS','valor':'100,00','data_pagamento':'2026-01-15',
                'mes_referencia':'2026-01','observacao':'Paid',
                'chave_envio':secrets.token_hex(16), 'funcionario_nome':'Ana', **changes}

    def create(self, categoria='impostos', client=None, **changes):
        response = self.post('/despesas/'+categoria, self.data(**changes), client)
        self.assertEqual(response.status_code,302,response.get_data(as_text=True)[:300])
        with (client or self.client).session_transaction() as session:
            uid = session['usuario_id']
        return self.rows('SELECT * FROM despesas_operacionais WHERE usuario_id=? ORDER BY id DESC', (uid,))[0]

    def rows(self, sql, args=()):
        with self.app.app_context(), banco() as conn:
            return [dict(row) for row in conn.execute(sql,args)]

    def execute(self, sql, args=()):
        with self.app.app_context(), banco(escrita=True) as conn:
            return conn.execute(sql,args).lastrowid

    def summary(self, mes, uid=None):
        with self.app.app_context(), banco() as conn:
            return resumo_mes(conn,uid or self.uid,mes)

    def cash(self, despesa_id):
        return self.rows('SELECT * FROM caixa_movimentos WHERE despesa_id=?',(despesa_id,))

    def test_create_tax_expense_and_one_linked_cash_outflow(self):
        expense = self.create(descricao='  DAS   mensal  ', valor='R$ 1.250,00', usuario_id=self.other)
        self.assertEqual(expense['usuario_id'],self.uid)
        self.assertEqual(expense['categoria'],'imposto')
        self.assertEqual(expense['descricao'],'DAS mensal')
        self.assertEqual(expense['valor_centavos'],125000)
        self.assertEqual(expense['tipo'],'')
        cash = self.cash(expense['id'])
        self.assertEqual(len(cash),1)
        self.assertEqual(cash[0]['usuario_id'],self.uid)
        self.assertEqual(cash[0]['tipo'],'saida')
        self.assertEqual(cash[0]['valor_centavos'],125000)
        self.assertEqual(cash[0]['data'],'2026-01-15')

    def test_create_employee_expenses_for_every_supported_type(self):
        for tipo in ('salario','beneficios','transporte','alimentacao','comissoes','bonus','encargos','outros'):
            with self.subTest(tipo=tipo):
                expense = self.create('funcionarios', descricao='Employee '+tipo, tipo=tipo, valor='12,34')
                self.assertEqual(expense['tipo'],tipo)
                self.assertEqual(expense['categoria'],'funcionario')
                self.assertEqual(self.cash(expense['id'])[0]['valor_centavos'],1234)
        self.assertEqual(len(self.rows('SELECT * FROM caixa_movimentos')),8)

    def test_edit_tax_updates_same_cash_row_and_historical_totals(self):
        expense = self.create()
        cash = self.cash(expense['id'])[0]
        response = self.post(f"/despesas/{expense['id']}/editar", self.data(
            descricao='ISS', valor='220,55', data_pagamento='2026-02-02',
            mes_referencia='2026-02', observacao='Corrected', usuario_id=self.other,
        ))
        self.assertEqual(response.status_code,302)
        edited = self.rows('SELECT * FROM despesas_operacionais')[0]
        self.assertEqual(edited['usuario_id'],self.uid)
        self.assertEqual(edited['descricao'],'ISS')
        self.assertEqual(edited['observacao'],'Corrected')
        self.assertEqual(self.summary('2026-01')['total_centavos'],0)
        self.assertEqual(self.summary('2026-02')['total_centavos'],22055)
        updated = self.cash(expense['id'])
        self.assertEqual(len(updated),1)
        self.assertEqual(updated[0]['id'],cash['id'])
        self.assertEqual(updated[0]['criado_em'],cash['criado_em'])
        self.assertEqual(updated[0]['valor_centavos'],22055)
        self.assertEqual(updated[0]['data'],'2026-02-02')
        self.assertIn('ISS',updated[0]['descricao'])

    def test_edit_employee_type_and_amount(self):
        expense = self.create('funcionarios', descricao='Ana', tipo='salario', valor='4800')
        response = self.post(f"/despesas/{expense['id']}/editar", self.data(
            descricao='Ana - benefits', tipo='beneficios', valor='600', categoria='imposto',
        ))
        self.assertEqual(response.status_code,302)
        edited = self.rows('SELECT * FROM despesas_operacionais')[0]
        self.assertEqual(edited['categoria'],'funcionario')
        self.assertEqual(edited['tipo'],'beneficios')
        self.assertEqual(edited['valor_centavos'],60000)
        self.assertEqual(len(self.cash(expense['id'])),1)

    def test_delete_both_categories_removes_cash_and_recalculates_totals(self):
        tax = self.create()
        employee = self.create('funcionarios', tipo='salario', descricao='Ana', valor='200')
        for expense in (tax,employee):
            self.assertEqual(self.post(f"/despesas/{expense['id']}/excluir").status_code,302)
            self.assertFalse(self.cash(expense['id']))
        self.assertFalse(self.rows('SELECT * FROM despesas_operacionais'))
        self.assertEqual(self.summary('2026-01')['total_centavos'],0)

    def test_monthly_totals_history_and_account_isolation(self):
        self.create(valor='1.250,00', mes_referencia='2026-10')
        self.create('funcionarios', descricao='Ana', tipo='salario', valor='4.800,00', mes_referencia='2026-10')
        self.create(valor='33,33',mes_referencia='2026-09')
        self.create(client=self.login('other'),valor='999',mes_referencia='2026-10')
        self.assertEqual(self.summary('2026-10'),{
            'impostos_centavos':125000,'funcionarios_centavos':480000,'total_centavos':605000,
        })
        self.assertEqual(self.summary('2026-09')['total_centavos'],3333)
        self.assertEqual(self.summary('2025-01')['total_centavos'],0)
        response = self.client.get('/despesas?mes=2026-10')
        self.assertEqual(response.status_code,200)
        self.assertIn('R$ 6.050,00',response.get_data(as_text=True))
        self.assertNotIn('R$ 999,00',response.get_data(as_text=True))

    def test_repeated_submission_records_each_payment_only_once(self):
        for category in ('impostos', 'funcionarios'):
            data = self.data(tipo='salario')
            first = self.post('/despesas/'+category, data)
            retry = self.post('/despesas/'+category, data)
            self.assertEqual(first.status_code, 302)
            self.assertEqual(retry.status_code, 302)
            self.assertEqual(first.location, retry.location)
        self.assertEqual(len(self.rows('SELECT * FROM despesas_operacionais')), 2)
        self.assertEqual(len(self.rows('SELECT * FROM caixa_movimentos')), 2)
        self.assertEqual(self.summary('2026-01')['total_centavos'], 20000)

    def test_new_forms_allow_identical_legitimate_payments(self):
        self.create()
        self.create()
        self.assertEqual(len(self.rows('SELECT * FROM despesas_operacionais')), 2)
        self.assertEqual(len(self.rows('SELECT * FROM caixa_movimentos')), 2)

    def test_submission_keys_are_scoped_to_the_owner(self):
        data = self.data()
        self.assertEqual(self.post('/despesas/impostos', data).status_code, 302)
        other_client = self.login('other')
        self.assertEqual(self.post('/despesas/impostos', data, other_client).status_code, 302)
        self.assertEqual(self.summary('2026-01')['total_centavos'], 10000)
        self.assertEqual(self.summary('2026-01', self.other)['total_centavos'], 10000)

    def test_reused_form_with_changed_fields_is_rejected(self):
        data = self.data()
        self.assertEqual(self.post('/despesas/impostos', data).status_code, 302)
        for changes in ({'valor':'999'}, {'mes_referencia':'2026-02'}, {'descricao':'ISS'}):
            response = self.post('/despesas/impostos', {**data, **changes})
            self.assertEqual(response.status_code, 400)
        self.assertEqual(self.post('/despesas/funcionarios', {**data, 'tipo':'salario'}).status_code, 400)
        self.assertEqual(len(self.rows('SELECT * FROM despesas_operacionais')), 1)
        self.assertEqual(self.summary('2026-01')['total_centavos'], 10000)

    def test_retry_after_deletion_does_not_recreate_payment(self):
        data = self.data()
        self.assertEqual(self.post('/despesas/impostos', data).status_code, 302)
        expense = self.rows('SELECT * FROM despesas_operacionais')[0]
        self.assertEqual(self.post(f"/despesas/{expense['id']}/excluir").status_code, 302)
        self.assertEqual(self.post('/despesas/impostos', data).status_code, 400)
        self.assertFalse(self.rows('SELECT * FROM despesas_operacionais'))
        self.assertFalse(self.rows('SELECT * FROM caixa_movimentos'))
        self.assertIsNone(self.rows('SELECT despesa_id FROM despesas_envios')[0]['despesa_id'])

    def test_missing_or_invalid_submission_key_is_rejected(self):
        for key in ('', 'invalid', 'x'*1000, "' OR 1=1 --"):
            self.assertEqual(self.post('/despesas/impostos', self.data(chave_envio=key)).status_code, 400)
        self.assertFalse(self.rows('SELECT * FROM despesas_operacionais'))
        self.assertFalse(self.rows('SELECT * FROM caixa_movimentos'))

    def test_submission_receipt_failure_rolls_back_and_allows_retry(self):
        data = self.data()
        self.execute("CREATE TRIGGER fail_expense_receipt BEFORE INSERT ON despesas_envios "
                     "BEGIN SELECT RAISE(ABORT,'test failure'); END")
        try:
            with self.assertRaises(sqlite3.IntegrityError):
                self.post('/despesas/impostos', data)
        finally:
            self.execute('DROP TRIGGER fail_expense_receipt')
        self.assertFalse(self.rows('SELECT * FROM despesas_operacionais'))
        self.assertFalse(self.rows('SELECT * FROM caixa_movimentos'))
        self.assertFalse(self.rows('SELECT * FROM despesas_envios'))
        self.assertEqual(self.post('/despesas/impostos', data).status_code, 302)
        self.assertEqual(len(self.rows('SELECT * FROM caixa_movimentos')), 1)

    def test_cross_site_requests_are_rejected_even_with_valid_csrf(self):
        expense = self.create()
        with self.client.session_transaction() as session:
            token = session['csrf_token']
        headers = {'X-CSRFToken':token, 'Sec-Fetch-Site':'cross-site'}
        for url, data in (('/despesas/impostos', self.data()),
                          ('/despesas/funcionarios', self.data(tipo='salario')),
                          (f"/despesas/{expense['id']}/editar", self.data(valor='999')),
                          (f"/despesas/{expense['id']}/excluir", {})):
            self.assertEqual(self.client.post(url, data=data, headers=headers).status_code, 400)
        self.assertEqual(self.summary('2026-01')['total_centavos'], 10000)
        self.assertEqual(len(self.rows('SELECT * FROM caixa_movimentos')), 1)

    def test_invalid_edits_preserve_expense_and_cash_for_both_categories(self):
        for category in ('impostos', 'funcionarios'):
            expense = self.create(category, tipo='salario')
            cash = self.cash(expense['id'])
            for amount in ('0', '-1', 'nan', 'inf', 'text', '1000000000.00'):
                response = self.post(f"/despesas/{expense['id']}/editar", self.data(valor=amount, tipo='salario'))
                self.assertEqual(response.status_code, 400)
                self.assertEqual(self.rows('SELECT * FROM despesas_operacionais WHERE id=?', (expense['id'],)), [expense])
                self.assertEqual(self.cash(expense['id']), cash)

    def test_migration_preserves_existing_expenses_and_consumed_forms(self):
        data = self.data()
        self.assertEqual(self.post('/despesas/impostos', data).status_code, 302)
        expense = self.rows('SELECT * FROM despesas_operacionais')
        cash = self.rows('SELECT * FROM caixa_movimentos')
        # Simulate the existing expense schema before submission tracking.
        self.execute('DROP TABLE despesas_envios')
        with self.app.app_context():
            init_db()
            init_db()
        self.assertEqual(self.rows('SELECT * FROM despesas_operacionais'), expense)
        self.assertEqual(self.rows('SELECT * FROM caixa_movimentos'), cash)
        self.assertFalse(self.rows('SELECT * FROM despesas_envios'))
        data = self.data()
        self.assertEqual(self.post('/despesas/impostos', data).status_code, 302)
        with self.app.app_context():
            init_db()
        self.assertEqual(self.post('/despesas/impostos', data).status_code, 302)
        self.assertEqual(len(self.rows('SELECT * FROM despesas_operacionais')), 2)
        self.assertEqual(len(self.rows('SELECT * FROM caixa_movimentos')), 2)
        self.assertFalse(self.rows('PRAGMA foreign_key_check'))

    def test_decimal_rounding_stays_in_integer_cents(self):
        expense = self.create(valor='0.105')
        self.assertEqual(expense['valor_centavos'],11)
        self.assertEqual(self.cash(expense['id'])[0]['valor_centavos'],11)
        self.create(valor='0.10')
        self.create(valor='0.20')
        self.assertEqual(self.summary('2026-01')['total_centavos'],41)

    def test_invalid_amounts_never_create_expense_or_cash(self):
        for category in ('impostos','funcionarios'):
            for amount in ('0','-1','nan','inf','','text','0.004','1000000000.00'):
                with self.subTest(category=category,amount=amount):
                    r = self.post('/despesas/'+category, self.data(valor=amount,tipo='salario'))
                    self.assertEqual(r.status_code,400)
        self.assertFalse(self.rows('SELECT * FROM despesas_operacionais'))
        self.assertFalse(self.rows('SELECT * FROM caixa_movimentos'))

    def test_invalid_dates_months_and_future_payments_are_rejected(self):
        tomorrow = (datetime.now()+timedelta(days=1)).strftime('%Y-%m-%d')
        for changes in ({'data_pagamento':'2026-02-30'},{'data_pagamento':'2026-1-01'},
                        {'data_pagamento':tomorrow},{'mes_referencia':'2026-13'},
                        {'mes_referencia':'2026-1'},{'mes_referencia':''},
                        {'mes_referencia':"2026-01' OR 1=1 --"}):
            self.assertEqual(self.post('/despesas/impostos',self.data(**changes)).status_code,400)
        for month in ('bad','2026-00','2026-13','2026-1',''):
            self.assertEqual(self.client.get('/despesas?mes='+month).status_code,400)
        self.assertFalse(self.rows('SELECT * FROM despesas_operacionais'))

    def test_employee_type_and_field_lengths_are_validated(self):
        for tipo in ('','invalid'):
            self.assertEqual(self.post('/despesas/funcionarios',self.data(tipo=tipo)).status_code,400)
        for changes in ({'descricao':''},{'descricao':'x'*151},{'observacao':'x'*501}):
            self.assertEqual(self.post('/despesas/impostos',self.data(**changes)).status_code,400)
        self.assertFalse(self.rows('SELECT * FROM caixa_movimentos'))

    def test_other_account_cannot_read_edit_or_delete_expenses(self):
        other_client = self.login('other')
        for categoria in ('impostos','funcionarios'):
            expense = self.create(categoria,descricao='Private expense',tipo='salario')
            eid = expense['id']
            for response in (other_client.get(f'/despesas/{eid}/editar'),
                             self.post(f'/despesas/{eid}/editar',self.data(tipo='salario'),other_client),
                             self.post(f'/despesas/{eid}/excluir',client=other_client)):
                self.assertEqual(response.status_code,404)
            mid = self.cash(eid)[0]['id']
            self.assertEqual(self.post(f'/caixa/{mid}/excluir',client=other_client).status_code,404)
            self.assertNotIn('Private expense',other_client.get('/despesas/'+categoria+'?mes=2026-01').get_data(as_text=True))
            self.assertEqual(self.cash(eid)[0]['valor_centavos'],10000)
        self.assertEqual(len(self.rows('SELECT * FROM despesas_operacionais')),2)

    def test_csrf_on_create_edit_and_delete(self):
        expense = self.create()
        for url, data in (('/despesas/impostos',self.data()),('/despesas/funcionarios',self.data(tipo='salario')),
                          (f"/despesas/{expense['id']}/editar",self.data(valor='999')),
                          (f"/despesas/{expense['id']}/excluir",{})):
            self.assertEqual(self.client.post(url,data=data).status_code,400)
            self.assertEqual(self.client.post(url,data=data,headers={'X-CSRFToken':'bad'}).status_code,400)
        self.assertEqual(len(self.rows('SELECT * FROM despesas_operacionais')),1)
        self.assertEqual(self.cash(expense['id'])[0]['valor_centavos'],10000)
        self.assertEqual(self.client.get(f"/despesas/{expense['id']}/excluir").status_code,405)

    def test_authentication_and_revoked_sessions(self):
        anonymous = self.app.test_client()
        for url in ('/despesas','/despesas/impostos','/despesas/funcionarios'):
            self.assertEqual(anonymous.get(url).location,'/login')
        self.assertEqual(anonymous.post('/despesas/impostos',data=self.data()).status_code,401)
        self.execute('UPDATE contas SET versao_sessao=2 WHERE id=?',(self.uid,))
        self.assertEqual(self.post('/despesas/impostos',self.data()).status_code,401)
        self.assertFalse(self.rows('SELECT * FROM despesas_operacionais'))

    def test_repeated_edits_never_duplicate_cash_and_direct_cash_delete_is_blocked(self):
        expense = self.create()
        for value in ('101','102','103'):
            self.assertEqual(self.post(f"/despesas/{expense['id']}/editar",self.data(valor=value)).status_code,302)
        cash = self.cash(expense['id'])
        self.assertEqual(len(cash),1)
        self.assertEqual(cash[0]['valor_centavos'],10300)
        self.assertEqual(self.post(f"/caixa/{cash[0]['id']}/excluir").status_code,400)
        with self.assertRaises(sqlite3.IntegrityError):
            self.execute("INSERT INTO caixa_movimentos (usuario_id,tipo,descricao,valor_centavos,data,despesa_id) "
                         "VALUES (?,'saida','duplicate',100,'2026-01-15',?)",(self.uid,expense['id']))
        self.assertEqual(len(self.cash(expense['id'])),1)

    def test_cash_screen_links_source_and_hides_direct_delete(self):
        expense = self.create()
        cash = self.cash(expense['id'])[0]
        html = self.client.get('/caixa?inicio=2026-01-01&fim=2026-01-31').get_data(as_text=True)
        self.assertIn(f"/despesas/{expense['id']}/editar",html)
        self.assertNotIn(f"/caixa/{cash['id']}/excluir",html)
        self.assertIn('Imposto: DAS',html)

    def test_create_rolls_back_if_cash_creation_fails(self):
        with patch('meufiado.services.despesas._sincronizar_caixa',side_effect=sqlite3.IntegrityError('test failure')):
            with self.assertRaises(sqlite3.IntegrityError):
                self.post('/despesas/impostos',self.data())
        self.assertFalse(self.rows('SELECT * FROM despesas_operacionais'))
        self.assertFalse(self.rows('SELECT * FROM caixa_movimentos'))

    def test_edit_rolls_back_if_cash_update_fails(self):
        expense = self.create()
        with patch('meufiado.services.despesas._sincronizar_caixa',side_effect=sqlite3.IntegrityError('test failure')):
            with self.assertRaises(sqlite3.IntegrityError):
                self.post(f"/despesas/{expense['id']}/editar",self.data(valor='999'))
        self.assertEqual(self.rows('SELECT valor_centavos FROM despesas_operacionais')[0]['valor_centavos'],10000)
        self.assertEqual(self.cash(expense['id'])[0]['valor_centavos'],10000)

    def test_delete_rolls_back_cash_deletion_if_expense_delete_fails(self):
        expense = self.create()
        self.execute("CREATE TRIGGER fail_expense_delete BEFORE DELETE ON despesas_operacionais "
                     "BEGIN SELECT RAISE(ABORT,'test failure'); END")
        try:
            with self.assertRaises(sqlite3.IntegrityError):
                self.post(f"/despesas/{expense['id']}/excluir")
        finally:
            self.execute('DROP TRIGGER fail_expense_delete')
        self.assertEqual(len(self.cash(expense['id'])),1)
        self.assertEqual(len(self.rows('SELECT * FROM despesas_operacionais')),1)

    def test_reports_use_payment_date_and_never_count_expenses_as_revenue(self):
        self.create(valor='1250',mes_referencia='2026-10',data_pagamento='2026-01-15')
        self.create('funcionarios',tipo='salario',valor='4800',data_pagamento='2026-01-15')
        self.create(client=self.login('other'),valor='999')
        self.execute("INSERT INTO vendas_negocio (usuario_id,forma_pagamento,total_centavos,data) "
                     "VALUES (?,'avista',20000,'2026-01-15')",(self.uid,))
        self.execute("INSERT INTO caixa_movimentos (usuario_id,tipo,descricao,valor_centavos,data) "
                     "VALUES (?,'entrada','Income',20000,'2026-01-15')",(self.uid,))
        contexts = []
        def record(sender, template, context, **extra):
            contexts.append(context)
        with template_rendered.connected_to(record,self.app):
            response = self.client.get('/relatorios?inicio=2026-01-01&fim=2026-01-31')
        self.assertEqual(response.status_code,200)
        report = contexts[-1]
        self.assertEqual(report['total_vendas'],200)
        self.assertEqual(report['recebimentos'],200)
        self.assertEqual(report['despesas'],6050)
        self.assertEqual(report['resultado'],-5850)
        self.assertEqual(report['despesas_operacionais']['total_centavos'],605000)
        self.assertEqual(self.summary('2026-10')['impostos_centavos'],125000)
        self.assertIn('method="get"',response.get_data(as_text=True))

    def test_account_deletion_cascades_expenses_without_affecting_other_accounts(self):
        own = self.create()
        with self.app.app_context(), banco(escrita=True) as conn:
            uid = criar_conta(conn,'Temporary','temporary-user','password123')
            dados = validar_despesa(self.data(tipo='salario'),'funcionario')
            eid = criar_lancamentos(conn,uid,[dados],secrets.token_hex(16))[0]
        admin_client = self.login('admin')
        self.assertEqual(self.post(f'/admin/usuario/{uid}/excluir',client=admin_client).status_code,302)
        self.assertFalse(self.rows('SELECT id FROM despesas_operacionais WHERE id=?',(eid,)))
        self.assertFalse(self.cash(eid))
        self.assertFalse(self.rows('SELECT * FROM despesas_envios WHERE usuario_id=?', (uid,)))
        self.assertFalse(self.rows('SELECT * FROM funcionarios WHERE usuario_id=?', (uid,)))
        self.assertFalse(self.rows('SELECT * FROM despesas_lotes WHERE usuario_id=?', (uid,)))
        self.assertEqual(len(self.cash(own['id'])),1)

    def test_descriptions_notes_and_form_errors_are_escaped(self):
        expense = self.create(descricao="Tax <script>alert(1)</script>",observacao="<img src=x onerror=alert(1)>")
        html = self.client.get('/despesas/impostos?mes=2026-01').get_data(as_text=True)
        self.assertIn('&lt;script&gt;',html)
        self.assertNotIn('<script>alert(1)</script>',html)
        self.assertNotIn('<img src=x onerror=',html)
        response = self.post(f"/despesas/{expense['id']}/editar",self.data(descricao='Retained value',valor='invalid'))
        self.assertEqual(response.status_code,400)
        self.assertIn('Retained value',response.get_data(as_text=True))
        self.assertEqual(len(self.cash(expense['id'])),1)

    def test_migration_preserves_old_cash_and_secret_and_is_idempotent(self):
        path = Path(self.temp.name)/'legacy-expenses.db'
        conn = sqlite3.connect(path)
        try:
            conn.execute('CREATE TABLE contas (id INTEGER PRIMARY KEY AUTOINCREMENT,nome TEXT NOT NULL,'
                         'login TEXT UNIQUE,senha_hash TEXT,admin INTEGER,ativo INTEGER,versao_sessao INTEGER,'
                         'criado_em TEXT)')
            conn.execute("INSERT INTO contas VALUES (7,'Legacy','legacy','test-hash',0,1,1,'2020-01-01')")
            conn.execute('CREATE TABLE caixa_movimentos (id INTEGER PRIMARY KEY AUTOINCREMENT,'
                         'usuario_id INTEGER REFERENCES contas(id),tipo TEXT,descricao TEXT,'
                         'valor_centavos INTEGER,data TEXT,origem TEXT,cliente_id INTEGER,criado_em TEXT)')
            conn.execute("INSERT INTO caixa_movimentos VALUES (9,7,'saida','Old manual expense',1234,'2020-01-01','manual',NULL,'2020-01-01')")
            conn.execute('CREATE TABLE configuracao_app (chave TEXT PRIMARY KEY,valor TEXT NOT NULL)')
            conn.execute("INSERT INTO configuracao_app VALUES ('secret_key','legacy-test-secret')")
            conn.commit()
        finally:
            conn.close()
        for _ in range(2):
            app = create_app({'TESTING':True,'DB_PATH':str(path)})
            self.assertEqual(app.secret_key,'legacy-test-secret')
            with app.app_context(), banco() as conn:
                old = conn.execute('SELECT * FROM caixa_movimentos WHERE id=9').fetchone()
                self.assertEqual(old['valor_centavos'],1234)
                self.assertEqual(old['descricao'],'Old manual expense')
                self.assertIsNone(old['despesa_id'])
                self.assertEqual(conn.execute('SELECT COUNT(*) FROM despesas_operacionais').fetchone()[0],0)
                self.assertEqual([r['name'] for r in conn.execute('PRAGMA table_info(caixa_movimentos)')].count('despesa_id'),1)
                self.assertEqual(conn.execute('PRAGMA foreign_key_check').fetchall(),[])

    def test_new_route_contract_and_navigation(self):
        actual = {r.rule:r.methods-{'HEAD','OPTIONS'} for r in self.app.url_map.iter_rules() if r.rule.startswith('/despesas')}
        self.assertEqual(actual,{
            '/despesas':{'GET'}, '/despesas/impostos':{'GET','POST'},
            '/despesas/funcionarios':{'GET','POST'},
            '/despesas/<int:despesa_id>/editar':{'GET','POST'},
            '/despesas/<int:despesa_id>/excluir':{'POST'},
        })
        for url in ('/painel','/caixa','/relatorios','/despesas','/despesas/funcionarios'):
            response = self.client.get(url)
            self.assertEqual(response.status_code,200)
            self.assertIn('href="/despesas"',response.get_data(as_text=True))

    def employee_items(self, nome='João', mes='2026-10', **changes):
        return self.data(funcionario_nome=nome, mes_referencia=mes,
                         descricao=['Salário', 'Transporte', 'Comissão'],
                         tipo=['salario', 'transporte', 'comissoes'],
                         valor=['1675,00', '100', '200'], **changes)

    def employee_summary(self, mes='2026-10', uid=None):
        with self.app.app_context(), banco() as conn:
            return {row['nome']:row['total_centavos'] for row in resumo_funcionarios(conn, uid or self.uid, mes)}

    def test_multiple_employee_items_ignore_submitted_total(self):
        data = self.employee_items(total='0', total_centavos='999999999', usuario_id=self.other)
        response = self.post('/despesas/funcionarios', data)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.employee_summary(), {'João':197500})
        expenses = self.rows('SELECT * FROM despesas_operacionais ORDER BY id')
        self.assertEqual([row['valor_centavos'] for row in expenses], [167500,10000,20000])
        self.assertEqual(len({row['funcionario_id'] for row in expenses}), 1)
        self.assertTrue(all(row['usuario_id']==self.uid for row in expenses))
        self.assertEqual(len(self.rows('SELECT * FROM funcionarios')), 1)
        self.assertEqual(len(self.rows('SELECT * FROM caixa_movimentos')), 3)
        self.assertEqual(self.post('/despesas/funcionarios', data).status_code, 302)
        self.assertEqual(len(self.rows('SELECT * FROM caixa_movimentos')), 3)

    def test_multiple_tax_items_are_independent_records(self):
        response = self.post('/despesas/impostos', self.data(
            descricao=['DAS','ICMS','Taxa municipal'], valor=['500','300','100'],
            mes_referencia='2026-10', total='999999', funcionario_id=self.other))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.summary('2026-10')['impostos_centavos'], 90000)
        rows = self.rows('SELECT * FROM despesas_operacionais')
        self.assertEqual(len(rows), 3)
        self.assertTrue(all(row['funcionario_id'] is None for row in rows))
        self.assertFalse(self.rows('SELECT * FROM funcionarios'))
        self.assertEqual(len(self.rows('SELECT * FROM caixa_movimentos')), 3)

    def test_employee_and_tax_example_multiple_people_months_and_accounts(self):
        self.assertEqual(self.post('/despesas/funcionarios', self.employee_items()).status_code, 302)
        for name, value in (('Maria','2250'), ('Carlos','1800')):
            self.create('funcionarios', funcionario_nome=name, tipo='salario', valor=value, mes_referencia='2026-10')
        self.create('funcionarios', funcionario_nome='João', tipo='salario', valor='500', mes_referencia='2026-09')
        self.create('funcionarios', client=self.login('other'), funcionario_nome='João',
                    tipo='salario', valor='999', mes_referencia='2026-10')
        self.post('/despesas/impostos', self.data(descricao=['DAS','ICMS','Taxa municipal'],
                  valor=['500','300','100'], mes_referencia='2026-10'))
        self.assertEqual(self.employee_summary(), {'João':197500,'Maria':225000,'Carlos':180000})
        self.assertEqual(self.employee_summary('2026-09'), {'João':50000})
        self.assertEqual(self.employee_summary('2025-01'), {})
        self.assertEqual(self.employee_summary(uid=self.other), {'João':99900})
        self.assertEqual(self.summary('2026-10'),
                         {'impostos_centavos':90000,'funcionarios_centavos':602500,'total_centavos':692500})
        html = self.client.get('/despesas/funcionarios?mes=2026-10').get_data(as_text=True)
        for text in ('João', 'Maria', 'Carlos', 'R$ 6.025,00', 'R$ 6.925,00'):
            self.assertIn(text, html)
        self.assertNotIn('R$ 999,00', html)

    def test_edit_delete_and_add_later_recalculate_employee_totals(self):
        self.post('/despesas/funcionarios', self.employee_items())
        items = self.rows('SELECT * FROM despesas_operacionais ORDER BY id')
        salary, transport = items[:2]
        cash_id = self.cash(salary['id'])[0]['id']
        self.assertEqual(self.post(f"/despesas/{salary['id']}/editar", self.data(
            funcionario_nome='João', tipo='salario', valor='1800', mes_referencia='2026-10')).status_code, 302)
        self.assertEqual(self.employee_summary(), {'João':210000})
        self.assertEqual(self.cash(salary['id'])[0]['id'], cash_id)
        self.assertEqual(self.post(f"/despesas/{transport['id']}/excluir").status_code, 302)
        self.assertEqual(self.employee_summary(), {'João':200000})
        self.assertFalse(self.cash(transport['id']))
        self.create('funcionarios', funcionario_nome='  JOÃO  ', tipo='hora_extra', valor='50', mes_referencia='2026-10')
        self.assertEqual(self.employee_summary(), {'João':205000})
        self.assertEqual(len(self.rows('SELECT * FROM funcionarios')), 1)
        self.assertEqual(sum(row['valor_centavos'] for row in self.rows('SELECT * FROM caixa_movimentos')), 205000)

    def test_moving_item_to_another_employee_and_month_recalculates_both(self):
        item = self.create('funcionarios', funcionario_nome='João', tipo='salario', valor='100', mes_referencia='2026-10')
        self.assertEqual(self.post(f"/despesas/{item['id']}/editar", self.data(
            funcionario_nome='Maria', tipo='bonus', valor='150', mes_referencia='2026-09')).status_code, 302)
        self.assertEqual(self.employee_summary('2026-10'), {})
        self.assertEqual(self.employee_summary('2026-09'), {'Maria':15000})
        self.assertEqual(len(self.cash(item['id'])), 1)

    def test_invalid_line_rejects_whole_batch_without_consuming_form(self):
        for category in ('impostos', 'funcionarios'):
            for amount in ('-1', '0', 'nan', 'inf', 'text', '0.001', '1000000000'):
                data = self.data(funcionario_nome='João', descricao=['First','Second'],
                                 tipo=['salario','transporte'], valor=['10',amount])
                self.assertEqual(self.post('/despesas/'+category, data).status_code, 400)
                for table in ('funcionarios','despesas_operacionais','caixa_movimentos','despesas_envios','despesas_lotes'):
                    self.assertFalse(self.rows(f'SELECT * FROM {table}'))
        data['valor'] = ['10','20']
        self.assertEqual(self.post('/despesas/funcionarios', data).status_code, 302)
        self.assertEqual(self.summary('2026-01')['total_centavos'], 3000)

    def test_incomplete_lines_and_missing_employee_are_rejected(self):
        for changes in ({'descricao':[], 'valor':[], 'tipo':[]},
                        {'descricao':['One','Two'], 'valor':['1'], 'tipo':['salario','transporte']},
                        {'descricao':['One','Two'], 'valor':['1','2'], 'tipo':['salario']},
                        {'funcionario_nome':''}, {'funcionario_nome':'x'*151}):
            self.assertEqual(self.post('/despesas/funcionarios', self.data(**{'tipo':'salario', **changes})).status_code, 400)
        self.assertFalse(self.rows('SELECT * FROM despesas_operacionais'))

    def test_employee_selection_and_database_links_respect_ownership(self):
        foreign = self.create('funcionarios', client=self.login('other'), funcionario_nome='Private employee', tipo='salario')
        foreign_id = foreign['funcionario_id']
        self.assertEqual(self.client.get(f'/despesas/funcionarios?funcionario={foreign_id}').status_code, 404)
        html = self.client.get('/despesas/funcionarios').get_data(as_text=True)
        self.assertNotIn('Private employee', html)
        own = self.create('funcionarios', funcionario_nome='Own employee', tipo='salario', funcionario_id=foreign_id)
        self.assertNotEqual(own['funcionario_id'], foreign_id)
        with self.assertRaises(sqlite3.IntegrityError):
            self.execute('UPDATE despesas_operacionais SET funcionario_id=? WHERE id=?', (foreign_id,own['id']))
        with self.assertRaises(sqlite3.IntegrityError):
            self.execute('UPDATE despesas_operacionais SET usuario_id=? WHERE id=?', (self.other,own['id']))
        self.assertEqual(self.cash(foreign['id'])[0]['usuario_id'], self.other)
        self.assertEqual(self.post(f"/despesas/{foreign['id']}/excluir").status_code, 404)

    def test_changed_batch_length_and_partial_deletion_cannot_duplicate_items(self):
        data = self.employee_items()
        self.assertEqual(self.post('/despesas/funcionarios', data).status_code, 302)
        shortened = {**data, 'descricao':data['descricao'][:1], 'tipo':data['tipo'][:1], 'valor':data['valor'][:1]}
        self.assertEqual(self.post('/despesas/funcionarios', shortened).status_code, 400)
        item = self.rows('SELECT id FROM despesas_operacionais ORDER BY id')[1]
        self.post(f"/despesas/{item['id']}/excluir")
        self.assertEqual(self.post('/despesas/funcionarios', data).status_code, 400)
        self.assertEqual(len(self.rows('SELECT * FROM despesas_operacionais')), 2)
        self.assertEqual(len(self.rows('SELECT * FROM caixa_movimentos')), 2)
        self.assertEqual(self.employee_summary(), {'João':187500})

    def test_failure_on_second_cash_movement_rolls_back_entire_batch(self):
        calls = []
        def fail_second(conn, uid, expense_id):
            calls.append(expense_id)
            if len(calls) == 2:
                raise sqlite3.IntegrityError('second movement failed')
            _sincronizar_caixa(conn, uid, expense_id)
        data = self.employee_items()
        with patch('meufiado.services.despesas._sincronizar_caixa', side_effect=fail_second):
            with self.assertRaises(sqlite3.IntegrityError):
                self.post('/despesas/funcionarios', data)
        for table in ('funcionarios','despesas_operacionais','caixa_movimentos','despesas_envios','despesas_lotes'):
            self.assertFalse(self.rows(f'SELECT * FROM {table}'))
        self.assertEqual(self.post('/despesas/funcionarios', data).status_code, 302)
        self.assertEqual(self.employee_summary(), {'João':197500})

    def test_legacy_employee_migration_preserves_items_and_cash(self):
        path = str(Path(self.temp.name)/'legacy-employees.db')
        app = create_app({'TESTING':True,'DB_PATH':path})
        with app.app_context(), banco(escrita=True) as conn:
            uid = criar_conta(conn,'Legacy owner','legacy-employees','password123')
            other = criar_conta(conn,'Legacy other','legacy-other','password123')
            conn.execute('DROP TRIGGER validar_funcionario_despesa_insert')
            conn.execute('DROP TRIGGER validar_funcionario_despesa_update')
            conn.execute('DROP INDEX idx_despesas_funcionario_mes')
            conn.execute('ALTER TABLE despesas_operacionais DROP COLUMN funcionario_id')
            conn.execute('DROP TABLE funcionarios')
            for owner, name, month in ((uid,'João','2026-10'),(uid,'João','2026-09'),(other,'João','2026-10')):
                eid = conn.execute("INSERT INTO despesas_operacionais (usuario_id,categoria,descricao,valor_centavos,"
                    "data_pagamento,mes_referencia,tipo) VALUES (?,'funcionario',?,10000,'2026-01-15',?,'salario')",
                    (owner,name,month)).lastrowid
                conn.execute("INSERT INTO caixa_movimentos (usuario_id,tipo,descricao,valor_centavos,data,despesa_id) "
                    "VALUES (?,'saida',?,10000,'2026-01-15',?)", (owner,name,eid))
            before = [dict(row) for row in conn.execute('SELECT * FROM despesas_operacionais ORDER BY id')]
            cash = [dict(row) for row in conn.execute('SELECT * FROM caixa_movimentos ORDER BY id')]
        for _ in range(2):
            with app.app_context():
                init_db()
        with app.app_context(), banco() as conn:
            after = [dict(row) for row in conn.execute('SELECT * FROM despesas_operacionais ORDER BY id')]
            self.assertEqual([{key:row[key] for key in before[0]} for row in after], before)
            self.assertEqual(after[0]['funcionario_id'], after[1]['funcionario_id'])
            self.assertNotEqual(after[0]['funcionario_id'], after[2]['funcionario_id'])
            self.assertEqual([dict(row) for row in conn.execute('SELECT * FROM caixa_movimentos ORDER BY id')], cash)
            self.assertEqual(conn.execute('SELECT COUNT(*) FROM funcionarios').fetchone()[0], 2)
            self.assertFalse(conn.execute('PRAGMA foreign_key_check').fetchall())

    def test_legacy_single_item_form_receipts_survive_upgrade(self):
        data = self.data()
        with self.app.app_context(), banco(escrita=True) as conn:
            eid = criar_despesa(conn, self.uid, validar_despesa(data,'imposto'), chave_envio=data['chave_envio'])
        self.assertEqual(self.post('/despesas/impostos', data).status_code, 302)
        self.assertEqual(len(self.rows('SELECT * FROM despesas_operacionais')), 1)
        self.assertEqual(len(self.cash(eid)), 1)
        self.assertEqual(self.post('/despesas/impostos', {**data, 'descricao':['DAS','ISS'], 'valor':['100','50']}).status_code, 400)
        self.assertEqual(self.post(f'/despesas/{eid}/excluir').status_code, 302)
        self.assertEqual(self.post('/despesas/impostos', data).status_code, 400)
        self.assertFalse(self.rows('SELECT * FROM caixa_movimentos'))
        self.assertFalse(self.rows('SELECT * FROM despesas_operacionais'))
