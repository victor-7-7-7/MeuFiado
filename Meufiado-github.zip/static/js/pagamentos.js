'use strict';
configurarBusca('searchPagamentos', '.payment-row', 'semPagamentos');
