'use strict';
configurarBusca('searchInput', '.item-cliente', 'semClientes');
const modalEdicao = document.getElementById('modalEdicao');
const modalExclusao = document.getElementById('modalExclusao');
document.querySelectorAll('.btn-editar').forEach(botao => {
    botao.addEventListener('click', () => {
        document.getElementById('formEdicao').action = botao.dataset.url;
        document.getElementById('editNome').value = botao.dataset.nome;
        document.getElementById('editCelular').value = botao.dataset.celular;
        document.getElementById('editEndereco').value = botao.dataset.endereco;
        modalEdicao.showModal();
    });
});
document.querySelectorAll('.btn-excluir').forEach(botao => {
    botao.addEventListener('click', () => {
        document.getElementById('nomeClienteModal').textContent = botao.dataset.nome;
        document.getElementById('formExclusao').action = botao.dataset.url;
        modalExclusao.showModal();
    });
});
