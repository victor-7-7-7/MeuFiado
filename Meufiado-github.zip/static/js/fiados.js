'use strict';
configurarBusca('searchInputFiados', '.item-devedor', 'semFiados');
document.querySelectorAll('[data-profile]').forEach(botao => {
    botao.addEventListener('click', () => document.getElementById(botao.dataset.profile).showModal());
});
const clienteSelecionado = new URLSearchParams(window.location.search).get('cliente');
if (clienteSelecionado && /^\d+$/.test(clienteSelecionado)) {
    const perfil = document.getElementById('perfil-' + clienteSelecionado);
    if (perfil) perfil.showModal();
}
const toggleValor = document.getElementById('btnToggleValor');
let escondido = false;
try { escondido = localStorage.getItem('esconderValorFiados') === 'sim'; } catch {}
function mostrarValor() {
    document.getElementById('valor-real').hidden = escondido;
    document.getElementById('valor-borrado').hidden = !escondido;
    toggleValor.setAttribute('aria-pressed', String(escondido));
    toggleValor.setAttribute('aria-label', escondido ? 'Mostrar valor total' : 'Ocultar valor total');
}
mostrarValor();
toggleValor.addEventListener('click', () => {
    escondido = !escondido;
    mostrarValor();
    try { localStorage.setItem('esconderValorFiados', escondido ? 'sim' : 'nao'); } catch {}
});
const confirmacao = document.getElementById('confirmOverlay');
const confirmar = document.getElementById('confirmBotao');
let formPendente = null;
function pedirConfirmacao(form, titulo, texto) {
    formPendente = form;
    document.getElementById('confirmTitulo').textContent = titulo;
    document.getElementById('confirmTexto').textContent = texto;
    confirmar.disabled = false;
    confirmar.textContent = 'Confirmar';
    confirmacao.showModal();
}
confirmacao.addEventListener('close', () => { formPendente = null; });
document.querySelectorAll('.form-abater').forEach(form => {
    form.addEventListener('submit', event => {
        event.preventDefault();
        const valor = Number(form.elements.valor_abatimento.value).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'});
        pedirConfirmacao(form, 'Confirmar abatimento', `Registrar o pagamento de ${valor} na conta de ${form.dataset.nome}?`);
    });
});
document.querySelectorAll('.form-quitar').forEach(form => {
    form.addEventListener('submit', event => {
        event.preventDefault();
        pedirConfirmacao(form, 'Quitar conta inteira', `Confirmar o recebimento de ${form.dataset.saldo} e quitar a conta de ${form.dataset.nome}?`);
    });
});
confirmar.addEventListener('click', () => {
    if (formPendente) {
        confirmar.disabled = true;
        confirmar.textContent = 'Registrando…';
        formPendente.submit();
    }
});
