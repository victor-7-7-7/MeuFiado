'use strict';

let itensVenda = [];
let vendaEmEnvio = false;


function moedaVenda(valor) {

    return Number(valor || 0)
        .toLocaleString(
            'pt-BR',
            {
                style: 'currency',
                currency: 'BRL'
            }
        );

}


function adicionarProdutoVenda() {

    if (vendaEmEnvio) return;

    const select =
        document.getElementById(
            'produtoVenda'
        );

    const quantidadeInput =
        document.getElementById(
            'quantidadeVenda'
        );

    const option =
        select.options[
            select.selectedIndex
        ];

    if (!option || !option.value) {
        alert(
            'Selecione um produto.'
        );
        return;
    }

    const quantidade =
        Number(
            quantidadeInput.value
        );

    if (
        !Number.isSafeInteger(quantidade) ||
        quantidade <= 0
    ) {
        avisarVenda("Informe uma quantidade inteira, maior que zero.", true);
        return;
    }

    itensVenda.push({
        id: option.value,
        nome: option.dataset.nome,
        preco: Number(
            option.dataset.preco || 0
        ),
        quantidade
    });

    quantidadeInput.value = 1;

    renderVenda();

}


function removerProdutoVenda(index) {

    if (vendaEmEnvio) return;

    itensVenda.splice(index,1);

    renderVenda();

}


function renderVenda() {

    const container =
        document.getElementById(
            'itensVenda'
        );

    if (!itensVenda.length) {

        container.innerHTML = `
            <div class="venda-empty">
                Nenhum produto adicionado.
            </div>
        `;

    } else {

        container.innerHTML =
            itensVenda.map(
                (item,index) => {

                    const total =
                        item.preco *
                        item.quantidade;

                    return `
                        <div class="venda-item">

                            <div>
                                <strong>
                                    ${item.nome}
                                </strong>

                                <small>
                                    ${item.quantidade}
                                    ×
                                    ${moedaVenda(item.preco)}
                                </small>
                            </div>

                            <div class="venda-item-total">
                                ${moedaVenda(total)}
                            </div>

                            <button
                                type="button"
                                class="venda-item-remove"
                                onclick="removerProdutoVenda(${index})"
                            >
                                ×
                            </button>

                        </div>
                    `;

                }
            ).join('');

    }


    const totalQuantidade =
        itensVenda.reduce(
            (total,item) =>
                total +
                item.quantidade,
            0
        );


    const total =
        itensVenda.reduce(
            (total,item) =>
                total +
                (
                    item.preco *
                    item.quantidade
                ),
            0
        );


    document.getElementById(
        'totalItens'
    ).textContent =
        itensVenda.length;


    document.getElementById(
        'totalQuantidade'
    ).textContent =
        totalQuantidade;


    document.getElementById(
        'totalVenda'
    ).textContent =
        moedaVenda(total);

    document.getElementById("finalizarVenda").disabled = vendaEmEnvio || !itensVenda.length;

}

function avisarVenda(texto, erro = false) {
    const mensagem = document.getElementById('mensagemVenda');
    mensagem.textContent = texto;
    mensagem.classList.toggle('error', erro);
    mensagem.setAttribute('role', erro ? 'alert' : 'status');
    mensagem.hidden = false;
}

function bloquearVenda(enviando) {
    vendaEmEnvio = enviando;
    document.querySelectorAll(
        '#clienteVenda, #produtoVenda, #quantidadeVenda, #adicionarVenda, ' +
        'input[name="forma_pagamento"], .venda-item-remove'
    ).forEach(controle => { controle.disabled = enviando; });
    const botao = document.getElementById('finalizarVenda');
    botao.disabled = enviando || !itensVenda.length;
    botao.textContent = enviando ? 'Finalizando\u2026' : 'Finalizar venda';
    botao.setAttribute('aria-busy', String(enviando));
}

async function atualizarEstoqueVenda(url) {
    // Read committed quantities from the server instead of subtracting locally.
    const resposta = await fetch(url, {credentials: 'same-origin', cache: 'no-store'});
    if (!resposta.ok || resposta.redirected) throw new Error('Falha ao atualizar estoque.');
    const pagina = new DOMParser().parseFromString(await resposta.text(), 'text/html');
    const produtos = pagina.getElementById('produtoVenda');
    if (!produtos) throw new Error('Falha ao atualizar estoque.');
    const select = document.getElementById('produtoVenda');
    select.innerHTML = produtos.innerHTML;
    select.value = '';
}

async function finalizarVenda() {
    // Set this guard before the first await: even queued clicks cannot POST twice.
    if (vendaEmEnvio) return;
    if (!itensVenda.length) {
        avisarVenda('Adicione pelo menos um produto.', true);
        return;
    }
    const pagamento = document.querySelector('input[name="forma_pagamento"]:checked');
    const cliente = document.getElementById('clienteVenda');
    if (!pagamento || !['avista', 'fiado'].includes(pagamento.value)) {
        avisarVenda('Forma de pagamento inv\u00e1lida.', true);
        return;
    }
    if (pagamento.value === 'fiado' && !cliente.value) {
        avisarVenda('Selecione um cliente para vender no fiado.', true);
        cliente.focus();
        return;
    }
    const token = document.querySelector('meta[name="csrf-token"]')?.content;
    if (!token) {
        avisarVenda('Atualize a p\u00e1gina antes de finalizar a venda.', true);
        return;
    }
    const botao = document.getElementById('finalizarVenda');
    const venda = {
        forma_pagamento: pagamento.value,
        cliente_id: cliente.value ? Number(cliente.value) : null,
        itens: itensVenda.map(item => ({id: Number(item.id), quantidade: item.quantidade})),
    };
    bloquearVenda(true);
    document.getElementById('mensagemVenda').hidden = true;
    try {
        const resposta = await fetch(botao.dataset.url, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRFToken': token,
            },
            body: JSON.stringify(venda),
        });
        const texto = await resposta.text();
        let dados = {};
        try { dados = JSON.parse(texto); } catch {}
        if (!resposta.ok || dados.sucesso !== true) {
            let erro = dados.erro || texto || 'N\u00e3o foi poss\u00edvel registrar a venda.';
            if (!dados.erro && resposta.headers.get('Content-Type')?.includes('text/html')) {
                const pagina = new DOMParser().parseFromString(texto, 'text/html');
                erro = `${resposta.status}: ${pagina.body.textContent.trim() || resposta.statusText}`;
            }
            throw new Error(erro);
        }
        // The POST has committed. Clear it before refreshing; never resend on a GET failure.
        itensVenda = [];
        cliente.value = '';
        document.getElementById('quantidadeVenda').value = 1;
        document.querySelector('input[name="forma_pagamento"][value="avista"]').checked = true;
        renderVenda();
        const mensagem = dados.mensagem || 'Venda registrada com sucesso.';
        avisarVenda(mensagem);
        try {
            await atualizarEstoqueVenda(botao.dataset.url);
        } catch {
            avisarVenda(mensagem + ' Atualize a p\u00e1gina para consultar o novo estoque.');
        }
    } catch (erro) {
        avisarVenda(erro instanceof TypeError
            ? 'A conex\u00e3o foi interrompida. Confira as vendas e o estoque antes de tentar novamente.'
            : erro.message, true);
    } finally {
        bloquearVenda(false);
    }
}

document.getElementById('finalizarVenda').addEventListener('click', finalizarVenda);
renderVenda();
