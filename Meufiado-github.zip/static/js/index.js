'use strict';
const formFiado = document.getElementById('formFiado');
const painel = document.getElementById('painelResumo');
async function atualizarPainel() {
    const resposta = await fetch(painel.dataset.url, {cache: 'no-store'});
    if (!resposta.ok) throw new Error('Não foi possível atualizar o painel.');
    const dados = await resposta.json();
    painel.innerHTML = dados.html;
}
window.addEventListener('pageshow', event => {
    if (event.persisted) atualizarPainel().catch(() => {});
});
if (formFiado) {
    const mensagem = document.getElementById('mensagem-fiado');
    const botao = formFiado.querySelector('button[type="submit"]');
    const conteudoBotao = botao.innerHTML;
    let enviando = false;
    function avisar(texto, erro = false) {
        mensagem.textContent = texto;
        mensagem.classList.toggle('error', erro);
        mensagem.hidden = false;
    }
    formFiado.addEventListener('submit', async event => {
        event.preventDefault();
        if (enviando) return;
        const cliente = document.getElementById('clienteInput');
        const opcoes = Array.from(document.getElementById('lista-clientes').options);
        const selecionado = opcoes.find(item => item.value.toLocaleLowerCase('pt-BR').replace(/\s+/g, ' ').trim() === cliente.value.toLocaleLowerCase('pt-BR').replace(/\s+/g, ' ').trim());
        if (!selecionado) {
            avisar('Selecione um cliente da lista. Se ele ainda não aparece, cadastre-o primeiro.', true);
            cliente.focus();
            return;
        }
        cliente.value = selecionado.value;
        enviando = true;
        botao.disabled = true;
        botao.textContent = 'Registrando…';
        mensagem.hidden = true;
        try {
            const resposta = await fetch(formFiado.action, {method: 'POST', body: new FormData(formFiado)});
            const texto = await resposta.text();
            if (!resposta.ok) throw new Error(texto || 'Não foi possível registrar a compra.');
            formFiado.reset();
            avisar('Compra registrada com sucesso!');
            try { await atualizarPainel(); }
            catch { avisar('Compra registrada! Atualize a página para consultar o novo saldo.'); }
        } catch (erro) {
            avisar(erro instanceof TypeError ? 'A conexão foi interrompida. Confira a conta do cliente antes de tentar novamente.' : erro.message, true);
        } finally {
            enviando = false;
            botao.disabled = false;
            botao.innerHTML = conteudoBotao;
        }
    });
}
