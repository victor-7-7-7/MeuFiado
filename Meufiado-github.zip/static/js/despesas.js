﻿'use strict';

(() => {
    const form = document.getElementById('formDespesa');
    if (!form) return;
    const container = document.getElementById('gastosDespesa');
    const template = document.getElementById('modeloGasto');
    const add = document.getElementById('adicionarGasto');
    const output = document.getElementById('totalLancamentos');
    const submit = form.querySelector('button[type="submit"]');
    const formatter = new Intl.NumberFormat('pt-BR', {style: 'currency', currency: 'BRL'});
    let submitting = false;

    // Parse and round decimal digits to cents, without floating-point addition.
    function cents(text) {
        let value = text.trim().replace(/R\$/g, '').replace(/\s/g, '');
        if (!value) return 0;
        if (value.includes(',')) value = value.replace(/\./g, '').replace(',', '.');
        const match = /^\+?(\d*)(?:\.(\d*))?$/.exec(value);
        if (!match || (!match[1] && !match[2]) || Number(value) > 999999999.99) return null;
        const fraction = (match[2] || '').padEnd(3, '0');
        const amount = Number(match[1] || '0') * 100 + Number(fraction.slice(0, 2))
            + (Number(fraction[2]) >= 5 ? 1 : 0);
        return Number.isSafeInteger(amount) && amount > 0 ? amount : null;
    }

    function recalculate() {
        let total = 0;
        let valid = true;
        const rows = [...container.querySelectorAll('[data-gasto]')];
        rows.forEach((row, index) => {
            row.querySelector('[data-numero]').textContent = String(index + 1);
            const remove = row.querySelector('[data-remover-gasto]');
            if (remove) remove.setAttribute('aria-label', `Remover gasto ${index + 1}`);
            const input = row.querySelector('input[name="valor"]');
            const value = cents(input.value);
            input.setCustomValidity(value === null ? 'Informe um valor válido, maior que zero.' : '');
            if (value === null) valid = false;
            else total += value;
        });
        output.textContent = valid && Number.isSafeInteger(total)
            ? formatter.format(total / 100) : 'Corrija os valores informados';
        submit.disabled = submitting || !rows.length;
    }

    if (add) add.addEventListener('click', () => {
        if (submitting) return;
        container.appendChild(template.content.cloneNode(true));
        recalculate();
        container.lastElementChild.querySelector('select, input').focus();
    });
    container.addEventListener('click', event => {
        const button = event.target.closest('[data-remover-gasto]');
        if (!button || submitting) return;
        button.closest('[data-gasto]').remove();
        recalculate();
        if (add) add.focus();
    });
    container.addEventListener('input', recalculate);
    form.addEventListener('submit', event => {
        if (submitting || !container.querySelector('[data-gasto]')) {
            event.preventDefault();
            return;
        }
        submitting = true;
        submit.disabled = true;
    });
    window.addEventListener('pageshow', () => {
        submitting = false;
        recalculate();
    });
    recalculate();
})();
