'use strict';
const navToggle = document.getElementById('navToggle');
const navMenu = document.getElementById('navMenu');
function fecharMenu() {
    navMenu.classList.remove('aberto');
    navToggle.setAttribute('aria-expanded', 'false');
}
navToggle.addEventListener('click', () => {
    const aberto = navMenu.classList.toggle('aberto');
    navToggle.setAttribute('aria-expanded', String(aberto));
});
document.addEventListener('click', event => {
    if (!navMenu.contains(event.target) && !navToggle.contains(event.target)) fecharMenu();
});
document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && navMenu.classList.contains('aberto')) {
        fecharMenu();
        navToggle.focus();
    }
});
document.querySelectorAll('[data-close-dialog]').forEach(button => {
    button.addEventListener('click', () => button.closest('dialog').close());
});
document.querySelectorAll('dialog').forEach(dialog => {
    dialog.addEventListener('click', event => {
        const rect = dialog.getBoundingClientRect();
        if (event.target === dialog && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) dialog.close();
    });
});
function normalizar(texto) {
    return texto.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR').replace(/\s+/g, ' ').trim();
}
function configurarBusca(inputId, seletor, emptyId) {
    const input = document.getElementById(inputId);
    if (!input) return;
    const itens = Array.from(document.querySelectorAll(seletor));
    const empty = document.getElementById(emptyId);
    function filtrar() {
        const termo = normalizar(input.value);
        let quantidade = 0;
        itens.forEach(item => {
            item.hidden = !normalizar(item.dataset.search || '').includes(termo);
            if (!item.hidden) quantidade++;
        });
        if (empty) empty.hidden = !termo || quantidade > 0;
    }
    input.addEventListener('input', filtrar);
    window.addEventListener('pageshow', filtrar);
    filtrar();
}
