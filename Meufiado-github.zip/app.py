﻿"""Backward-compatible entry point: python app.py / flask --app app / app:app."""

from meufiado import create_app
from meufiado.config import BASE_DIR as _BASE_DIR
from meufiado.database import banco as _banco
from meufiado.database import get_db_connection as _get_db_connection
from meufiado.database import init_db as _init_db


app = create_app()
BASE_DIR = str(_BASE_DIR)
DB_PATH = app.config["DB_PATH"]


def get_db_connection():
    """Preserve the existing helper for scripts outside an app context."""
    return _get_db_connection(app.config["DB_PATH"])


def banco(escrita=False):
    return _banco(escrita=escrita, db_path=app.config["DB_PATH"])


def init_db():
    with app.app_context():
        _init_db()


if __name__ == "__main__":
    app.run(debug=False)
